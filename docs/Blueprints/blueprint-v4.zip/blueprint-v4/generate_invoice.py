"""
generate_invoice.py
Brian Onieal | Freelance AI Systems Engineer
Usage: python generate_invoice.py

Fill in the INVOICE_DATA dict below, then run to produce a PDF invoice.
Output: invoices/INV-XXX_ClientName_YYYY-MM-DD.pdf
"""

from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
)
from reportlab.lib.enums import TA_RIGHT, TA_LEFT, TA_CENTER
import os
from datetime import datetime, timedelta

# ─────────────────────────────────────────────────────────────
# FILL THIS IN FOR EACH INVOICE
# ─────────────────────────────────────────────────────────────
INVOICE_DATA = {
    # Your info
    "your_name": "Brian Onieal",
    "your_title": "Freelance AI Systems Engineer",
    "your_email": "{{YOUR_EMAIL}}",
    "your_location": "Brooklyn, NY",
    "your_github": "github.com/brianonieal",

    # Client info
    "client_name": "{{CLIENT_NAME}}",
    "client_company": "{{CLIENT_COMPANY}}",
    "client_email": "{{CLIENT_EMAIL}}",

    # Invoice meta
    "invoice_number": "INV-001",
    "contract_ref": "{{CONTRACT_REF_NUMBER}}",
    "project_name": "{{APP_NAME}}",
    "issue_date": datetime.today().strftime("%B %d, %Y"),
    "due_date": (datetime.today() + timedelta(days=15)).strftime("%B %d, %Y"),

    # Rates
    "hourly_rate": 150.00,

    # Line items: (description, gate/phase, hours, unit_price, is_flat_fee)
    # Set is_flat_fee=True to show a flat amount instead of hours x rate
    "line_items": [
        ("Discovery & Requirements Gathering", "Pre-Project", 4.0, 150.00, False),
        ("Blueprint & Architecture Planning", "v0.0.0", 3.0, 150.00, False),
        ("Project Scaffold & Dev Environment", "v0.1.0", 2.0, 150.00, False),
        ("Database Schema & Migrations", "v0.2.0", 6.0, 150.00, False),
        ("Authentication Integration", "v0.3.0", 4.0, 150.00, False),
        ("Core Feature: {{FEATURE_1}}", "v0.4.0", 8.0, 150.00, False),
        ("Core Feature: {{FEATURE_2}}", "v0.5.0", 10.0, 150.00, False),
        ("Client Revision Round 1 (included)", "Revisions", 2.0, 0.00, False),
        ("Scope Change: {{SCOPE_CHANGE_DESC}}", "SCOPE", 3.0, 150.00, False),
    ],

    # Expenses: (description, service, amount)
    "expenses": [
        ("Anthropic Claude API usage", "Anthropic", 28.50),
        ("Supabase Pro plan - 1 month", "Supabase", 25.00),
        ("Vercel Pro plan - 1 month", "Vercel", 20.00),
    ],

    # Milestone context
    "milestone": "v0.5.0 Gate Complete",
    "milestone_description": (
        "This invoice covers work completed through the v0.5.0 milestone gate. "
        "All passing criteria have been met. The next gate (v1.0.0) will open "
        "upon receipt of this payment."
    ),

    # Deliverables checklist
    "deliverables": [
        "Database schema with full migration history",
        "Authentication system (sign up, sign in, session management)",
        "{{FEATURE_1}} -- fully functional with tests passing",
        "{{FEATURE_2}} -- fully functional with tests passing",
        "Deployed to staging environment at {{STAGING_URL}}",
        "All test suite passing (X/X tests)",
    ],

    # Revision rounds
    "revisions_included": 2,
    "revisions_used": 1,

    # Scope changes
    "scope_changes": [
        "Client-requested: {{SCOPE_CHANGE_DESC}} (+X hrs, approved {{DATE}})",
    ],

    # Payment info
    "payment_methods": "Venmo: @{{VENMO}} | Zelle: {{EMAIL}} | Check payable to: Brian Onieal",
    "late_fee": "1.5% per month on balances unpaid after due date",
    "kill_fee": "50% of remaining contract value if project cancelled after v0.2.0",

    # IP clause
    "ip_clause": (
        "Full intellectual property and source code ownership transfers to client "
        "upon receipt of final payment in full. No IP is transferred for partial payments."
    ),
}
# ─────────────────────────────────────────────────────────────


def build_invoice(data):
    os.makedirs("invoices", exist_ok=True)
    filename = f"invoices/{data['invoice_number']}_{data['client_company'].replace(' ', '_')}_{datetime.today().strftime('%Y-%m-%d')}.pdf"

    doc = SimpleDocTemplate(
        filename,
        pagesize=letter,
        rightMargin=0.75 * inch,
        leftMargin=0.75 * inch,
        topMargin=0.75 * inch,
        bottomMargin=0.75 * inch,
    )

    # Colors
    NAVY = colors.HexColor("#1B2B4B")
    GOLD = colors.HexColor("#C8A96E")
    LIGHT_GRAY = colors.HexColor("#F5F5F5")
    MID_GRAY = colors.HexColor("#888888")
    BLACK = colors.black
    WHITE = colors.white

    styles = getSampleStyleSheet()

    def style(name, **kwargs):
        return ParagraphStyle(name, **kwargs)

    S = {
        "h1": style("h1", fontSize=22, textColor=NAVY, fontName="Helvetica-Bold", spaceAfter=2),
        "h2": style("h2", fontSize=11, textColor=NAVY, fontName="Helvetica-Bold", spaceAfter=4),
        "h3": style("h3", fontSize=9, textColor=NAVY, fontName="Helvetica-Bold", spaceAfter=2),
        "body": style("body", fontSize=9, textColor=BLACK, fontName="Helvetica", spaceAfter=2, leading=13),
        "small": style("small", fontSize=8, textColor=MID_GRAY, fontName="Helvetica", spaceAfter=2, leading=11),
        "right": style("right", fontSize=9, textColor=BLACK, fontName="Helvetica", alignment=TA_RIGHT),
        "right_bold": style("right_bold", fontSize=10, textColor=NAVY, fontName="Helvetica-Bold", alignment=TA_RIGHT),
        "label": style("label", fontSize=8, textColor=MID_GRAY, fontName="Helvetica", spaceAfter=1),
        "gold": style("gold", fontSize=9, textColor=GOLD, fontName="Helvetica-Bold"),
        "total": style("total", fontSize=13, textColor=WHITE, fontName="Helvetica-Bold", alignment=TA_RIGHT),
    }

    story = []
    W = 7.0 * inch  # usable width

    # ── HEADER ──────────────────────────────────────────────────
    header_data = [[
        Paragraph(f"<b>{data['your_name']}</b>", S["h1"]),
        Paragraph(f"<b>INVOICE</b>", style("inv", fontSize=22, textColor=GOLD, fontName="Helvetica-Bold", alignment=TA_RIGHT)),
    ]]
    header_table = Table(header_data, colWidths=[W * 0.6, W * 0.4])
    header_table.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "BOTTOM")]))
    story.append(header_table)

    story.append(Paragraph(data["your_title"], S["body"]))
    story.append(Paragraph(f"{data['your_email']}  |  {data['your_location']}  |  {data['your_github']}", S["small"]))
    story.append(Spacer(1, 8))
    story.append(HRFlowable(width=W, thickness=2, color=NAVY))
    story.append(Spacer(1, 10))

    # ── BILL TO / INVOICE META ──────────────────────────────────
    meta_data = [[
        [
            Paragraph("BILL TO", S["label"]),
            Paragraph(f"<b>{data['client_name']}</b>", S["h2"]),
            Paragraph(data["client_company"], S["body"]),
            Paragraph(data["client_email"], S["body"]),
        ],
        [
            Paragraph("INVOICE #", S["label"]),
            Paragraph(f"<b>{data['invoice_number']}</b>", S["h2"]),
            Paragraph(f"Contract Ref: {data['contract_ref']}", S["small"]),
            Spacer(1, 4),
            Paragraph("ISSUE DATE", S["label"]),
            Paragraph(data["issue_date"], S["body"]),
            Spacer(1, 4),
            Paragraph("DUE DATE", S["label"]),
            Paragraph(f"<b>{data['due_date']}</b>", S["body"]),
        ],
    ]]
    meta_table = Table([[meta_data[0][0], meta_data[0][1]]], colWidths=[W * 0.55, W * 0.45])
    meta_table.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP")]))
    story.append(meta_table)
    story.append(Spacer(1, 12))

    # ── PROJECT / MILESTONE ──────────────────────────────────────
    story.append(Paragraph(f"Project: <b>{data['project_name']}</b>  |  Milestone: <b>{data['milestone']}</b>", S["body"]))
    story.append(Paragraph(data["milestone_description"], S["small"]))
    story.append(Spacer(1, 10))

    # ── LINE ITEMS TABLE ─────────────────────────────────────────
    story.append(Paragraph("SERVICES", S["h2"]))

    li_header = [
        Paragraph("<b>Description</b>", S["h3"]),
        Paragraph("<b>Gate / Phase</b>", S["h3"]),
        Paragraph("<b>Hours</b>", ParagraphStyle("rh", fontSize=9, fontName="Helvetica-Bold", alignment=TA_RIGHT)),
        Paragraph("<b>Rate</b>", ParagraphStyle("rh", fontSize=9, fontName="Helvetica-Bold", alignment=TA_RIGHT)),
        Paragraph("<b>Amount</b>", ParagraphStyle("rh", fontSize=9, fontName="Helvetica-Bold", alignment=TA_RIGHT)),
    ]

    li_rows = [li_header]
    total_hours = 0
    subtotal = 0

    for desc, gate, hours, rate, is_flat in data["line_items"]:
        amount = rate if is_flat else hours * rate
        total_hours += hours if not is_flat else 0
        subtotal += amount
        li_rows.append([
            Paragraph(desc, S["body"]),
            Paragraph(gate, S["small"]),
            Paragraph("—" if is_flat else f"{hours:.1f}", S["right"]),
            Paragraph("Flat" if is_flat else f"${rate:.0f}/hr", S["right"]),
            Paragraph(f"${amount:,.2f}", S["right"]),
        ])

    li_table = Table(li_rows, colWidths=[W * 0.38, W * 0.18, W * 0.1, W * 0.14, W * 0.2])
    li_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("TEXTCOLOR", (0, 0), (-1, 0), WHITE),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [WHITE, LIGHT_GRAY]),
        ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#DDDDDD")),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
    ]))
    story.append(li_table)
    story.append(Spacer(1, 10))

    # ── EXPENSES ─────────────────────────────────────────────────
    total_expenses = sum(amt for _, _, amt in data["expenses"])
    if data["expenses"]:
        story.append(Paragraph("EXPENSES (PASS-THROUGH)", S["h2"]))
        exp_rows = [[
            Paragraph("<b>Description</b>", S["h3"]),
            Paragraph("<b>Service</b>", S["h3"]),
            Paragraph("<b>Amount</b>", ParagraphStyle("rh", fontSize=9, fontName="Helvetica-Bold", alignment=TA_RIGHT)),
        ]]
        for desc, svc, amt in data["expenses"]:
            exp_rows.append([
                Paragraph(desc, S["body"]),
                Paragraph(svc, S["small"]),
                Paragraph(f"${amt:,.2f}", S["right"]),
            ])
        exp_table = Table(exp_rows, colWidths=[W * 0.55, W * 0.25, W * 0.2])
        exp_table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), NAVY),
            ("TEXTCOLOR", (0, 0), (-1, 0), WHITE),
            ("ROWBACKGROUNDS", (0, 1), (-1, -1), [WHITE, LIGHT_GRAY]),
            ("GRID", (0, 0), (-1, -1), 0.25, colors.HexColor("#DDDDDD")),
            ("TOPPADDING", (0, 0), (-1, -1), 5),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
            ("LEFTPADDING", (0, 0), (-1, -1), 6),
            ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ]))
        story.append(exp_table)
        story.append(Spacer(1, 10))

    # ── TOTALS ───────────────────────────────────────────────────
    grand_total = subtotal + total_expenses
    totals_data = [
        ["", Paragraph("Services Subtotal", S["right"]), Paragraph(f"${subtotal:,.2f}", S["right"])],
        ["", Paragraph("Expenses", S["right"]), Paragraph(f"${total_expenses:,.2f}", S["right"])],
        ["", Paragraph(f"<b>TOTAL DUE</b>", S["total"]), Paragraph(f"<b>${grand_total:,.2f}</b>", S["total"])],
    ]
    totals_table = Table(totals_data, colWidths=[W * 0.55, W * 0.25, W * 0.2])
    totals_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 2), (-1, 2), NAVY),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("LINEABOVE", (1, 2), (-1, 2), 1, GOLD),
    ]))
    story.append(totals_table)
    story.append(Spacer(1, 16))

    # ── DELIVERABLES ──────────────────────────────────────────────
    story.append(HRFlowable(width=W, thickness=0.5, color=colors.HexColor("#DDDDDD")))
    story.append(Spacer(1, 8))
    story.append(Paragraph("DELIVERABLES", S["h2"]))
    for item in data["deliverables"]:
        story.append(Paragraph(f"&#x2713;  {item}", S["body"]))
    story.append(Spacer(1, 8))

    # ── SCOPE CHANGES ─────────────────────────────────────────────
    if data["scope_changes"]:
        story.append(Paragraph("SCOPE CHANGES", S["h2"]))
        for sc in data["scope_changes"]:
            story.append(Paragraph(f"&#x25B8;  {sc}", S["body"]))
        story.append(Spacer(1, 8))

    # ── REVISION ROUNDS ───────────────────────────────────────────
    story.append(Paragraph(
        f"REVISION ROUNDS: {data['revisions_used']} of {data['revisions_included']} included rounds used.",
        S["body"]
    ))
    story.append(Spacer(1, 10))

    # ── PAYMENT / TERMS ───────────────────────────────────────────
    story.append(HRFlowable(width=W, thickness=0.5, color=colors.HexColor("#DDDDDD")))
    story.append(Spacer(1, 8))
    story.append(Paragraph("PAYMENT", S["h2"]))
    story.append(Paragraph(data["payment_methods"], S["body"]))
    story.append(Spacer(1, 6))

    terms_data = [[
        [Paragraph("PAYMENT TERMS", S["label"]), Paragraph(f"Net 15 -- due by {data['due_date']}", S["body"])],
        [Paragraph("LATE FEE", S["label"]), Paragraph(data["late_fee"], S["body"])],
        [Paragraph("KILL FEE", S["label"]), Paragraph(data["kill_fee"], S["body"])],
    ]]
    terms_table = Table([[terms_data[0][0], terms_data[0][1], terms_data[0][2]]], colWidths=[W / 3] * 3)
    terms_table.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("BACKGROUND", (0, 0), (-1, -1), LIGHT_GRAY),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
    ]))
    story.append(terms_table)
    story.append(Spacer(1, 8))

    # ── IP CLAUSE ─────────────────────────────────────────────────
    story.append(Paragraph("INTELLECTUAL PROPERTY", S["label"]))
    story.append(Paragraph(data["ip_clause"], S["small"]))
    story.append(Spacer(1, 10))

    # ── FOOTER ────────────────────────────────────────────────────
    story.append(HRFlowable(width=W, thickness=2, color=NAVY))
    story.append(Spacer(1, 4))
    story.append(Paragraph(
        f"Thank you for the opportunity to build {data['project_name']}. "
        f"Questions: {data['your_email']}",
        S["small"]
    ))

    doc.build(story)
    return filename


if __name__ == "__main__":
    output = build_invoice(INVOICE_DATA)
    print(f"Invoice generated: {output}")
