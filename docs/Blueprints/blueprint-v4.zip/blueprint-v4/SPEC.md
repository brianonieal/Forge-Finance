# SPEC.md — Current Gate Specification
# {{APP_NAME}}
# Last updated: {{DATE}}
#
# PURPOSE: Generated at gate open. Defines exactly what gets built this gate.
# Claude checks its own work against this file throughout the gate.
# Gate cannot close until all spec items are checked.
#
# RULE: SPEC.md is overwritten at every gate open with a new spec.
# RULE: Previous gate specs are archived in specs/v[VERSION]-spec.md
# RULE: If scope changes mid-gate, update SPEC.md and log a pivot in DECISIONS.md
# RULE: Claude checks SPEC.md before starting any task within the gate

---

## Current Gate: {{GATE_VERSION}} — {{GATE_NAME}}
**Opened:** {{DATE}}
**Target close:** {{TARGET_DATE}}
**Status:** IN PROGRESS

---

## What Gets Built This Gate

### Backend
- [ ] {{BACKEND_TASK_1}}
- [ ] {{BACKEND_TASK_2}}

### Frontend
- [ ] {{FRONTEND_TASK_1}}
- [ ] {{FRONTEND_TASK_2}}

### Database
- [ ] {{DB_TASK_1}}

### Tests
- [ ] {{TEST_TASK_1}}
- Target test count: {{EXPECTED_TESTS}} passing

---

## What Does NOT Get Built This Gate
Explicitly out of scope -- do not implement even if it seems related:
- {{OUT_OF_SCOPE_1}}
- {{OUT_OF_SCOPE_2}}

---

## Files That Will Be Modified This Gate
Claude references this list to scope its work correctly.

**New files:**
- `{{FILE_PATH_1}}`
- `{{FILE_PATH_2}}`

**Modified files:**
- `{{FILE_PATH_3}}`
- `{{FILE_PATH_4}}`

**Do not touch:**
- `{{FILE_PATH_5}}` -- reason: {{WHY_NOT}}

---

## Acceptance Criteria
Gate cannot close until ALL of these pass:

- [ ] {{CRITERION_1}}
- [ ] {{CRITERION_2}}
- [ ] `{{TEST_COMMAND}}` passes with {{EXPECTED_TESTS}} tests
- [ ] Security lightweight check: PASS
- [ ] Performance lightweight check: PASS
- [ ] agnix: PASS (no errors)
- [ ] /deslop applied: PASS
- [ ] CHANGELOG.md updated: DONE
- [ ] TIMELOG.md updated: DONE

---

## Risk Areas
Things most likely to go wrong in this gate.

| Risk | Likelihood | Mitigation |
|------|-----------|------------|
| {{RISK_1}} | HIGH/MED/LOW | {{HOW_TO_MITIGATE}} |

---

## Architectural Decisions Made At Gate Open
Any decisions made when opening this gate that affect implementation.
Full details in DECISIONS.md.

- DEC-{{NNN}}: {{DECISION_SUMMARY}}

---

## Rollback Plan
If this gate fails catastrophically:
`git revert {{VERSION_TAG}}`
Additional steps: {{ROLLBACK_NOTES}}

---

## Spec Archive
Previous gate specs preserved for reference:
`specs/v0.0.0-foundation-spec.md`
`specs/v0.1.0-scaffold-spec.md`
(add entry when archiving before overwriting)
