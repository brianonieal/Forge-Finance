# CONTRACT.md — Single Source of Truth
# {{APP_NAME}} | Version: {{CURRENT_VERSION}}
# Last updated: {{DATE}}
#
# RULE: Nothing is hardcoded in application code that is defined here.
# All values consumed via environment variable, import, or config loader.
# Update this file FIRST, then update code.

## Project Identity
APP_NAME="{{APP_NAME}}"
APP_VERSION="{{CURRENT_VERSION}}"
APP_ENV="development" # development | staging | production

## Ports & URLs
DEV_PORT={{DEV_PORT}}
API_BASE_URL="{{API_BASE_URL}}"
FRONTEND_URL="{{FRONTEND_URL}}"

## Database
DB_PROVIDER="{{DB_PROVIDER}}"  # supabase | postgres | sqlite | mongo
DB_URL="{{DB_URL_ENV_VAR}}"    # env var name, not value

## Authentication
AUTH_PROVIDER="{{AUTH_PROVIDER}}"  # supabase | clerk | auth0 | none
AUTH_SECRET_ENV="{{AUTH_SECRET_ENV_VAR}}"

## AI / LLM
PRIMARY_MODEL="claude-sonnet-4-6"
FALLBACK_MODEL="claude-haiku-4-5-20251001"
MAX_TOKENS=1000
ANTHROPIC_API_KEY_ENV="ANTHROPIC_API_KEY"

## Agent Configuration
# Names must match COUNCIL_AGENTS.md exactly
AGENT_ROUTER="{{AGENT_ROUTER_NAME}}"
AGENT_PRIMARY="{{AGENT_PRIMARY_NAME}}"
# Add all agents here

## Feature Flags
FEATURE_{{FLAG_NAME}}=false

## External Services
# Pattern: SERVICE_NAME_ENV="ENV_VAR_NAME"
{{EXTERNAL_SERVICES}}

## File Paths (relative to project root)
UPLOADS_DIR="./uploads"
LOGS_DIR="./logs"
MEMORY_DIR="./.claude/memory"

## Test Configuration
TEST_TIMEOUT_MS=5000
TEST_DB_URL="{{TEST_DB_URL}}"

## Deployment
DEPLOY_FRONTEND="vercel"  # vercel | netlify | cloudflare
DEPLOY_BACKEND="{{BACKEND_DEPLOY}}"  # render | railway | fly | vercel
