# TECH_STACK.md — Canonical Stack Decisions
# {{APP_NAME}}
# Last updated: {{DATE}}
#
# RULE: Claude must read this before writing any code.
# RULE: Never use an alternative to a listed technology without updating this file first.
# RULE: Rationale is included so Claude understands WHY -- not just WHAT.

---

## App Type
- [ ] Full-stack web (Next.js)
- [ ] Mobile (Expo / React Native)
- [ ] API only (FastAPI / Express)
- [ ] Multi-repo (monorepo -- list packages below)
- [ ] Hybrid: {{DESCRIBE}}

---

## Frontend

| Layer            | Technology              | Version    | Rationale                                      |
|------------------|-------------------------|------------|------------------------------------------------|
| Framework        | {{FRONTEND_FRAMEWORK}}  | {{VERSION}}| {{RATIONALE}}                                  |
| Styling          | {{STYLING}}             | {{VERSION}}| {{RATIONALE}}                                  |
| State management | {{STATE_MGMT}}          | {{VERSION}}| {{RATIONALE}}                                  |
| Navigation       | {{NAVIGATION}}          | {{VERSION}}| {{RATIONALE}}                                  |
| Forms            | {{FORMS}}               | {{VERSION}}| {{RATIONALE}}                                  |
| HTTP client      | {{HTTP_CLIENT}}         | {{VERSION}}| {{RATIONALE}}                                  |
| Testing          | {{TEST_FRAMEWORK}}      | {{VERSION}}| {{RATIONALE}}                                  |

### Frontend Conventions
- Import style: {{ES_MODULES | CommonJS}}
- Component pattern: {{FUNCTIONAL | CLASS}}
- File naming: {{kebab-case | PascalCase | camelCase}}
- State pattern: {{ZUSTAND | REDUX | CONTEXT | JOTAI}}
- {{ANY_OTHER_NON_DEFAULT_CONVENTION}}

---

## Backend

| Layer            | Technology              | Version    | Rationale                                      |
|------------------|-------------------------|------------|------------------------------------------------|
| Runtime          | {{RUNTIME}}             | {{VERSION}}| {{RATIONALE}}                                  |
| Framework        | {{API_FRAMEWORK}}       | {{VERSION}}| {{RATIONALE}}                                  |
| ORM / DB client  | {{ORM}}                 | {{VERSION}}| {{RATIONALE}}                                  |
| Auth             | {{AUTH_LIB}}            | {{VERSION}}| {{RATIONALE}}                                  |
| Validation       | {{VALIDATION}}          | {{VERSION}}| {{RATIONALE}}                                  |
| Testing          | {{TEST_FRAMEWORK}}      | {{VERSION}}| {{RATIONALE}}                                  |

### Backend Conventions
- Route pattern: {{REST | GraphQL | tRPC}}
- Response shape: `{ success: boolean, data: T | null, error: string | null }`
- Error handling: All external calls wrapped in try/catch. Retry transient errors (429, 503) with exponential backoff.
- Logging: Structured logger (not console.log). Never swallow errors silently.
- {{ANY_OTHER_NON_DEFAULT_CONVENTION}}

---

## Database

| Layer            | Technology              | Rationale                                      |
|------------------|-------------------------|------------------------------------------------|
| Primary DB       | {{DB}}                  | {{RATIONALE}}                                  |
| Vector store     | {{VECTOR_DB}}           | {{RATIONALE}} (omit if N/A)                    |
| Cache            | {{CACHE}}               | {{RATIONALE}} (omit if N/A)                    |
| Migrations       | {{MIGRATION_TOOL}}      | {{RATIONALE}}                                  |

---

## AI / LLM

| Layer            | Technology              | Rationale                                      |
|------------------|-------------------------|------------------------------------------------|
| Primary model    | claude-sonnet-4-6       | Best coding + reasoning balance for production |
| Fallback model   | claude-haiku-4-5-...    | Cost-efficient fallback for simple tasks       |
| Orchestration    | {{LANGGRAPH | CUSTOM}}  | {{RATIONALE}}                                  |
| LLM router       | {{LITELLM | DIRECT}}    | {{RATIONALE}}                                  |
| Embeddings       | {{EMBEDDING_MODEL}}     | {{RATIONALE}} (omit if N/A)                    |

---

## Infrastructure & Deployment

| Layer            | Technology              | Tier       | Rationale                                      |
|------------------|-------------------------|------------|------------------------------------------------|
| Frontend deploy  | Vercel                  | Free/Pro   | Standard for Next.js and Expo web              |
| Backend deploy   | {{RENDER | RAILWAY}}    | {{TIER}}   | {{RATIONALE}}                                  |
| DB hosting       | {{SUPABASE | NEON}}     | {{TIER}}   | {{RATIONALE}}                                  |
| File storage     | {{S3 | SUPABASE}}       | {{TIER}}   | {{RATIONALE}} (omit if N/A)                    |
| CI/CD            | {{GITHUB_ACTIONS | N/A}}| N/A        | {{RATIONALE}}                                  |

---

## MCP Servers
List all MCP servers wired into the harness:

| Server           | URL                     | Purpose                                        |
|------------------|-------------------------|------------------------------------------------|
| {{MCP_SERVER}}   | {{URL}}                 | {{PURPOSE}}                                    |

---

## Explicitly Rejected Technologies
Document what was considered and rejected so Claude doesn't suggest them:

| Technology       | Rejected Because                                                     |
|------------------|----------------------------------------------------------------------|
| Redux            | Zustand is simpler and sufficient for this app's state complexity    |
| {{TECH}}         | {{REASON}}                                                           |

---

## Optional Web Extensions (Next.js only)
Pull these in only when the specific use case applies. Not baseline dependencies.
Mark [ ] not using or [x] active per project.

- [ ] **Pretext** (`@chenglou/pretext`) -- DOM-free text layout engine. 15KB, zero deps.
  - **Use when:** Text-heavy UI with dynamic layout -- chat interfaces, editorial spreads,
    AI-generated streaming text, admin dashboards with dense content, any component
    where `getBoundingClientRect` or `offsetHeight` would be in the hot render path.
  - **Do not use when:** Standard content pages, simple forms, Expo/React Native (incompatible).
  - **Why it matters:** 300-600x faster than DOM measurement. Enables text flowing around
    objects, shrink-wrapping chat bubbles, and 120fps layout at scale without reflows.
  - **API pattern:**
    ```typescript
    import { prepare, layout } from '@chenglou/pretext'
    const prepared = prepare(text, '16px FontName')   // one-time, ~19ms for 500 texts
    const { height, lineCount } = layout(prepared, containerWidth, lineHeight) // 0.09ms, pure arithmetic
    ```
  - **Install:** `npm install @chenglou/pretext`
  - **Docs:** github.com/chenglou/pretext

---

## Upgrade Policy
- Minor version bumps: allowed without file update
- Major version bumps: require updating this file and a review of breaking changes
- Never upgrade a dependency mid-version-gate. Only at gate boundaries.
