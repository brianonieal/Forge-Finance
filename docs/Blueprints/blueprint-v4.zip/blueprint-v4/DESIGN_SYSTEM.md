# DESIGN_SYSTEM.md — v2
# {{APP_NAME}}
# Last updated: {{DATE}}
#
# TWO-PHASE DESIGN SYSTEM:
# PHASE 1 — EXTRACTION: Run once at project start. Claude reads your reference
#            and populates the token tables below. Do not skip this.
# PHASE 2 — EXECUTION: Every build session. Claude reads populated tokens and
#            builds UI consistently. Never drifts. Never improvises palette.
#
# RULE: Complete Phase 1 before writing a single UI component.
# RULE: Never use a color, font, or spacing value not defined here.
# RULE: Log every design decision in the Decision Log below.
# RULE: Register every new component in the Component Registry.

---

## PHASE 1 — DESIGN EXTRACTION
# - [ ] Phase 1 complete

### Extraction Inputs
REFERENCE_URL="{{REFERENCE_SITE_OR_APP_URL}}"
REFERENCE_DESCRIPTION="{{VIBE_OR_MOOD_IN_WORDS}}"
BRAND_COLORS_DECIDED="{{ANY_COLORS_ALREADY_PICKED}}"
FIGMA_OR_SCREENSHOTS="{{PATH_OR_URL}}"

### Claude Extraction Prompt
Paste this into Claude Code at project start when you have a reference:

```
Read DESIGN_SYSTEM.md. Phase 1 is not complete.

My reference: [URL or describe it]
My vibe: [describe in words]
Colors already decided: [list them or say "none"]

Do the following in order:
1. Analyze the reference. Extract: dominant colors, accent, background, font
   feel, spacing density (tight/airy), radius style, overall tone.
2. Propose 3 original palette options that honor the reference vibe but are
   not a direct copy. Rank them by fit.
3. For each option, show BOTH Tailwind classes (Next.js) AND React Native
   StyleSheet hex values (Expo).
4. Recommend one font pairing: display + body. No Inter, Roboto, Arial,
   Space Grotesk. Something with character.
5. Wait for my approval before writing any code.
6. After approval: populate all token tables in this file, generate the
   Expo theme files and Tailwind config extension, mark Phase 1 complete.
```

---

## DESIGN INTENT

**Aesthetic tone:** {{e.g. "Warm, editorial, trust-forward"}}
**Reference:** {{URL}}
**The one unforgettable thing:** {{what a user remembers after one session}}
**What we are NOT:** {{e.g. "Not dark/techy. Not purple-gradient SaaS."}}

---

## COLOR TOKENS

### Master Token Table
Each token has three values. All three must be populated in Phase 1.

| Token             | Hex     | Tailwind (Next.js)  | RN StyleSheet (Expo)         | Usage                     |
|-------------------|---------|---------------------|------------------------------|---------------------------|
| `brand-primary`   | {{HEX}} | `bg-[{{HEX}}]`      | `colors.primary`             | CTAs, active states       |
| `brand-secondary` | {{HEX}} | `bg-[{{HEX}}]`      | `colors.secondary`           | Accents, highlights       |
| `brand-bg`        | {{HEX}} | `bg-[{{HEX}}]`      | `colors.background`          | Page/screen background    |
| `brand-surface`   | {{HEX}} | `bg-[{{HEX}}]`      | `colors.surface`             | Cards, panels, sheets     |
| `brand-border`    | {{HEX}} | `border-[{{HEX}}]`  | `colors.border`              | Borders, dividers         |
| `text-primary`    | {{HEX}} | `text-[{{HEX}}]`    | `colors.textPrimary`         | Body, headings            |
| `text-secondary`  | {{HEX}} | `text-[{{HEX}}]`    | `colors.textSecondary`       | Labels, captions          |
| `text-inverse`    | {{HEX}} | `text-[{{HEX}}]`    | `colors.textInverse`         | Text on dark bg           |
| `status-success`  | {{HEX}} | `text-[{{HEX}}]`    | `colors.success`             | Confirmations             |
| `status-error`    | {{HEX}} | `text-[{{HEX}}]`    | `colors.error`               | Errors, destructive       |
| `status-warning`  | {{HEX}} | `text-[{{HEX}}]`    | `colors.warning`             | Caution                   |

### Expo colors.ts (generate after Phase 1 approval)
```typescript
// src/theme/colors.ts
export const colors = {
  primary: '{{HEX}}',
  secondary: '{{HEX}}',
  background: '{{HEX}}',
  surface: '{{HEX}}',
  border: '{{HEX}}',
  textPrimary: '{{HEX}}',
  textSecondary: '{{HEX}}',
  textInverse: '{{HEX}}',
  success: '{{HEX}}',
  error: '{{HEX}}',
  warning: '{{HEX}}',
} as const;
```

### tailwind.config.ts extension (generate after Phase 1 approval)
```javascript
extend: {
  colors: {
    brand: {
      primary: '{{HEX}}', secondary: '{{HEX}}',
      bg: '{{HEX}}', surface: '{{HEX}}', border: '{{HEX}}',
    },
    text: { primary: '{{HEX}}', secondary: '{{HEX}}', inverse: '{{HEX}}' },
    status: { success: '{{HEX}}', error: '{{HEX}}', warning: '{{HEX}}' },
  },
}
```

---

## TYPOGRAPHY

| Role     | Family        | Weights   | Source               |
|----------|---------------|-----------|----------------------|
| Display  | {{FONT}}      | {{W}}     | {{Google/expo-font}} |
| Body     | {{FONT}}      | {{W}}     | {{Google/expo-font}} |
| Mono     | {{FONT}}      | 400       | System fallback ok   |

**Why this pairing:** {{rationale}}

### Type Scale
| Token     | px  | lh  | wt  | Tailwind      | RN fontSize | Usage            |
|-----------|-----|-----|-----|---------------|-------------|------------------|
| `xs`      | 12  | 16  | 400 | `text-xs`     | 12          | Fine print       |
| `sm`      | 14  | 20  | 400 | `text-sm`     | 14          | Labels           |
| `base`    | 16  | 24  | 400 | `text-base`   | 16          | Body             |
| `lg`      | 18  | 28  | 500 | `text-lg`     | 18          | Emphasis         |
| `xl`      | 20  | 28  | 600 | `text-xl`     | 20          | Subheadings      |
| `2xl`     | 24  | 32  | 700 | `text-2xl`    | 24          | Headings         |
| `3xl`     | 30  | 36  | 700 | `text-3xl`    | 30          | Page titles      |
| `display` | 40  | 48  | 700 | `text-4xl`    | 40          | Hero/splash      |

### Expo typography.ts (generate after Phase 1 approval)
```typescript
// src/theme/typography.ts
export const typography = {
  display: { fontFamily: '{{FONT}}-Bold', fontSize: 40, lineHeight: 48 },
  h1:      { fontFamily: '{{FONT}}-Bold', fontSize: 30, lineHeight: 36 },
  h2:      { fontFamily: '{{FONT}}-SemiBold', fontSize: 24, lineHeight: 32 },
  body:    { fontFamily: '{{FONT}}-Regular', fontSize: 16, lineHeight: 24 },
  label:   { fontFamily: '{{FONT}}-Medium', fontSize: 14, lineHeight: 20 },
  caption: { fontFamily: '{{FONT}}-Regular', fontSize: 12, lineHeight: 16 },
} as const;
```

---

## SPACING & LAYOUT

**Spacing feel:** {{TIGHT | BALANCED | AIRY}}
**Base unit:** 4px -- do not override

### Border Radius
**Radius style:** {{SHARP | SOFT | PILL-HEAVY}}

| Token        | Value  | Tailwind       | RN  | Usage                |
|--------------|--------|----------------|-----|----------------------|
| `radius-xs`  | 4px    | `rounded-sm`   | 4   | Inputs, tags         |
| `radius-sm`  | 8px    | `rounded-md`   | 8   | Buttons, cards       |
| `radius-md`  | 12px   | `rounded-lg`   | 12  | Modals, sheets       |
| `radius-lg`  | 16px   | `rounded-xl`   | 16  | Feature cards        |
| `radius-full`| 9999px | `rounded-full` | 999 | Avatars, pills, FABs |

### Expo spacing.ts
```typescript
// src/theme/spacing.ts
export const spacing = {
  xs: 4, sm: 8, md: 12, lg: 16, xl: 24, '2xl': 32, '3xl': 48,
} as const;
```

---

## COMPONENT REGISTRY
# Check this before building ANY component.
# If it exists, import it. Do not rebuild it.

| Component      | Path                         | Variants                       | Platform    | Status |
|----------------|------------------------------|--------------------------------|-------------|--------|
| Button         | {{PATH}}                     | primary, secondary, ghost, dest| Both        | TODO   |
| Card           | {{PATH}}                     | default, elevated, flat        | Both        | TODO   |
| Input          | {{PATH}}                     | default, error, disabled       | Both        | TODO   |
| Badge          | {{PATH}}                     | success, warning, error, info  | Both        | TODO   |
| Avatar         | {{PATH}}                     | sm, md, lg, with-badge         | Both        | TODO   |
| BottomSheet    | {{PATH}}                     | default, tall                  | Expo only   | TODO   |
| Modal          | {{PATH}}                     | default, fullscreen            | Next.js only| TODO   |
| Skeleton       | {{PATH}}                     | line, card, avatar             | Both        | TODO   |
| EmptyState     | {{PATH}}                     | default                        | Both        | TODO   |
| {{COMPONENT}}  | {{PATH}}                     | {{VARIANTS}}                   | {{PLATFORM}}| TODO   |

---

## UI BUILD SEQUENCE
# Follow this order for every screen or page. No skipping.

1. **Layout shell** -- SafeAreaView (Expo) or page wrapper (Next.js). Background applied.
2. **Navigation** -- Tab bar / header (Expo) or nav component (Next.js).
3. **Screen structure** -- ScrollView or flex container. Spacing from spacing.ts / Tailwind.
4. **Check Component Registry** -- confirm component doesn't exist before building.
5. **Build or import components** -- use registry. Build new only if missing.
6. **Apply tokens only** -- no raw hex, no arbitrary Tailwind values.
7. **Responsive / platform behavior** -- breakpoint rules (Next.js) or Platform.select (Expo).
8. **Loading state** -- skeleton screen. Spinner only on button actions.
9. **Empty state** -- icon + message + CTA. Never a blank screen.
10. **Error state** -- status-error color, clear message, retry action.
11. **Register new components** -- update Component Registry before committing.

---

## RESPONSIVE BEHAVIOR (Next.js)
Mobile-first. All components start at mobile width. Desktop is override.

| Pattern         | Mobile                  | md (768px+)          | lg (1024px+)         |
|-----------------|-------------------------|----------------------|----------------------|
| Navigation      | Bottom tab bar          | Side rail            | Full sidebar         |
| Card grid       | 1 column                | 2 columns            | 3 columns            |
| Form layout     | Stacked full-width      | Stacked full-width   | 2-column grid        |
| Modal           | Bottom sheet            | Centered dialog      | Centered dialog      |
| {{PATTERN}}     | {{MOBILE}}              | {{TABLET}}           | {{DESKTOP}}          |

---

## PLATFORM GUARDS (Expo)

```typescript
import { Platform } from 'react-native';

// Shadow
const shadow = Platform.select({
  ios: { shadowColor: '#000', shadowOffset: { width: 0, height: 2 },
         shadowOpacity: 0.08, shadowRadius: 8 },
  android: { elevation: 4 },
});

// KeyboardAvoidingView
behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
```

**Rules:**
- iOS shadow: `shadowColor/Offset/Opacity/Radius` only. Never `elevation`.
- Android shadow: `elevation` only. Never shadow props.
- Touch targets: minimum 44x44pt on both platforms.
- Keyboard: `padding` iOS, `height` Android.
- Status bar: set explicitly per screen, never rely on default.

---

## ANIMATION CONTRACT

**Philosophy:** {{RESTRAINED | EXPRESSIVE | FUNCTIONAL-ONLY}}

| Animation        | Duration | Easing       | Trigger                         |
|------------------|----------|--------------|---------------------------------|
| Screen enter     | 300ms    | ease-out     | Route push                      |
| Screen exit      | 200ms    | ease-in      | Route pop                       |
| Modal/sheet open | 250ms    | ease-out     | Sheet mount                     |
| Button press     | 100ms    | ease-in-out  | Scale 0.97 on press             |
| Skeleton pulse   | 1200ms   | loop         | Loading state                   |
| {{ANIMATION}}    | {{MS}}   | {{EASING}}   | {{TRIGGER}}                     |

**Never animate:** Tab icons, form labels, error messages, data table rows.
**Reduced motion:** Always provide static fallback. Respect `prefers-reduced-motion`.

### Text Layout Performance (Next.js only)
For any component where text height, line count, or wrapping is computed dynamically
(chat bubbles, AI streaming output, editorial layouts, dense dashboards) -- check
TECH_STACK.md Optional Web Extensions for Pretext before using `getBoundingClientRect`
or `offsetHeight`. Pretext is the correct tool when text layout is in the hot render path.
Never use Pretext in Expo/React Native -- Canvas API is not available.

---

## DESIGN DECISION LOG
# Every decision made gets logged here. Prevents re-litigating in future sessions.

| Date     | Decision                                  | Rationale                                    | Who     |
|----------|-------------------------------------------|----------------------------------------------|---------|
| {{DATE}} | Primary CTA: {{COLOR}}                    | Pulled from {{REFERENCE}}, warm and direct   | Brian   |
| {{DATE}} | Display font: {{FONT}}                    | Editorial feel, reference used serif display | Claude  |
| {{DATE}} | No dark mode v1.0                         | Out of scope, adds complexity                | Brian   |
| {{DATE}} | {{DECISION}}                              | {{RATIONALE}}                                | {{WHO}} |

---

## WHAT WE ARE NOT
Hard stops. Claude must not drift toward these.

- No purple gradients on white backgrounds
- No Inter or Roboto as primary typeface
- No generic white-card-with-drop-shadow SaaS layouts
- No spinners as primary loading state (skeletons only)
- {{ADD_PROJECT_SPECIFIC_ANTI_PATTERNS}}
