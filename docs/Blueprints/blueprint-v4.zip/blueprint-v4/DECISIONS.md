# DECISIONS.md — Architectural Decision Log
# {{APP_NAME}}
# Last updated: {{DATE}}
#
# PURPOSE: Every significant architectural decision is logged here with
# the reasoning, alternatives considered, and result.
# Claude reads this before making any decision that could conflict with prior ones.
#
# RULE: Log decisions when made, not after.
# RULE: Never delete decisions -- mark as SUPERSEDED if overridden.
# RULE: If a decision is revisited, log a new entry that references the old one.
# RULE: The result field is filled in after the decision plays out.

---

## Decision Index

| ID | Date | Area | Decision | Status | Result |
|----|------|------|----------|--------|--------|
| DEC-001 | {{DATE}} | Template | Project initialized | ACTIVE | -- |

---

## DEC-001 — Project Initialized
**Date:** {{DATE}}
**Gate:** v0.0.0
**Area:** Foundation
**Status:** ACTIVE

**Context:** Blueprint v3 initialized for {{APP_NAME}}.

**Decision:** Build with Blueprint v3 methodology using all 13 foundation files,
full skill stack, and harness architecture.

**Alternatives considered:** None at initialization.

**Rationale:** Blueprint v3 is the current methodology standard.

**Result:** TBD

---

## Decision Entry Template

## DEC-[NNN] — [SHORT TITLE]
**Date:** {{DATE}}
**Gate:** v[X.X.X]
**Area:** Architecture / Database / Auth / AI / Frontend / Cost / Security / UX
**Status:** ACTIVE / SUPERSEDED / DEFERRED

**Context:**
[What situation prompted this decision]

**Decision:**
[What was decided -- be specific]

**Alternatives considered:**
- Option A: [description] -- [why rejected]
- Option B: [description] -- [why rejected]

**Rationale:**
[Why this option was chosen]

**Tradeoffs:**
[What you gave up to get this]

**Impact:**
- Files affected: [list]
- Gates affected: [list]
- Cost implication: [if any]

**Result:** [Filled in after the decision plays out -- did it work?]

---

## Decision Categories
To filter DECISIONS.md by area:

**Architecture:** Stack choices, framework decisions, deployment targets
**Database:** Schema, migrations, ORM, vector config
**Auth:** Provider, session management, OAuth
**AI:** Model selection, agent architecture, prompt strategy, embedding
**Frontend:** UI framework, state management, component library
**Cost:** Cost ceiling, tier decisions, model routing
**Security:** Auth approach, RLS, env var handling
**UX:** Conversation UI, feature gates, freemium design
