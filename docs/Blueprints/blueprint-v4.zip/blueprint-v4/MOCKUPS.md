# MOCKUPS.md — Screen Mockup Registry
# {{APP_NAME}}
# Last updated: {{DATE}}
#
# PURPOSE: Track approval status of every screen mockup before frontend work begins.
# Claude Code reads this file before building any UI component.
# No screen gets built without an APPROVED entry here.
#
# RULE: Mockup must be APPROVED before any component work starts on that screen.
# RULE: If design drifts from approved mockup, update mockup and re-approve.
# RULE: MOCKUP_DRIFT entries are treated as regressions -- fix immediately.
# RULE: This file is populated during the Mockup Approval phase of /build-rules.

---

## Mockup Status Summary

| Screen | Route | Mockup File | Status | Approved By | Date |
|--------|-------|-------------|--------|-------------|------|
| {{SCREEN_NAME}} | {{ROUTE}} | mockups/{{FILENAME}}.png | PENDING | -- | -- |

Status options: PENDING / IN_REVIEW / APPROVED / DRIFT / DEPRECATED

---

## Screen Registry

### SCREEN-001: {{SCREEN_NAME}}
**Route:** `{{ROUTE}}`
**Status:** PENDING
**Mockup file:** `mockups/{{FILENAME}}.png`
**Description:** {{WHAT_THIS_SCREEN_DOES}}

**Key components:**
- {{COMPONENT_1}}
- {{COMPONENT_2}}

**Design tokens used:**
- Colors: {{COLOR_TOKENS}}
- Typography: {{FONT_TOKENS}}
- Spacing: {{SPACING_NOTES}}

**Responsive behavior:**
- Desktop: {{DESKTOP_NOTES}}
- Mobile: {{MOBILE_NOTES}}

**Approval status:** PENDING
**Approved by:** --
**Approved date:** --
**Notes:** --

---

## Drift Log
When built UI diverges from approved mockup, log it here.
Drift = regression. Fix it or update the mockup and re-approve.

| ID | Date | Screen | What Drifted | Resolution | Status |
|----|------|--------|-------------|------------|--------|
| DRIFT-001 | {{DATE}} | {{SCREEN}} | {{DESCRIPTION}} | {{HOW_FIXED}} | OPEN/CLOSED |

---

## Mockup Generation Process
When a screen needs a mockup:

1. Run `/build-rules mockup` or describe the screen to Claude
2. Claude generates an HTML mockup using DESIGN_SYSTEM.md tokens
3. Brian reviews and provides feedback
4. Iterate until approved
5. Mark status APPROVED in this file
6. Commit the mockup file to `mockups/` directory
7. Frontend work on that screen can now begin

## Mockup File Naming Convention
```
mockups/
  v[VERSION]-[SCREEN_NAME]-desktop.html
  v[VERSION]-[SCREEN_NAME]-mobile.html
  v[VERSION]-[SCREEN_NAME]-approved.png  (screenshot of final approved mockup)
```

---

## Phase Gate Integration
- DESIGN_SYSTEM.md Phase 1 must be complete before any mockups are created
- All screens in the current gate must be APPROVED before gate can close
- DRIFT entries block gate close until resolved
