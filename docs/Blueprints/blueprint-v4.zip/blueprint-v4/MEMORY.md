# MEMORY.md — Cross-Session Learning Log
# {{APP_NAME}}
# Last updated: {{DATE}}
#
# PURPOSE: Institutional memory of HOW this project is built.
# Not a task log (that's PLANS.md).
# Not an error log (that's ERRORS.md).
# Not a decision log (that's DECISIONS.md).
#
# This file captures non-obvious discoveries, patterns, and learnings
# that make every future session smarter than the last.
# Claude writes to this file at the end of every session.
# Claude reads this file at the start of every session (in boot sequence).
#
# RULE: Every entry must be a genuine insight -- not a task summary.
# RULE: If it's obvious, it doesn't belong here.
# RULE: If it's already in ERRORS.md or DECISIONS.md, don't duplicate it.
# RULE: Entries should change how Claude approaches future work on this project.

---

## HOW CLAUDE USES THIS FILE

At session start: Read all entries. Let them inform approach silently.
At session end: Add 1-3 new entries if genuine learnings occurred.
During /health check: Cross-reference entries against current project state.

Entry format:
- One sentence: what was learned
- One sentence: why it matters for future sessions
- Tag: [ARCHITECTURE] [PATTERN] [GOTCHA] [PERFORMANCE] [COST] [UX] [AGENT] [DATABASE]

---

## LEARNING LOG

### Session: {{DATE}} | Gate: v0.0.0 | Author: Claude

**[INITIALIZED]**
MEMORY.md created. No learnings yet -- first session.
Future Claude: read all entries below before doing anything else.

---

## PATTERN LIBRARY
# Patterns discovered across multiple sessions on this project.
# More valuable than single-session observations.

| Pattern | Observed | Implication |
|---------|----------|-------------|
| {{PATTERN}} | {{N}} times | {{WHAT TO DO DIFFERENTLY}} |

---

## CROSS-FILE CONNECTIONS
# Non-obvious relationships between project files and decisions
# that Claude should keep in mind.

| If you touch... | Also check... | Because... |
|----------------|---------------|------------|
| CONTRACT.md (model) | COSTS.md projections | Model change affects all cost estimates |
| TECH_STACK.md | HARNESS.md tool registry | Stack changes may require new tools |
| COUNCIL_AGENTS.md | HARNESS.md permissions | Agent changes need permission updates |
| DATABASE schema | ERRORS.md migration history | Past migration failures are instructive |

---

## WHAT WORKS ON THIS PROJECT
# Approaches that have proven effective -- remember to repeat them.

- {{APPROACH}}: {{WHY IT WORKS}}

---

## WHAT DOESN'T WORK ON THIS PROJECT
# Approaches that consistently fail -- don't try them again.

- {{APPROACH}}: {{WHY IT FAILS}} | First observed: {{DATE}}

---

## OPEN QUESTIONS
# Things Claude noticed but couldn't resolve -- flag for future sessions.

| Question | Raised | Resolved | Answer |
|----------|--------|----------|--------|
| {{QUESTION}} | {{DATE}} | NO | — |
