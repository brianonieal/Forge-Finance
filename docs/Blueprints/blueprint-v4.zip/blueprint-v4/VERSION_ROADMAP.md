# TRAILWAI — VERSION ROADMAP
# Blueprint v4 | April 2026
# Owner: Brian Onieal

## Version Philosophy
Trailwai is built in three layers: methodology engine first,
AI integration second, frontend product third. Every gate must
pass before the next opens. No exceptions.

---

## Gate Structure

### v0.0.0 — Foundation
Deliverables:
  - All 16 blueprint files populated
  - Monorepo initialized: Next.js 15 (frontend) + FastAPI (backend)
  - Supabase project created, env vars confirmed
  - FRONTEND_SPEC.md complete and approved
  - LiteLLM configured with Qwen 2.5 Coder 32B (free) + Claude Sonnet 4.6 (paid)
  - GitHub repo initialized and connected
  - agnix: PASS
Gate criteria: Dev server starts, DB connects, all files complete, FRONTEND_SPEC.md approved
Tests: 0
Duration estimate: 4 hours

### v0.1.0 — Scaffold
Deliverables:
  - Frontend: Next.js App Router structure, Tailwind config, design tokens
  - All routes stubbed: landing, auth, dashboard, projects, gates, settings, profile
  - Backend: FastAPI app structure, routers stubbed, health endpoint
  - Supabase schema: users, projects, gates, messages, files, sessions tables
  - Alembic migrations initialized
  - All shared components scaffolded (Button, Input, Modal, Toast, etc.)
Gate criteria: All routes render without errors, DB schema created, health endpoint 200
Tests: 12
Duration estimate: 6 hours

### v0.2.0 — Auth + Onboarding
Deliverables:
  - Google OAuth via Supabase Auth
  - Magic link email login
  - Protected routes and session management
  - Onboarding flow: 4-step wizard
  - User profile created on first login
  - useAuthStore wired to Supabase session
Gate criteria: Full auth flow works, onboarding completes, profile created in DB
Tests: 28
Duration estimate: 5 hours

### v0.3.0 — Landing Page + Marketing
Deliverables:
  - Landing page: LandingNav, HeroSection, HowItWorks, Differentiators
  - PricingSection: Free (Explorer) + Pro (Builder) tiers
  - Footer with links
  - SEO meta tags on all pages
  - Mobile responsive: all breakpoints tested
  - Waitlist email capture
Gate criteria: Landing page renders correctly on desktop/tablet/mobile, Lighthouse > 90
Tests: 35
Duration estimate: 5 hours

### v0.4.0 — Dashboard Shell + Navigation
Deliverables:
  - TopNav: project selector, model indicator, status dot, notifications
  - Sidebar: navigation, project list, usage meter
  - Main layout: TopNav + Sidebar + content area
  - Left panel + Right panel: resizable split layout
  - Tab systems: Build/Research/Decisions/Logs (left) + Preview/Gates/Files/Costs (right)
  - All tabs render correct empty states
  - useUIStore wired to all UI state
Gate criteria: Full dashboard layout renders, tabs switch correctly, resize works
Tests: 48
Duration estimate: 7 hours

### v0.5.0 — Chat + Build Interface
Deliverables:
  - ChatMessage component: AI, User, System variants
  - MessageList with auto-scroll
  - InterrogationCard: form questions + text input + multi-select
  - InputArea with auto-resize textarea
  - ThinkingIndicator animation
  - SSE streaming from backend: /api/build/stream/{id}
  - useBuildStore wired to message stream
  - Build session creation: POST /api/build/start
Gate criteria: Full chat flow works, streaming displays tokens, interrogation cards function
Tests: 68
Duration estimate: 8 hours

### v0.6.0 — AI Integration (Qwen + Claude)
Deliverables:
  - LiteLLM router: Qwen 2.5 Coder 32B (free tier) + Claude Sonnet 4.6 (paid)
  - Model selection based on user tier (pulled from Supabase user record)
  - Cost tracking per session: token counting, cost per model
  - Cost ceiling enforcement: $0.50/session default (configurable)
  - Haiku fallback for routing/classification tasks
  - AI response parsing and structured output
  - Error handling: model failure, timeout, cost ceiling hit
Gate criteria: Both models respond correctly, cost tracked, fallback works, ceiling enforced
Tests: 92
Duration estimate: 8 hours

### v0.7.0 — Live Preview Window
Deliverables:
  - PreviewFrame: iframe with sandboxed HTML/CSS rendering (v1.0.0 scope)
  - DeviceToggle: Desktop / Tablet / Mobile with correct iframe widths
  - Preview refresh on build update event
  - Loading skeleton during iframe load
  - Error state with retry
  - Preview URL display
  - Open in new tab
Gate criteria: HTML/CSS renders in iframe, device toggle changes width correctly
Tests: 108
Duration estimate: 6 hours

### v0.8.0 — Gate Progress Dashboard
Deliverables:
  - GateCard component with status, progress bar, task checklist
  - GateTimeline: visual roadmap, current gate pulsing
  - GateBadge: COMPLETE / IN_PROGRESS / PENDING / BLOCKED variants
  - Stats row: Tests, Security, Performance, Hours
  - Gate advancement: POST /api/build/gate/advance
  - Gate completion animation: checkmark + subtle confetti
  - GateRoadmapPage: /gates route with full project timeline
Gate criteria: Gate progress displays correctly, advancement works, animations fire
Tests: 128
Duration estimate: 7 hours

### v0.9.0 — Files + Costs + Projects List
Deliverables:
  - FileTree: collapsible directory tree of generated files
  - CodeViewer: Shiki syntax highlighting, copy button, language badge
  - File download: individual files + ZIP
  - CostCard: current build cost, monthly cost, projected
  - UsageChart: Recharts line + bar charts
  - CostBreakdown: per-model, per-agent breakdown
  - ProjectsPage: /projects with search, filter, sort
  - ProjectCard: name, description, gate badge, progress bar
  - NewProjectFlow: /projects/new 4-step wizard
  - useProjectStore wired to all project state
Gate criteria: All three tabs functional, file download works, projects list renders
Tests: 152
Duration estimate: 9 hours

### v1.0.0 — Genesis (Public Launch)
Deliverables:
  - Profile page: stats, recent activity, achievements placeholder
  - Settings page: all 6 sections functional
  - GitHub integration: repo picker (same UX as Claude Code)
  - Stripe integration: subscription billing, Free / Pro tiers
  - Email notifications (Resend): gate completed, build errors, weekly summary
  - Waitlist converted to signup flow
  - Full mobile responsive audit: every screen tested
  - Accessibility audit: keyboard nav, ARIA, contrast
  - Error boundaries on all major components
  - Deploy to production: Vercel (frontend) + Render (backend)
  - Custom domain: trailwai.com
  - Client handoff: /handoff generates docs
Gate criteria: All screens functional, Stripe live, deployed, domain connected,
               Lighthouse > 90, 0 CRITICAL/HIGH security findings,
               0 CRITICAL/HIGH performance findings
Tests: 180
Duration estimate: 12 hours

### v2.0.0 — Horizon
Deliverables:
  - React component preview: server-side render → HTML injection into iframe
  - Research tab: RESEARCH.md rendered as interactive competitor cards
  - Decisions tab: DECISIONS.md as filterable timeline
  - Collaboration: share project with read access
  - Build history: revert to any gate
  - Webhook support for GitHub events
Tests: 218
Duration estimate: 20 hours

### v3.0.0 — Compass
Deliverables:
  - Full WebContainer interactive preview (Stackblitz integration)
  - Multi-agent support: user can choose agent count and roles
  - Custom model: BYOK (bring your own API key)
  - Public project gallery: showcase shipped apps
  - Template library: start from industry-specific templates
Tests: 260
Duration estimate: 30 hours

---

## Summary

| Gate | Name | Tests | Hours |
|------|------|-------|-------|
| v0.0.0 | Foundation | 0 | 4 |
| v0.1.0 | Scaffold | 12 | 6 |
| v0.2.0 | Auth + Onboarding | 28 | 5 |
| v0.3.0 | Landing Page | 35 | 5 |
| v0.4.0 | Dashboard Shell | 48 | 7 |
| v0.5.0 | Chat + Build Interface | 68 | 8 |
| v0.6.0 | AI Integration | 92 | 8 |
| v0.7.0 | Live Preview | 108 | 6 |
| v0.8.0 | Gate Progress | 128 | 7 |
| v0.9.0 | Files + Costs + Projects | 152 | 9 |
| v1.0.0 | Genesis | 180 | 12 |
| v2.0.0 | Horizon | 218 | 20 |
| v3.0.0 | Compass | 260 | 30 |

**Total to v1.0.0: 77 hours (~$11,550 at $150/hr)**
**Total to v3.0.0: 127 hours (~$19,050 at $150/hr)**

---

## Explicit Out of Scope for v1.0.0

- Full WebContainer interactive preview (v3.0.0)
- Mobile app (Expo/React Native) -- web only
- Collaboration / team features (v2.0.0)
- Build history / revert (v2.0.0)
- Custom model BYOK (v3.0.0)
- Public gallery (v3.0.0)
- Template library (v3.0.0)
- i18n / multiple languages
- Native mobile push notifications
