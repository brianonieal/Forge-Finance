# HARNESS.md — Agent Harness Architecture
# {{APP_NAME}} | Informed by Claude Code v2.1.88 architectural patterns

## The Agent Loop (Canonical)
```
User --> messages[] --> LLM --> response
         ^                         |
         |              stop_reason == tool_use?
         |                /               \
         |              YES                NO
         |         execute tools        return text
         |         append results
         +-------- loop back
```
This loop is the foundation. Everything below layers on top of it.

## Harness Layers Active in This Project
Mark applicable layers:

- [ ] s01: TOOL REGISTRY -- Discrete permission-gated tools. See COUNCIL_AGENTS.md for per-agent tool lists.
- [ ] s02: PARALLEL EXECUTION -- Writer/Reviewer pattern. Separate Claude invocations for write vs review.
- [ ] s03: PLAN-THEN-EXECUTE -- Agent must produce a plan and receive approval before coding begins.
- [ ] s04: SUBAGENT ISOLATION -- Each subagent spawned with fresh messages[]. No context bleed from parent.
- [ ] s05: KNOWLEDGE ON DEMAND -- Extended docs loaded via @imports only when task requires them.
- [ ] s06: CONTEXT COMPRESSION -- Compact at 50% context fill max. Never wait for auto-compact.
- [ ] s07: PERSISTENT TASKS -- File-based task graph in PLANS.md with status, dependencies, and order.
- [ ] s08: BACKGROUND TASKS -- Long-running ops (migrations, batch jobs) run non-blocking.
- [ ] s09: AGENT TEAMS -- Coordinator agent uses a system prompt as the orchestration algorithm.

## Tool Registry
Define every tool this project uses. Each tool is discrete and permission-gated.

| Tool Name        | Description                    | Permitted Agents        | Requires Approval |
|------------------|--------------------------------|-------------------------|-------------------|
| read_file        | Read any project file          | ALL                     | No                |
| write_file       | Write or create files          | {{PERMITTED_AGENTS}}    | No                |
| run_bash         | Execute shell commands         | {{PERMITTED_AGENTS}}    | Destructive: Yes  |
| query_db         | Read database                  | {{PERMITTED_AGENTS}}    | No                |
| mutate_db        | Write to database              | {{PERMITTED_AGENTS}}    | Yes               |
| call_api         | External API calls             | {{PERMITTED_AGENTS}}    | No                |
| spawn_subagent   | Fork a subagent                | COORDINATOR only        | No                |
| web_search       | Search the web                 | {{PERMITTED_AGENTS}}    | No                |

## Context Management Strategy
- **Compact trigger:** 50% context window fill (do not wait for auto-compact)
- **Compact instruction:** "/compact focus on [current task], list of modified files, current test status"
- **CLAUDE.md standing compact rule:** "When compacting, preserve: modified file list, current test status, active version gate, last error from ERRORS.md"
- **Cache optimization:** Stable content (system prompt, tool definitions) at TOP of context. Volatile content (conversation) at BOTTOM.
- **Session isolation:** Never carry context from one major feature into another. Use /clear between tasks.

## Subagent Spawning Rules
- Coordinator agent spawns workers. Workers NEVER spawn other workers.
- Each worker receives: task description, relevant context slice, tool permissions, completion criteria.
- Workers report back to coordinator. Coordinator synthesizes, never rubber-stamps.
- Coordinator system prompt must include:
  - "Do not rubber-stamp weak work"
  - "You must understand findings before directing follow-up work"
  - "Never hand off understanding to another worker"

## Plan-Then-Execute Protocol (s03)
When enabled, agent MUST:
1. Produce a written plan with: approach, files affected, risk areas, test strategy
2. Pause and wait for human approval
3. Only then begin implementation
4. Flag any deviation from plan before making it

## Permission Gates
Destructive operations require explicit approval:
- Database mutations (INSERT, UPDATE, DELETE, DROP)
- File deletion or overwrite of existing files
- External API calls that cost money or send communications
- Git operations (push, force-push, merge)

## Hooks (settings.json)
Deterministic enforcement -- 100% reliable vs CLAUDE.md's ~80%:
```json
{
  "hooks": {
    "PostToolUse": [
      {
        "matcher": "Edit|Write",
        "hooks": [{ "type": "command", "command": "{{FORMAT_COMMAND}}" }]
      }
    ],
    "PreToolUse": [
      {
        "matcher": "Bash",
        "hooks": [{ "type": "command", "command": "{{SAFETY_CHECK_COMMAND}}" }]
      }
    ]
  }
}
```

## MCP Servers Active
| Server     | URL                        | Purpose                    |
|------------|----------------------------|----------------------------|
| {{MCP_1}}  | {{MCP_URL_1}}              | {{MCP_PURPOSE_1}}          |

## Persistent Task Graph (PLANS.md)
When s07 is active, maintain PLANS.md with:
```
## Active Tasks
- [ ] TASK-001: {{description}} | depends: none | status: pending
- [x] TASK-002: {{description}} | depends: TASK-001 | status: complete

## Completed
- [x] TASK-000: Foundation files | status: complete
```
