# COUNCIL_AGENTS.md — Agent Roster & Orchestration Rules
# {{APP_NAME}}
# Last updated: {{DATE}}
#
# RULE: Every agent in this system is defined here before it is built.
# RULE: Tool permissions listed here are the only tools each agent may call.
# RULE: Coordinator orchestration uses system prompt as algorithm -- not code.
# RULE: Subagents always receive fresh messages[]. No context bleed from parent.
# RULE: Agent names must match CONTRACT.md exactly.

---

## Agent Architecture Type
- [ ] Single agent (one @AGENT handles all tasks)
- [ ] Coordinator + workers (one coordinator, N specialized workers)
- [ ] Pipeline (output of agent A feeds agent B in sequence)
- [ ] Hybrid: {{DESCRIBE}}

---

## Coordinator Agent (if applicable)

### @{{COORDINATOR_NAME}}
**Role:** Orchestrates all worker agents. Synthesizes results. Never rubber-stamps.
**Model:** claude-sonnet-4-6
**Context scope:** Full project context
**Spawns:** All worker agents listed below
**Reports to:** Human / user

**System Prompt Algorithm (embed directly):**
```
You are @{{COORDINATOR_NAME}}, the coordinating agent for {{APP_NAME}}.

Your job is to:
1. Decompose the user's task into discrete subtasks
2. Assign subtasks to the appropriate worker agents
3. Synthesize their outputs critically -- do not rubber-stamp weak work
4. You must understand each worker's findings before directing follow-up work
5. Never hand off understanding to another worker -- maintain comprehension yourself
6. Report a clear, consolidated result to the user

Available workers: {{LIST_WORKER_AGENTS}}
Task assignment rules: {{ASSIGNMENT_RULES}}
Escalation: If a worker produces low-quality output, retry with clearer instructions before reporting failure.
```

**Permitted tools:**
- spawn_subagent
- read_file
- web_search (for research tasks)

---

## Worker Agents

### @{{AGENT_1_NAME}}
**Role:** {{ROLE_DESCRIPTION}}
**Model:** {{MODEL}}
**Context scope:** {{WHAT_CONTEXT_IT_RECEIVES}}
**Spawned by:** @{{COORDINATOR_NAME}}
**Receives:** Fresh messages[] with task-specific context only

**System Prompt:**
```
You are @{{AGENT_1_NAME}} for {{APP_NAME}}.
Your ONLY responsibility: {{SINGLE_CLEAR_RESPONSIBILITY}}
You have access to the following tools: {{TOOL_LIST}}
You do NOT have access to: {{EXCLUDED_TOOLS}}
When your task is complete, output: {{OUTPUT_FORMAT}}
```

**Permitted tools:**
- read_file
- {{TOOL_2}}
- {{TOOL_3}}

**NOT permitted:**
- spawn_subagent
- mutate_db (unless explicitly listed above)
- run_bash (unless explicitly listed above)

---

### @{{AGENT_2_NAME}}
**Role:** {{ROLE_DESCRIPTION}}
**Model:** {{MODEL}}
**Context scope:** {{WHAT_CONTEXT_IT_RECEIVES}}
**Spawned by:** @{{COORDINATOR_NAME}}
**Receives:** Fresh messages[] with task-specific context only

**System Prompt:**
```
You are @{{AGENT_2_NAME}} for {{APP_NAME}}.
Your ONLY responsibility: {{SINGLE_CLEAR_RESPONSIBILITY}}
You have access to the following tools: {{TOOL_LIST}}
Output format: {{OUTPUT_FORMAT}}
```

**Permitted tools:**
- read_file
- {{TOOL_2}}

**NOT permitted:**
- spawn_subagent
- All destructive operations

---

## Single Agent Template (if architecture is single agent)

### @{{AGENT_NAME}}
**Role:** Full-stack agent handling all user tasks
**Model:** claude-sonnet-4-6
**Context scope:** Full project context via CLAUDE.md boot sequence

**System Prompt:**
```
You are @{{AGENT_NAME}}, the AI assistant for {{APP_NAME}}.

Core responsibilities:
- {{RESPONSIBILITY_1}}
- {{RESPONSIBILITY_2}}
- {{RESPONSIBILITY_3}}

Behavioral rules:
- Always read CONTRACT.md before touching config values
- Always check ERRORS.md at session start
- Compact context at 50% fill
- When you make a mistake, add it to ERRORS.md before moving on

You have access to: {{TOOL_LIST}}
```

**Permitted tools:** ALL (single agent pattern -- no restriction)

---

## Agent Communication Protocol
- Coordinator to worker: Structured task object `{ task_id, description, context_slice, tools, completion_criteria }`
- Worker to coordinator: Structured result `{ task_id, status, output, confidence, issues }`
- Escalation path: Worker -> Coordinator -> Human (for destructive ops approval)

## Tool Permission Matrix

| Tool           | @COORDINATOR | @AGENT_1 | @AGENT_2 | Notes                        |
|----------------|-------------|----------|----------|------------------------------|
| read_file      | YES         | YES      | YES      | All agents can read          |
| write_file     | NO          | YES      | NO       | Worker 1 only                |
| run_bash       | NO          | YES      | NO       | Approval required for destr. |
| query_db       | YES         | YES      | YES      | Read-only for all            |
| mutate_db      | NO          | YES      | NO       | Approval required            |
| call_api       | YES         | YES      | YES      | Rate limits apply            |
| spawn_subagent | YES         | NO       | NO       | Coordinator only             |
| web_search     | YES         | YES      | YES      |                              |

---

## Writer/Reviewer Pattern (when s02 harness layer is active)
When code quality reviews are needed, use two separate invocations:
1. **Writer agent** -- implements the feature
2. **Reviewer agent** -- fresh messages[], reviews without bias (never saw the Writer's context)
3. Writer incorporates review feedback
4. Ship only after Reviewer approves

This mirrors the Claude Code internal pattern: fresh context improves review quality.

---

## Agent Versioning
When agent prompts change significantly, log it:
| Agent              | Version | Date       | Change Summary                  |
|--------------------|---------|------------|---------------------------------|
| @{{AGENT_NAME}}    | v1.0    | {{DATE}}   | Initial definition              |
