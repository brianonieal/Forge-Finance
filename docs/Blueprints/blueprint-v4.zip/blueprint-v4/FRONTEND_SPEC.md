# FRONTEND_SPEC.md — Trailwai Frontend Specification
# Blueprint v4 | Trailwai (trailwai.com)
# Version: 1.0 | April 2026
#
# PURPOSE: Complete UI/UX specification for the Trailwai web app.
# Claude Code reads this before building any frontend component.
# Every screen, component, interaction, and state is defined here.
# Deviation from this spec is a regression.
#
# RULE: Read this file completely before writing any UI code.
# RULE: If a component isn't in this spec, stop and ask Brian.
# RULE: Match component names exactly -- no renaming.
# RULE: Match interaction patterns exactly -- no improvising.

---

## PRODUCT OVERVIEW

**Trailwai** is a guided AI app builder that takes any user -- beginner
to expert -- from a raw idea to a shipped, production-quality app using
a structured, gated methodology.

**Core experience:** The user describes their idea. Trailwai guides them
through smart questions, makes intelligent recommendations with cost
breakdowns, and an AI engine builds the app in the background while a
live dashboard shows progress through gates in real time.

**What makes it different from Lovable/Bolt/v0:**
- Structured gates -- nothing ships without passing criteria
- Competitive research built into the process before any code
- Decision logging with full traceability
- Cost intelligence -- knows what each choice costs before you commit
- Professional output -- proposal, contract, handoff docs generated
- Accessible to beginners AND powerful for experts

---

## DESIGN PHILOSOPHY

**Feeling:** Space explorer and artist creating something new.
Every user should feel like they are blazing a trail through
uncharted territory toward something they built themselves.

**Tone:** Dark, premium, focused. Not playful, not corporate.
Think command center meets creative studio.

**Influence:** Claude Code terminal aesthetics + Lovable's
guided conversational flow + Linear's clean information hierarchy.

---

## DESIGN TOKENS

### Colors
```
--bg-primary:      #0A0B0E    /* Near-black main background */
--bg-secondary:    #12141A    /* Card and panel backgrounds */
--bg-tertiary:     #1A1D26    /* Elevated surfaces, modals */
--bg-hover:        #1F2230    /* Hover states */

--border-subtle:   #1E2130    /* Subtle dividers */
--border-default:  #2A2E40    /* Standard borders */
--border-active:   #3D4460    /* Active/focused borders */

--text-primary:    #F0F2FF    /* Primary text */
--text-secondary:  #8B92B8    /* Secondary, labels */
--text-muted:      #4A5080    /* Placeholders, disabled */
--text-inverse:    #0A0B0E    /* Text on light backgrounds */

--accent-primary:  #6C63FF    /* Purple -- primary actions */
--accent-hover:    #7B73FF    /* Hover state for primary */
--accent-glow:     rgba(108, 99, 255, 0.15)  /* Glow effect */

--success:         #4ECCA3    /* Gate passed, complete */
--success-bg:      rgba(78, 204, 163, 0.1)
--warning:         #FFB74D    /* Warnings, in progress */
--warning-bg:      rgba(255, 183, 77, 0.1)
--error:           #FF6B6B    /* Errors, blocked */
--error-bg:        rgba(255, 107, 107, 0.1)
--info:            #4FC3F7    /* Info, pending */
--info-bg:         rgba(79, 195, 247, 0.1)

--gradient-primary: linear-gradient(135deg, #6C63FF 0%, #4ECCA3 100%)
--gradient-subtle:  linear-gradient(135deg, #1A1D26 0%, #12141A 100%)
```

### Typography
```
--font-display:   'Space Grotesk', sans-serif   /* Headers, brand */
--font-body:      'Inter', sans-serif            /* Body text, UI */
--font-mono:      'JetBrains Mono', monospace    /* Code, terminal */

/* Scale */
--text-xs:    11px / 1.4
--text-sm:    13px / 1.5
--text-base:  15px / 1.6
--text-lg:    17px / 1.5
--text-xl:    20px / 1.4
--text-2xl:   24px / 1.3
--text-3xl:   30px / 1.2
--text-4xl:   38px / 1.1
```

### Spacing
```
--space-1:  4px
--space-2:  8px
--space-3:  12px
--space-4:  16px
--space-5:  20px
--space-6:  24px
--space-8:  32px
--space-10: 40px
--space-12: 48px
--space-16: 64px
```

### Radius
```
--radius-sm:  4px
--radius-md:  8px
--radius-lg:  12px
--radius-xl:  16px
--radius-full: 9999px
```

### Shadows
```
--shadow-sm:  0 1px 3px rgba(0,0,0,0.4)
--shadow-md:  0 4px 12px rgba(0,0,0,0.5)
--shadow-lg:  0 8px 32px rgba(0,0,0,0.6)
--shadow-glow: 0 0 20px rgba(108, 99, 255, 0.2)
```

---

## APPLICATION LAYOUT

### Master Layout (authenticated)
```
┌─────────────────────────────────────────────────────┐
│  TOPNAV (56px fixed)                                │
├──────────┬──────────────────────────────────────────┤
│          │                                          │
│ SIDEBAR  │  MAIN CONTENT AREA                       │
│ (240px   │  (flex-1, scrollable)                    │
│  fixed)  │                                          │
│          │                                          │
└──────────┴──────────────────────────────────────────┘
```

### Layout on mobile (<768px)
- Topnav: stays visible, hamburger replaces sidebar links
- Sidebar: slides in as drawer overlay, 280px wide
- Main content: full width

---

## SCREEN 1 -- LANDING PAGE (unauthenticated)

**Route:** `/`
**Gate:** v1.0.0
**Status:** public, no auth required

### Purpose
Convert visitors into registered users. Communicate the value
proposition in under 10 seconds. Make beginners feel welcome
and experts feel respected simultaneously.

### Layout
```
┌─────────────────────────────────────────────────────┐
│  LANDING NAV                                        │
├─────────────────────────────────────────────────────┤
│                                                     │
│  HERO SECTION                                       │
│  (full viewport height)                             │
│                                                     │
├─────────────────────────────────────────────────────┤
│  HOW IT WORKS (3 steps)                             │
├─────────────────────────────────────────────────────┤
│  DIFFERENTIATORS (vs vibe coding)                   │
├─────────────────────────────────────────────────────┤
│  PRICING                                            │
├─────────────────────────────────────────────────────┤
│  CTA SECTION                                        │
├─────────────────────────────────────────────────────┤
│  FOOTER                                             │
└─────────────────────────────────────────────────────┘
```

### LandingNav component
```
Props: none
Height: 64px
Background: rgba(10, 11, 14, 0.8) -- glassmorphism, backdrop blur
Position: sticky top-0 z-50
Border-bottom: 1px solid var(--border-subtle)

Contents:
  Left: Logo (TrailwaiLogo) + wordmark "Trailwai"
  Center: nav links [How it works] [Pricing] [Docs]
  Right: [Sign In] button (ghost) + [Start Building] button (primary)

Behavior:
  Scrolled > 20px: border-bottom becomes visible with transition
  Mobile: center links hidden, hamburger menu shown
```

### HeroSection component
```
Background: var(--bg-primary) with subtle grid pattern overlay
Min-height: 100vh
Display: flex, center, column

Headline: (--font-display, --text-4xl, --text-primary)
  "Blaze Your Trail."
  "Build Your App."

Subheadline: (--font-body, --text-xl, --text-secondary)
  "From idea to shipped product — guided, gated, and built right.
   For beginners and experts alike."

CTA group:
  Primary button: "Start Building Free" → /register
  Secondary button: "Watch Demo" → opens VideoModal

Below CTA:
  Social proof: "Join [X] builders who shipped real apps"
  Trust badges: "No credit card" | "Free tier available" | "Open source AI"

Hero visual (right side on desktop, below on mobile):
  Live preview window mockup showing the dashboard in action
  Subtle animation: gates lighting up green one by one
  Glow effect: var(--shadow-glow)
```

### HowItWorks component
```
3 steps, horizontal on desktop, vertical on mobile
Each step:
  Number: large gradient number (1, 2, 3)
  Icon: relevant icon from Lucide React
  Title: --font-display, --text-xl
  Description: --font-body, --text-base, --text-secondary

Step 1: "Describe your idea"
  "Tell us what you want to build. No technical knowledge required."

Step 2: "Answer smart questions"
  "Our AI guides you through key decisions with cost recommendations."

Step 3: "Watch it get built"
  "Track progress in real time as your app takes shape, gate by gate."

Connector lines between steps (desktop only)
Animated on scroll into view
```

### PricingSection component
```
2 tiers (v1.0.0), expandable to 3 at v5.0.0

Free tier card:
  Label: "Explorer"
  Price: "$0 / month"
  Model: "Powered by Qwen 2.5 Coder"
  Features list (5 items)
  CTA: "Start for free" → /register

Pro tier card:
  Label: "Builder"
  Price: "$29 / month"
  Badge: "Most Popular"
  Model: "Powered by Claude Sonnet"
  Features list (8 items)
  CTA: "Start building" → /register?plan=pro

Design: Pro card has accent border + glow, slightly elevated
```

---

## SCREEN 2 -- AUTHENTICATION

**Route:** `/login` | `/register`
**Gate:** v0.3.0

### AuthLayout component
```
Full screen, centered
Background: var(--bg-primary) with radial gradient center
Card: var(--bg-secondary), --radius-xl, --shadow-lg
Card width: 400px (desktop), full width - 32px (mobile)

Card contents:
  Logo centered at top
  Heading: "Sign in to Trailwai" / "Create your account"
  Auth options:
    [Google OAuth button] -- primary option
    Divider: "or"
    [Email input]
    [Magic Link button] -- "Send magic link"
  Footer: toggle between login/register
  Legal: "By continuing you agree to our Terms and Privacy Policy"
```

---

## SCREEN 3 -- ONBOARDING FLOW

**Route:** `/onboarding`
**Gate:** v0.3.0
**Trigger:** First login only, then skipped

### OnboardingFlow component
```
Multi-step wizard, 4 steps
Progress indicator: dots at top (4 dots)
Skip button: top right
Back/Next: bottom navigation

Step 1 -- "What's your experience level?"
  3 cards, single select:
  [Beginner] "I'm new to building apps"
  [Developer] "I can code but want structure"
  [Expert] "I want the full Build Rules methodology"

Step 2 -- "What do you want to build?"
  Text area: "Describe your app idea in a sentence or two"
  Examples shown below: chips with "SaaS dashboard",
  "Mobile app", "AI tool", "Internal tool"

Step 3 -- "Connect your GitHub"
  GitHub OAuth button
  Skip option: "I'll connect later"
  Explanation: why GitHub is needed

Step 4 -- "Choose your AI tier"
  2 cards (same as pricing)
  Free: Qwen 2.5 Coder
  Pro: Claude Sonnet
  CTA: "Start building" → /dashboard
```

---

## SCREEN 4 -- DASHBOARD (main app)

**Route:** `/dashboard`
**Gate:** v0.5.0
**This is the primary experience screen.**

### Layout
```
┌─────────────────────────────────────────────────────┐
│  TOPNAV                                             │
├──────────┬──────────────────────────────────────────┤
│          │  ┌─────────────────┬──────────────────┐  │
│ SIDEBAR  │  │                 │                  │  │
│          │  │  LEFT PANEL     │  RIGHT PANEL     │  │
│          │  │  (Chat /        │  (Live Preview / │  │
│          │  │   Interrogation)│   Gate Dashboard) │  │
│          │  │                 │                  │  │
│          │  │  flex: 1        │  flex: 1         │  │
│          │  └─────────────────┴──────────────────┘  │
└──────────┴──────────────────────────────────────────┘
```

### TopNav component
```
Height: 56px
Background: var(--bg-secondary)
Border-bottom: 1px solid var(--border-default)
Position: fixed top-0, full width, z-50

Left:
  Hamburger icon (mobile only)
  Current project name (clickable → project settings)
  Current gate badge: "v0.2.0 Data Layer" (--warning color if in progress)

Center:
  Model indicator: "Qwen 2.5 Coder" or "Claude Sonnet 4.6"
  Status dot: green (active) / yellow (thinking) / grey (idle)

Right:
  [New Project] button -- icon + text
  Notification bell -- badge count if any
  Avatar menu -- profile, settings, billing, sign out
```

### Sidebar component
```
Width: 240px fixed (desktop), drawer (mobile)
Background: var(--bg-secondary)
Border-right: 1px solid var(--border-default)

Top section:
  Project selector dropdown
    Shows: project name, current gate, last active
    [+ New Project] option at bottom

Navigation items (with icons from Lucide):
  [Home] → /dashboard
  [Projects] → /projects
  [Gates] → /gates (gate roadmap view)
  [Decisions] → /decisions
  [Research] → /research
  [Files] → /files (generated project files)
  [Settings] → /settings

Bottom section:
  Usage meter: "[X] / [Y] builds this month"
  Progress bar in accent color
  [Upgrade] link if on free tier

Hover state: bg var(--bg-hover), left border 2px accent
Active state: bg var(--bg-hover), left border 2px accent solid, text primary
```

### LeftPanel -- Chat/Interrogation component
```
Width: 50% of content area (resizable, min 320px)
Background: var(--bg-primary)
Border-right: 1px solid var(--border-default)
Display: flex, column

Header:
  Tab bar: [Build] [Research] [Decisions] [Logs]
  Each tab switches panel content

[Build] tab -- main chat interface:
  MessageList (scrollable, flex-1):
    AIMessage: left aligned, avatar, bg var(--bg-secondary), radius-lg
    UserMessage: right aligned, bg var(--accent-primary), radius-lg
    SystemMessage: centered, small text, muted color
    ThinkingIndicator: animated dots when AI is processing

  InterrogationCard (shown during intake):
    Question text prominently
    Answer options as clickable cards OR text input
    Multiple choice: pill buttons, multi-select support
    Free text: textarea with character count
    Submit button at bottom

  InputArea (fixed bottom):
    Textarea: auto-resize, max 4 lines
    Placeholder: "Describe what you want to build..."
    Left: [Attach] icon
    Right: [Send] button (accent, disabled when empty)
    Model badge below input: "Qwen 2.5 Coder" or "Claude Sonnet"

[Research] tab:
  Shows RESEARCH.md content rendered as cards
  Competitor cards with scores
  Market gap highlights
  Recommendation chips

[Decisions] tab:
  DECISIONS.md rendered as timeline
  Each decision: DEC number, area, decision, status
  Filter by area (Architecture, Database, AI, etc.)

[Logs] tab:
  Build log stream -- monospace font
  Color coded: grey (info), green (success), yellow (warning), red (error)
  Auto-scroll to bottom, pause on hover
```

### RightPanel -- Live Preview/Gate Dashboard component
```
Width: 50% of content area (resizable)
Background: var(--bg-primary)
Display: flex, column

Header:
  Tab bar: [Preview] [Gates] [Files] [Costs]

[Preview] tab -- HTML live preview:
  Toolbar:
    Device toggles: [Desktop] [Tablet] [Mobile]
    [Refresh] icon button
    [Open in new tab] icon button
    URL bar showing preview URL

  PreviewFrame:
    iframe, border: 1px solid var(--border-default)
    Responsive: changes width based on device toggle
    Desktop: full width
    Tablet: 768px centered with margins
    Mobile: 375px centered with margins
    Loading state: skeleton overlay
    Error state: centered error message with retry

  EmptyState (no preview yet):
    Icon: monitor with sparkle
    Text: "Your app preview will appear here as it's built"
    Subtext: "Start by describing your idea in the chat"

[Gates] tab -- Gate progress dashboard:
  GateTimeline component:
    Visual roadmap of all gates
    Current gate: highlighted, pulsing indicator
    Completed gates: green checkmark + completion date
    Future gates: muted, locked icon

  GateCard (for current gate):
    Gate name and version
    Progress bar: X of Y tasks complete
    Task checklist (from SPEC.md):
      Each task: checkbox, description, status
    Passing criteria section
    Time tracked this gate
    Estimated completion

  Stats row (4 metric cards):
    Tests Passing: [X] / [Y]
    Security: PASS / CHECKING / BLOCK
    Performance: PASS / CHECKING / BLOCK
    Hours: [X] hrs / $[Y]

[Files] tab -- Generated project files:
  FileTree component:
    Collapsible directory tree
    File icons by type (tsx, py, md, json, etc.)
    Click to preview file content
    Download individual files
    Download all as ZIP

  FilePreview:
    Code viewer with syntax highlighting (Shiki)
    Line numbers
    Copy button
    Language badge

[Costs] tab -- Cost intelligence:
  CurrentCost card:
    This build: $[X]
    This month: $[X]
    Projected at 100 users: $[X]

  ModelCostBreakdown:
    Input tokens: [X] / Output tokens: [X]
    Cost per session: $[X]
    Recommendation: "Switch to Haiku for routing tasks: save $[X]/month"

  UsageChart:
    Line chart: daily cost over current month
    Bar chart: cost by agent/component
```

---

## SCREEN 5 -- NEW PROJECT FLOW

**Route:** `/projects/new`
**Gate:** v1.0.0

### NewProjectFlow component
```
Full-screen modal OR dedicated page (TBD during mockup phase)

Step 1 -- Project basics:
  Project name input
  One-line description textarea
  Project type chips: [Web App] [Mobile] [API] [AI Tool]
  [Start with research] toggle -- runs /research before interrogation

Step 2 -- Research (if toggled):
  Shows /research results as they stream in
  Competitor cards appearing one by one
  Market gap summary
  [Continue to build] button when complete

Step 3 -- Connect repository:
  GitHub repo picker (same UI as Claude Code screenshot)
  [Create new repo] option
  [Use existing repo] with search
  Skip option

Step 4 -- Model selection:
  Free: Qwen 2.5 Coder
  Pro: Claude Sonnet 4.6
  Shows estimated cost per build

Final: [Start Interrogation] → redirects to /dashboard with project loaded
```

---

## SCREEN 6 -- PROJECTS LIST

**Route:** `/projects`
**Gate:** v1.0.0

### ProjectsPage component
```
Header:
  "Your Projects" (--font-display, --text-3xl)
  [+ New Project] button (primary, top right)

Filter/sort bar:
  Search input
  Filter: [All] [Active] [Complete] [Paused]
  Sort: [Recent] [Name] [Gate]

ProjectGrid:
  3 columns desktop, 2 tablet, 1 mobile
  ProjectCard per project:
    Project name (--font-display, --text-lg)
    Description (--text-sm, --text-secondary, 2-line clamp)
    Current gate badge (colored by status)
    Progress bar (tasks complete %)
    Stats row: Tests | Hours | Last active
    [Open] button on hover overlay
    Context menu: Rename | Archive | Delete

EmptyState (no projects):
  Illustration: empty trail path
  Text: "No projects yet"
  CTA: [Start your first build]
```

---

## SCREEN 7 -- GATE ROADMAP VIEW

**Route:** `/gates`
**Gate:** v1.0.0

### GateRoadmapPage component
```
Full roadmap visualization

Header:
  Project name
  Total progress: [X] / [Y] gates complete
  Time total: [X] hrs / $[Y]

GateRoadmap:
  Vertical timeline on left
  Gate cards expanding to the right

  GateCard (each):
    Gate number + name (v0.2.0 Data Layer)
    Status indicator: COMPLETE / IN_PROGRESS / PENDING / BLOCKED
    Date completed (if done) / estimated (if pending)
    Duration: [X] hrs
    Test count: [X] passing
    Expand/collapse: shows task list, passing criteria, changelog entry

  Connector lines between gates
  Current gate: pulsing glow effect

SummaryPanel (right side, sticky):
  Completion %: large number, gradient fill
  Gates complete: [X] / [Y]
  Tests total: [X] passing
  Total cost: $[X]
  Projected completion: [date estimate]
```

---

## SCREEN 8 -- SETTINGS

**Route:** `/settings`
**Gate:** v1.0.0

### SettingsPage component
```
Sidebar navigation within settings:
  Profile
  AI Models
  GitHub
  Billing
  Notifications
  Danger Zone

Profile section:
  Avatar upload
  Display name
  Email (read-only)
  Experience level (from onboarding, editable)

AI Models section:
  Current tier display
  Free tier: Qwen 2.5 Coder -- model info card
  Paid tier: Claude Sonnet -- upgrade CTA
  API key fields (for BYOK -- bring your own key)
  Cost ceiling slider: $0.10 to $5.00 per build

GitHub section:
  Connected account display (avatar + username)
  [Disconnect] option
  Default repo settings

Billing section:
  Current plan
  Usage this month: progress bar
  [Upgrade] / [Manage subscription] button
  Invoice history table

Notifications section:
  Toggle list:
    Gate completed
    Build errors
    Weekly summary
    New features

Danger Zone section:
  [Delete account] -- requires confirmation modal
  [Export all data] -- downloads ZIP
```

---

## SCREEN 9 -- PROFILE / ACCOUNT

**Route:** `/profile`
**Gate:** v1.0.0

### ProfilePage component
```
Header:
  Avatar (large, 80px)
  Display name
  Email
  Member since date
  Experience level badge

Stats cards:
  Projects: [X]
  Apps Shipped: [X]
  Gates Completed: [X]
  Total Build Time: [X] hrs

Recent Activity:
  Timeline of recent actions
  Each: icon, description, timestamp

Achievements (v2.0.0):
  Badge grid -- placeholder locked state at v1.0.0
```

---

## SHARED COMPONENTS

### Button component
```
Variants:
  primary:   bg accent-primary, text white, hover accent-hover
  secondary: bg transparent, border border-default, hover bg-hover
  ghost:     bg transparent, no border, hover bg-hover
  danger:    bg error, text white
  success:   bg success, text inverse

Sizes:
  sm:   height 32px, px 12px, text-sm
  md:   height 40px, px 16px, text-base (default)
  lg:   height 48px, px 24px, text-lg

States:
  loading: spinner replaces children, disabled pointer-events
  disabled: opacity 0.4, no-pointer
  icon-only: square aspect ratio, centered icon

Animation: subtle scale(0.98) on active
```

### Input component
```
Height: 40px
Background: var(--bg-secondary)
Border: 1px solid var(--border-default)
Border-radius: var(--radius-md)
Text: var(--text-primary), --font-body, --text-base
Placeholder: var(--text-muted)

Focus: border var(--border-active), box-shadow var(--shadow-glow)
Error: border var(--error), error message below in --error color
Disabled: opacity 0.4

Icon variants: left icon / right icon with appropriate padding
```

### GateBadge component
```
Variants by status:
  COMPLETE:     bg success-bg, text success, "✓ v0.2.0 Complete"
  IN_PROGRESS:  bg warning-bg, text warning, "◉ v0.3.0 In Progress"
  PENDING:      bg info-bg, text info, "○ v0.4.0 Pending"
  BLOCKED:      bg error-bg, text error, "✗ v0.3.0 Blocked"

Size: height 24px, px 10px, text-xs, radius-full
Font: --font-mono for version number
```

### ModelBadge component
```
Shows current AI model
Icon: sparkle icon
Text: "Qwen 2.5 Coder" or "Claude Sonnet 4.6"
Size: small, pill shape
Color: accent-primary tint background
```

### ThinkingIndicator component
```
3 animated dots, staggered pulse
Color: var(--text-muted)
Used in: chat messages, preview loading, gate processing
```

### EmptyState component
```
Props: icon, title, description, action (optional)
Layout: centered, vertical stack
Icon: 48px, text-muted color
Title: --font-display, --text-xl
Description: --font-body, --text-base, --text-secondary
Action: primary button (optional)
```

### Modal component
```
Overlay: rgba(0,0,0,0.7) backdrop blur
Card: var(--bg-tertiary), --radius-xl, --shadow-lg
Max-width: 480px (sm) / 640px (md) / 800px (lg)
Header: title + close button
Body: scrollable if content overflows
Footer: action buttons right-aligned
Animation: fade in + scale from 0.95 to 1
```

### Toast component
```
Position: bottom-right, stacked
Variants: success / error / warning / info
Height: auto, min 48px
Width: 320px
Icon + message + optional action link
Auto-dismiss: 4 seconds (error: 6 seconds)
Close button always visible
```

### ProgressBar component
```
Height: 4px (slim) or 8px (standard)
Background: var(--bg-tertiary)
Fill: gradient (accent-primary → success) based on % complete
Animated: smooth transition on value change
Label: optional percentage or fraction above
```

### CodeViewer component
```
Library: Shiki for syntax highlighting
Theme: custom dark matching Trailwai colors
Features:
  Line numbers
  Copy button (top right)
  Language badge (top right)
  Collapse to N lines with "Show more"
Font: --font-mono, --text-sm
Background: var(--bg-secondary)
Border: 1px solid var(--border-default)
Radius: --radius-lg
```

---

## STATE MANAGEMENT

**Library:** Zustand
**Pattern:** One store per feature domain

### Stores:

**useProjectStore**
```typescript
interface ProjectStore {
  currentProject: Project | null
  projects: Project[]
  isLoading: boolean
  setCurrentProject: (project: Project) => void
  loadProjects: () => Promise<void>
  createProject: (data: NewProjectData) => Promise<Project>
}
```

**useBuildStore**
```typescript
interface BuildStore {
  currentGate: Gate | null
  gates: Gate[]
  buildStatus: 'idle' | 'running' | 'paused' | 'complete' | 'error'
  messages: Message[]
  addMessage: (message: Message) => void
  updateGateStatus: (gateId: string, status: GateStatus) => void
  streamBuild: (projectId: string) => void
}
```

**useUIStore**
```typescript
interface UIStore {
  sidebarOpen: boolean
  activeLeftTab: 'build' | 'research' | 'decisions' | 'logs'
  activeRightTab: 'preview' | 'gates' | 'files' | 'costs'
  previewDevice: 'desktop' | 'tablet' | 'mobile'
  toggleSidebar: () => void
  setLeftTab: (tab: string) => void
  setRightTab: (tab: string) => void
  setPreviewDevice: (device: string) => void
}
```

**useAuthStore**
```typescript
interface AuthStore {
  user: User | null
  session: Session | null
  isLoading: boolean
  signIn: (provider: 'google' | 'magic') => Promise<void>
  signOut: () => Promise<void>
}
```

---

## API CONNECTIONS

### Build API (FastAPI backend)
```
POST /api/build/start          -- Start a new build session
POST /api/build/message        -- Send user message to AI
GET  /api/build/stream/{id}    -- SSE stream for AI responses
POST /api/build/gate/advance   -- Advance to next gate
GET  /api/build/status/{id}    -- Current build status

POST /api/project/create       -- Create new project
GET  /api/project/list         -- List user's projects
GET  /api/project/{id}         -- Get project details
PUT  /api/project/{id}         -- Update project

GET  /api/files/{projectId}    -- List generated files
GET  /api/files/{id}/content   -- Get file content

GET  /api/costs/current        -- Current usage and costs
GET  /api/costs/breakdown      -- Detailed cost breakdown
```

### Streaming pattern
```typescript
// Use SSE for AI response streaming
const eventSource = new EventSource(`/api/build/stream/${sessionId}`)
eventSource.onmessage = (event) => {
  const data = JSON.parse(event.data)
  if (data.type === 'token') addToken(data.content)
  if (data.type === 'gate_update') updateGate(data.gate)
  if (data.type === 'preview_update') refreshPreview(data.url)
  if (data.type === 'complete') eventSource.close()
}
```

---

## ANIMATION PATTERNS

### Page transitions
- Fade in + slight upward translate (20px → 0)
- Duration: 200ms, ease-out

### Card hover
- Scale: 1.0 → 1.01
- Shadow: increases
- Duration: 150ms, ease-out

### Gate completion
- Green checkmark draws in
- Confetti particles (subtle, 0.5s)
- Success toast appears

### AI thinking
- Pulse animation on status dot
- Dots animation in chat

### Preview loading
- Skeleton shimmer in preview frame
- Replaces with iframe when ready

### Gate progress
- Counter animates up from 0 to value on mount
- Progress bar fills with spring animation

---

## RESPONSIVE BREAKPOINTS

```
mobile:   < 768px   (single column, drawer sidebar)
tablet:   768-1024px (2 column, condensed sidebar)
desktop:  > 1024px  (full 3 column layout)
wide:     > 1440px  (max-width 1440px centered)
```

### Mobile-specific behaviors:
- Left/Right panels stack vertically instead of side by side
- Tabs switch between panels (chat vs preview)
- Sidebar is always a drawer
- TopNav shows project name, back button on nested pages
- Preview defaults to mobile device mode

---

## ACCESSIBILITY

- All interactive elements keyboard navigable
- Focus rings: 2px solid accent-primary, 2px offset
- ARIA labels on all icon-only buttons
- Color contrast: minimum 4.5:1 for all text
- Screen reader announcements for gate status changes
- Reduced motion: all animations respect prefers-reduced-motion
- Font size minimum 13px everywhere

---

## TECH STACK (frontend only)

```
Framework:    Next.js 15 (App Router)
Language:     TypeScript (strict mode)
Styling:      Tailwind CSS + CSS variables
Components:   shadcn/ui (base) + custom Trailwai components
State:        Zustand
Data fetch:   TanStack Query v5
Forms:        React Hook Form + Zod
Icons:        Lucide React
Charts:       Recharts
Code view:    Shiki
Animations:   Framer Motion
Fonts:        Space Grotesk, Inter, JetBrains Mono (Google Fonts)
Testing:      Vitest + React Testing Library
```

---

## COMPONENT FILE STRUCTURE

```
src/
  components/
    ui/              -- Base shadcn/ui components
    layout/
      TopNav.tsx
      Sidebar.tsx
      LeftPanel.tsx
      RightPanel.tsx
    build/
      ChatMessage.tsx
      InterrogationCard.tsx
      InputArea.tsx
      ThinkingIndicator.tsx
      BuildLogStream.tsx
    preview/
      PreviewFrame.tsx
      DeviceToggle.tsx
    gates/
      GateCard.tsx
      GateBadge.tsx
      GateTimeline.tsx
      GateRoadmap.tsx
    project/
      ProjectCard.tsx
      ProjectGrid.tsx
      NewProjectFlow.tsx
    research/
      CompetitorCard.tsx
      MarketGapCard.tsx
    costs/
      CostCard.tsx
      UsageChart.tsx
      CostBreakdown.tsx
    shared/
      Button.tsx
      Input.tsx
      Modal.tsx
      Toast.tsx
      EmptyState.tsx
      ProgressBar.tsx
      CodeViewer.tsx
      ModelBadge.tsx
      GateBadge.tsx
  stores/
    useProjectStore.ts
    useBuildStore.ts
    useUIStore.ts
    useAuthStore.ts
  hooks/
    useBuildStream.ts
    useKeyboardShortcuts.ts
    useResizablePanel.ts
  lib/
    api.ts
    utils.ts
    constants.ts
  app/
    (auth)/
      login/page.tsx
      register/page.tsx
    (app)/
      layout.tsx          -- authenticated layout
      dashboard/page.tsx
      projects/page.tsx
      projects/new/page.tsx
      gates/page.tsx
      settings/page.tsx
      profile/page.tsx
    page.tsx              -- landing page
    layout.tsx            -- root layout
```

---

# END OF FRONTEND_SPEC.md v1.0
# This spec governs every UI decision in the Trailwai build.
# Deviation from this spec requires Brian's approval and a DECISIONS.md entry.
