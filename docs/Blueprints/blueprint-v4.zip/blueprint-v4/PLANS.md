# PLANS.md — Active Task Graph
# {{APP_NAME}} | Updated: {{DATE}}
#
# PURPOSE: Persistent task tracking across sessions.
# Inspired by Claude Code's TaskCreate/Update/Get/List harness subsystem (s07).
# This file persists goals beyond any single conversation.
#
# STATUS VALUES: pending | in-progress | blocked | complete | cancelled
# RULE: Update this file when starting a task, completing a task, or hitting a blocker.
# RULE: Claude reads this at session start to resume context accurately.

---

## Current Version Gate: {{CURRENT_VERSION}}
## Next Gate Target: {{NEXT_VERSION}}

---

## Active Tasks

| ID       | Description                              | Depends On | Status      | Agent         |
|----------|------------------------------------------|------------|-------------|---------------|
| TASK-001 | {{TASK_DESCRIPTION}}                     | none       | pending     | @{{AGENT}}    |
| TASK-002 | {{TASK_DESCRIPTION}}                     | TASK-001   | pending     | @{{AGENT}}    |
| TASK-003 | {{TASK_DESCRIPTION}}                     | TASK-001   | pending     | @{{AGENT}}    |

---

## Blocked Tasks
| ID       | Description                              | Blocked By                     | Notes              |
|----------|------------------------------------------|--------------------------------|--------------------|
| —        | No blocked tasks                         | —                              | —                  |

---

## Completed Tasks
| ID       | Description                              | Completed  | Version    |
|----------|------------------------------------------|------------|------------|
| TASK-000 | Write all 8 foundation files             | {{DATE}}   | v0.0.0     |

---

## Session Log
Use this to record what was accomplished each session, so next session resumes cleanly.

### Session: {{DATE}}
**Started at gate:** {{VERSION}}
**Completed:**
- {{WHAT_WAS_DONE}}
**Modified files:**
- {{FILE_1}}
- {{FILE_2}}
**Left off at:**
- {{NEXT_ACTION}}
**Test status:** {{PASSING_COUNT}} passing / {{FAILING_COUNT}} failing
**Notes for next session:**
- {{NOTE}}
