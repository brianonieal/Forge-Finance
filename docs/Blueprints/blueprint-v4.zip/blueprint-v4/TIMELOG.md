# TIMELOG.md — Project Time Tracking
# {{APP_NAME}}
# Client: {{CLIENT_NAME}}
# Contract Ref: {{CONTRACT_REF_NUMBER}}
# Hourly Rate: $150.00
# Project Start: {{START_DATE}}
# Last Updated: {{DATE}}
#
# RULE: Log every session before closing your editor.
# RULE: Discovery and planning hours are billable. Log them.
# RULE: Client-requested scope changes get their own SCOPE tag.
# RULE: This file feeds the master MASTER_BILLING.md at invoice time.

---

## Session Log

| ID    | Date       | Start | End   | Hours | Gate    | Category     | Description                                      | Billable |
|-------|------------|-------|-------|-------|---------|--------------|--------------------------------------------------|----------|
| S-001 | {{DATE}}   | HH:MM | HH:MM | X.X   | v0.0.0  | DISCOVERY    | Initial client meeting, requirements gathering   | YES      |
| S-002 | {{DATE}}   | HH:MM | HH:MM | X.X   | v0.0.0  | PLANNING     | Blueprint files written (CLAUDE.md, CONTRACT.md, etc.) | YES |
| S-003 | {{DATE}}   | HH:MM | HH:MM | X.X   | v0.1.0  | BUILD        | Project scaffold, dependency setup               | YES      |
| S-004 | {{DATE}}   | HH:MM | HH:MM | X.X   | v0.2.0  | BUILD        | Database schema + migrations                     | YES      |
| S-005 | {{DATE}}   | HH:MM | HH:MM | X.X   | v0.2.0  | DEBUG        | Supabase RLS policy debugging (not in scope)     | YES      |
| S-006 | {{DATE}}   | HH:MM | HH:MM | X.X   | v0.3.0  | SCOPE        | Client-requested pivot: REST to tRPC (+4 hrs)    | YES      |

## Session Categories
- **DISCOVERY** -- Client meetings, requirements, research
- **PLANNING** -- Blueprint files, architecture, spec writing
- **BUILD** -- Feature implementation per gate
- **DEBUG** -- Bug fixing, regression resolution
- **REVIEW** -- Code review, QA, testing
- **REVISION** -- Client-requested changes (track separately)
- **SCOPE** -- Out-of-scope work requested by client (always billable, always flagged)
- **ADMIN** -- Invoicing, email, project management (non-billable by default)

---

## Hours Summary

| Gate / Phase        | Category   | Hours | Amount ($150/hr) |
|---------------------|------------|-------|------------------|
| Discovery & Planning| DISCOVERY  | X.X   | $X,XXX.XX        |
| Discovery & Planning| PLANNING   | X.X   | $X,XXX.XX        |
| v0.1.0 Scaffold     | BUILD      | X.X   | $X,XXX.XX        |
| v0.2.0 Data Layer   | BUILD      | X.X   | $X,XXX.XX        |
| v0.2.0 Data Layer   | DEBUG      | X.X   | $X,XXX.XX        |
| v0.3.0 Auth         | BUILD      | X.X   | $X,XXX.XX        |
| v0.4.0 {{FEATURE}}  | BUILD      | X.X   | $X,XXX.XX        |
| Scope Changes       | SCOPE      | X.X   | $X,XXX.XX        |
| Client Revisions    | REVISION   | X.X   | $X,XXX.XX        |
| **TOTAL**           |            | **X.X** | **$X,XXX.XX**  |

---

## Scope Change Log
Track every client-requested change that deviated from original spec.
This protects you in billing disputes.

| ID    | Date       | Requested By | Description                                      | Hours Added | Approved |
|-------|------------|--------------|--------------------------------------------------|-------------|----------|
| SC-001| {{DATE}}   | {{CLIENT}}   | {{SCOPE_CHANGE_DESCRIPTION}}                     | X.X         | YES/NO   |

---

## Revision Rounds
| Round | Date       | Description                                      | Hours | Included in Flat Fee | Billable Extra |
|-------|------------|--------------------------------------------------|-------|----------------------|----------------|
| R-01  | {{DATE}}   | {{REVISION_DESCRIPTION}}                         | X.X   | YES (round 1 of 2)   | NO             |
| R-02  | {{DATE}}   | {{REVISION_DESCRIPTION}}                         | X.X   | YES (round 2 of 2)   | NO             |
| R-03  | {{DATE}}   | {{REVISION_DESCRIPTION}}                         | X.X   | NO                   | YES            |

---

## Expense Log
Track all third-party costs to pass through to client.

| ID    | Date       | Service              | Description                        | Cost     | Billable |
|-------|------------|----------------------|------------------------------------|----------|----------|
| E-001 | {{DATE}}   | Anthropic API        | Claude API usage - build month 1   | $XX.XX   | YES      |
| E-002 | {{DATE}}   | Supabase             | Pro plan - month 1                 | $XX.XX   | YES      |
| E-003 | {{DATE}}   | Vercel               | Pro plan - month 1                 | $XX.XX   | YES      |
| E-004 | {{DATE}}   | {{SERVICE}}          | {{DESCRIPTION}}                    | $XX.XX   | YES/NO   |

**Total Expenses: $XXX.XX**

---

## Milestone Payment Schedule
| Milestone    | Gate        | Amount Due    | Due Date   | Paid       | Invoice #  |
|--------------|-------------|---------------|------------|------------|------------|
| Deposit 50%  | v0.0.0      | $X,XXX.XX     | {{DATE}}   | YES/NO     | INV-001    |
| Gate 1       | v0.2.0      | $X,XXX.XX     | {{DATE}}   | YES/NO     | INV-002    |
| Gate 2       | v0.4.0      | $X,XXX.XX     | {{DATE}}   | YES/NO     | INV-003    |
| Final        | v1.0.0      | $X,XXX.XX     | {{DATE}}   | YES/NO     | INV-004    |

---

## Notes & Blockers Log
| Date       | Note                                                                     |
|------------|--------------------------------------------------------------------------|
| {{DATE}}   | {{ANY_RELEVANT_CONTEXT_FOR_BILLING_DISPUTES_OR_DELAYS}}                  |

---

## Gate Cost Summary (v3 addition)
Auto-populated at every gate close. Compares actual vs estimated.
Feeds directly into invoicing and roadmap accuracy tracking.

| Gate | Estimated Hrs | Actual Hrs | Variance | Cost ($150/hr) | Status |
|------|--------------|------------|----------|----------------|--------|
| v0.0.0 Foundation | {{EST}} | {{ACT}} | {{VAR}} | ${{COST}} | CLOSED |
| v0.1.0 Scaffold | {{EST}} | {{ACT}} | {{VAR}} | ${{COST}} | OPEN |

**Running totals:**
- Total estimated: {{X}} hrs
- Total actual: {{X}} hrs
- Total variance: {{X}} hrs ({{+/-}}{{X}}%)
- Total billed: ${{X}}
- Total unbilled: ${{X}}

**Estimate accuracy tracking:**
After 3+ gates, Claude calculates your average estimate accuracy
and adjusts future estimates accordingly.
If actual consistently runs over estimate by more than 20%,
flag this to Brian at next gate open.
