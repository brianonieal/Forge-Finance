# MASTER_BILLING.md — Cross-Project Billing Ledger
# Brian Onieal | Freelance AI Systems Engineer
# Rate: $150/hr
# Last Updated: {{DATE}}
#
# PURPOSE: Single ledger across all active and past client projects.
# Per-project TIMELOG.md files feed into this file at invoice time.
# Use this to track cash flow, outstanding invoices, and YTD revenue.
#
# LOCATION: Keep this file OUTSIDE any client project repo.
# Suggested location: ~/freelance/MASTER_BILLING.md

---

## Active Projects

| Project       | Client         | Contract Ref | Start Date | Status      | Total Billed | Outstanding |
|---------------|----------------|--------------|------------|-------------|--------------|-------------|
| {{APP_NAME}}  | {{CLIENT}}     | {{REF}}      | {{DATE}}   | IN PROGRESS | $X,XXX.XX    | $X,XXX.XX   |
| {{APP_NAME}}  | {{CLIENT}}     | {{REF}}      | {{DATE}}   | IN PROGRESS | $X,XXX.XX    | $X,XXX.XX   |

---

## Invoice Register

| Invoice #  | Project       | Client         | Issue Date | Due Date   | Amount     | Status   | Paid Date  |
|------------|---------------|----------------|------------|------------|------------|----------|------------|
| INV-001    | {{APP_NAME}}  | {{CLIENT}}     | {{DATE}}   | {{DATE}}   | $X,XXX.XX  | PAID     | {{DATE}}   |
| INV-002    | {{APP_NAME}}  | {{CLIENT}}     | {{DATE}}   | {{DATE}}   | $X,XXX.XX  | PENDING  | —          |
| INV-003    | {{APP_NAME}}  | {{CLIENT}}     | {{DATE}}   | {{DATE}}   | $X,XXX.XX  | OVERDUE  | —          |

---

## YTD Summary ({{YEAR}})

| Month     | Hours Billed | Revenue      | Expenses     | Net          |
|-----------|--------------|--------------|--------------|--------------|
| January   | X.X          | $X,XXX.XX    | $XXX.XX      | $X,XXX.XX    |
| February  | X.X          | $X,XXX.XX    | $XXX.XX      | $X,XXX.XX    |
| March     | X.X          | $X,XXX.XX    | $XXX.XX      | $X,XXX.XX    |
| April     | X.X          | $X,XXX.XX    | $XXX.XX      | $X,XXX.XX    |
| **TOTAL** | **X.X**      | **$X,XXX.XX**| **$XXX.XX**  | **$X,XXX.XX**|

---

## Completed Projects

| Project       | Client         | Dates              | Total Billed | Total Hours | Status    |
|---------------|----------------|--------------------|--------------|-------------|-----------|
| {{APP_NAME}}  | {{CLIENT}}     | {{DATE}}-{{DATE}}  | $X,XXX.XX    | X.X         | PAID/FULL |

---

## Outstanding / Overdue

| Invoice #  | Client         | Amount     | Days Overdue | Action Taken              |
|------------|----------------|------------|--------------|---------------------------|
| INV-XXX    | {{CLIENT}}     | $X,XXX.XX  | XX days      | Reminder sent {{DATE}}    |

---

## Tax Tracking (consult your accountant)
| Quarter | Estimated Tax Due | Paid  | Date     |
|---------|-------------------|-------|----------|
| Q1      | $X,XXX.XX         | YES   | {{DATE}} |
| Q2      | $X,XXX.XX         | NO    | —        |
| Q3      | $X,XXX.XX         | NO    | —        |
| Q4      | $X,XXX.XX         | NO    | —        |

Self-employment tax rate: ~15.3% on net earnings
Estimated federal income tax: ~22% bracket at current earnings
Set aside ~30-35% of every invoice for taxes. Do not spend it.
