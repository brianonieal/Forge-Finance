---
name: research
description: Competitive intelligence and repo research skill for any app Brian is building. Invoke with /research to trigger a full research session before or during a build. Researches top 5 competitor apps across features, UX/UI, AI technologies, pricing, user complaints, and market gaps. Searches GitHub, npm, and PyPI for relevant libraries and code patterns. Outputs a structured RESEARCH.md file that feeds directly into the Build Rules intake interrogation.
---

# RESEARCH SKILL
# Owner: Brian Onieal | Freelance AI Systems Engineer
# Version: 1.0 | April 2026
# Invoke: /research [brief description of what you're building]

---

## WHAT THIS IS

The Research skill is Claude's competitive intelligence and repo discovery system.
It runs BEFORE or DURING a Build Rules session.

When invoked, it:
1. Asks about the app's purpose and clarifying questions
2. Automatically identifies the top 5 competitor apps in the category
3. Researches each competitor exhaustively across 8 dimensions
4. Searches GitHub, npm, and PyPI for relevant libraries and patterns
5. Produces a structured RESEARCH.md in the project folder
6. Summarizes key findings before the Build Rules interrogation begins

The output is not a reading assignment.
It is actionable intelligence -- features to consider, patterns to steal,
gaps to own, libraries to use, and mistakes to avoid.

---

## INVOCATION

When `/research` is invoked with any description, Claude responds:

---

"Research session started.

Before I find your competitors, I need to understand what you're building.

1. What is the core purpose of this app? What problem does it solve and for who?
2. What is the primary platform? (mobile, web, both)
3. Who is the target user? (consumers, businesses, developers, specific niche)
4. What is the core action a user takes in this app? (track spending, manage tasks, book appointments, etc.)
5. Do you already have any competitors in mind, or should I find them entirely on my own?
6. Are there any apps -- even outside this category -- whose design, UX, or features you admire?
7. Is there a specific aspect you most want to research? (features, design, AI usage, pricing, all of it)

Answer what you know. Skip what you don't. Type READY when done."

---

After READY, Claude confirms its understanding in one paragraph and states:
"Finding your top 5 competitors now. This will take a moment."

---

## PHASE 1 -- COMPETITOR IDENTIFICATION

Claude searches the web to identify the top 5 competitors.

Selection criteria (in order of priority):
1. Most downloaded / highest rated in the app category
2. Most frequently cited in reviews, Reddit, Product Hunt, and tech coverage
3. Direct feature overlap with what Brian is building
4. Mix of established players AND newer challengers (not all incumbents)
5. At least one that is known for exceptional UX/design

Claude states the 5 selected competitors and why each was chosen:

```
TOP 5 COMPETITORS FOR [APP CATEGORY]

1. [App Name] -- [why selected, e.g. "market leader, 4M+ users"]
2. [App Name] -- [why selected]
3. [App Name] -- [why selected]
4. [App Name] -- [why selected]
5. [App Name] -- [why selected, e.g. "known for best-in-class UX"]

Proceeding with research on all 5. Type SWAP [number] [replacement] to
swap any competitor before I begin. Otherwise type GO."
```

---

## PHASE 2 -- COMPETITOR RESEARCH

For each of the 5 competitors, Claude researches all 8 dimensions below.
Research is conducted via web search, app store pages, review sites
(Reddit, App Store, Google Play, Product Hunt, G2, Trustpilot),
and any available technical documentation or blog posts.

### DIMENSION 1 -- CORE FEATURES
- Complete feature list, organized by category
- Which features are in free tier vs. paid
- Which features are unique to this app (not found in others)
- Which features are table stakes (every competitor has them)
- Recently launched features (what they're investing in)

### DIMENSION 2 -- PRICING STRUCTURE
- Free tier: what's included, what's limited
- Paid tiers: exact pricing, what each unlocks
- Enterprise/team pricing if applicable
- Free trial policy
- Annual vs. monthly discount
- What the most popular tier appears to be (based on reviews/coverage)

### DIMENSION 3 -- UX & DESIGN PATTERNS
- Overall aesthetic and design language
- Navigation pattern (bottom tabs, sidebar, drawer, etc.)
- Onboarding flow -- how many steps, what's required
- Key interaction patterns (gestures, animations, micro-interactions)
- Empty state handling
- Loading and error state patterns
- Anything notably beautiful or notably broken about the UX

### DIMENSION 4 -- FRONTEND & TECH
- Known tech stack (from job postings, blog posts, open source, or inference)
- Native vs. cross-platform
- Any notable frontend libraries or frameworks in use
- Performance reputation (fast/slow, crashes, stability)
- Accessibility reputation

### DIMENSION 5 -- AI & TECHNOLOGY
- Does the app use AI? What for specifically?
- Which AI features are surface-level (just a chatbot) vs. deeply integrated
- Any known models or providers (OpenAI, Anthropic, proprietary)
- AI features users love vs. AI features users ignore or distrust
- What AI features are missing that would obviously help

### DIMENSION 6 -- USER COMPLAINTS (what users hate)
- Top recurring complaints from App Store, Google Play, Reddit, G2
- Bugs or reliability issues mentioned repeatedly
- Missing features users consistently request
- Pricing complaints
- Support and customer service reputation
- Anything users switched AWAY from this app for

### DIMENSION 7 -- MARKET GAPS (what nobody does well)
- Features requested across multiple competitors but not delivered
- UX problems that exist in all 5 apps
- User segments underserved by current market
- Price points not covered
- Platform gaps (everyone is web-only, nobody has a great mobile app, etc.)
- AI capabilities that are obviously valuable but absent

### DIMENSION 8 -- REPO & LIBRARY RESEARCH
Claude proactively searches GitHub, npm, and PyPI for:
- Open source implementations of core features in this category
- Libraries that solve the hardest technical problems in this space
- Starter templates or boilerplates relevant to this app type
- Code patterns worth studying (not copying -- studying)
- Any repos with significant stars that solve a problem Brian will face

For each relevant find:
```
REPO: [name] | [platform] | [stars]
URL: [url]
What it does: [one sentence]
Relevance: [why it matters for Brian's app]
Recommendation: USE / STUDY / SKIP
```

---

## PHASE 3 -- RESEARCH.md GENERATION

After researching all 5 competitors across all 8 dimensions, Claude generates
RESEARCH.md in the project folder at `[PROJECT_ROOT]/RESEARCH.md`.

### RESEARCH.md structure:

```markdown
# RESEARCH.md — Competitive Intelligence
# App: [APP NAME]
# Category: [CATEGORY]
# Researched: [DATE]
# Competitors: [LIST OF 5]

---

## EXECUTIVE SUMMARY
[3-5 sentences: the most important things Brian needs to know before building.
What the market looks like. The biggest opportunity. The biggest risk.]

---

## COMPETITOR PROFILES

### [Competitor 1]
[All 8 dimensions, structured]

### [Competitor 2]
[All 8 dimensions, structured]

[...continues for all 5...]

---

## FEATURE MATRIX
[Table showing which features exist across which competitors]

| Feature                | App1 | App2 | App3 | App4 | App5 |
|------------------------|------|------|------|------|------|
| [Feature]              | ✓    | ✓    | ✗    | ✓    | ✗    |

---

## PRICING MATRIX
[Table showing pricing across all 5 competitors]

| Tier     | App1   | App2   | App3   | App4   | App5   |
|----------|--------|--------|--------|--------|--------|
| Free     | [what] | [what] | [what] | [what] | [what] |
| Paid 1   | $X/mo  | $X/mo  | $X/mo  | $X/mo  | $X/mo  |
| Paid 2   | $X/mo  | —      | $X/mo  | —      | $X/mo  |

---

## MARKET GAPS (opportunities Brian can own)
1. [Gap] -- [why it exists, why it's an opportunity]
2. [Gap]
3. [Gap]

---

## USER COMPLAINTS (problems to solve better)
1. [Complaint pattern across competitors] -- [how to do it better]
2. [Complaint]
3. [Complaint]

---

## RECOMMENDED FEATURES FOR [APP NAME]

### MUST HAVE (table stakes -- users expect these)
- [feature] -- present in X/5 competitors

### SHOULD HAVE (competitive advantage)
- [feature] -- only X/5 competitors have this, users request it frequently

### CONSIDER (differentiation opportunity)
- [feature] -- nobody has this, market gap identified

### SKIP (not worth building)
- [feature] -- exists everywhere, commoditized, not a differentiator

---

## PRICING RECOMMENDATION
Based on competitor pricing structures:

[Summary of how competitors price]

Suggested pricing structure for [APP NAME]:
- Free: [what to include]
- [Tier name] $X/mo: [what to include]
- [Tier name] $X/mo: [what to include]

Note: This is a recommendation based on market data.
Brian makes the final pricing decision during the Build Rules interrogation.

---

## AI & TECHNOLOGY RECOMMENDATIONS
[What AI features the market is using, what's missing, what Brian should consider]

---

## REPOS & LIBRARIES

### Recommended for use
[List with links and rationale]

### Worth studying
[List with links and rationale]

---

## DESIGN INSPIRATION
[Specific UX patterns, screens, or interactions from competitors worth referencing]
[Note: reference and improve -- never copy]

---

## RED FLAGS (what not to build)
[Features that sound good but users consistently ignore or dislike across competitors]
```

---

## PHASE 4 -- BUILD RULES INTEGRATION

After RESEARCH.md is generated, Claude delivers a summary brief:

---

"Research complete. Here's what matters most before we start building:

**The market in one sentence:** [summary]

**Biggest opportunity:** [the gap Brian can own]

**Must-have features:** [top 3-5]

**Biggest mistake to avoid:** [top complaint pattern across competitors]

**Pricing insight:** [what the market charges and what's recommended]

**Best repo finds:** [top 1-2 with links]

RESEARCH.md has been saved to [PROJECT_ROOT]/RESEARCH.md.

If you're starting a Build Rules session now, this research will inform
every question Claude asks during the interrogation. Type /build-rules
to begin, or continue working in your current session."

---

## COMMAND WORDS

| You type | What happens |
|----------|--------------|
| `/research [description]` | Invoke research session |
| `READY` | Purpose questions answered, find competitors |
| `GO` | Competitors confirmed, begin full research |
| `SWAP [#] [app name]` | Replace a competitor before research begins |
| `DEEP [#]` | Go deeper on one specific competitor |
| `REPOS ONLY` | Skip competitor research, only search repos |
| `UPDATE` | Re-run research on an existing RESEARCH.md |

---

## INTEGRATION WITH BUILD RULES

When `/build-rules` is invoked after `/research` has been run:

Claude automatically reads RESEARCH.md at the start of Phase 1 interrogation
and uses it to:

- Pre-fill known answers where research already determined them
- Ask smarter questions based on market gaps found
- Flag features during interrogation: "Competitors X and Y have this --
  do you want to include it, improve on it, or skip it?"
- Inform the roadmap proposal with competitive context
- Inform mockup design with UX patterns worth referencing

RESEARCH.md is listed in the Build Rules foundation files table and
is referenced throughout the build whenever feature or design decisions arise.

---

## RULES

- Never recommend copying a competitor's design or code -- reference and improve
- Always cite the source of a finding (App Store, Reddit, G2, etc.)
- If web search returns limited results for a competitor, state that clearly
- Repo recommendations must have meaningful GitHub stars (>500) unless
  the library is highly specific and clearly relevant
- Pricing recommendations are suggestions only -- Brian decides
- Research sessions can be re-run at any time with UPDATE command
- RESEARCH.md is version controlled -- commit it with the project

---

# END OF RESEARCH SKILL v1.0
# Next version: v1.1 -- informed by first real research session run

---

## UPDATE MODE (auto-refresh for existing RESEARCH.md)

When `UPDATE` is typed or triggered by /health, Claude runs a
targeted refresh against the existing RESEARCH.md -- not a full
new research session.

### What UPDATE does differently from a full /research run:
- Uses the competitor list already in RESEARCH.md (no new discovery)
- Focuses on: pricing changes, new features, new competitors entered market
- Produces a DIFF against current RESEARCH.md content
- Flags any competitor moves that affect planned VERSION_ROADMAP.md features
- Updates the "Last updated" date in RESEARCH.md

### UPDATE output format:
```
RESEARCH.md REFRESH COMPLETE

Last research: [PREVIOUS DATE] ([X] days ago)
Competitors re-researched: [list]

CHANGES DETECTED:

PRICING CHANGES:
- [Competitor]: [old price] → [new price]

NEW FEATURES SHIPPED:
- [Competitor]: [feature] -- [threat level: LOW/MEDIUM/HIGH]
  Impact on your roadmap: [which gate/feature is affected]

NEW COMPETITORS:
- [Name]: [description] | Threat level: [LOW/MEDIUM/HIGH]

NO LONGER RELEVANT:
- [Competitor]: [why -- shut down, pivoted, etc.]

UNCHANGED: [N] items

ROADMAP ALERT (if any):
[Competitor] shipped [feature] you planned as a differentiator at v[X.X.X].
Recommend: [keep / accelerate / differentiate / drop]

RESEARCH.md updated. Health check score recalculated.
```

### Cadence recommendations by market type:
- Fintech (Forge Finance): every 60 days
- Community/SaaS (Feast-AI): every 90 days
- Slow-moving markets: every 180 days
- After any major competitor announcement: immediately

MEMORY.md tracks last research update date for /health to reference.

# END OF RESEARCH SKILL v1.1
