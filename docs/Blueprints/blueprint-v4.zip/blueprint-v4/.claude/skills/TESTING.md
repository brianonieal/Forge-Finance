---
name: testing
description: "Comprehensive testing skill for all app builds. Invoke with /testing to generate test files, track coverage, and enforce gate validation. Covers Pytest (backend), Vitest + React Testing Library (frontend components), and Playwright (E2E). Writes tests before building and validates after. Hard blocks gate completion until 100% of written tests pass and 90%+ critical path coverage is confirmed. Maintains TESTS.md as the permanent test registry."
---

# TESTING SKILL
# Owner: Brian Onieal | Freelance AI Systems Engineer
# Version: 1.0 | April 2026
# Invoke: /testing

---

## WHAT THIS IS

The Testing skill governs all test generation, execution, and gate validation
for every app Brian builds.

It runs in two modes:
- **PRE-BUILD:** Write tests before Claude builds a feature (defines acceptance criteria)
- **POST-BUILD:** Run and validate tests after a gate is built (confirms correctness)

Both modes run for every gate. No exceptions.

This skill maintains TESTS.md -- the permanent test registry that survives
across sessions and tells any Claude instance exactly what tests exist,
what's passing, and what coverage looks like.

---

## STACK

| Layer | Tool | Purpose |
|-------|------|---------|
| Backend | Pytest | Unit + integration tests for Python/FastAPI |
| Frontend components | Vitest + React Testing Library | Component tests (how a user interacts, not implementation) |
| E2E | Playwright | Full user journey tests across every screen and role |
| Mobile E2E | Playwright (web) / Detox (Expo) | Mobile-specific journey tests |

**React Testing Library rule:**
Never test implementation details (internal state, method calls).
Always test behavior -- what the user sees, clicks, and gets back.

---

## INVOCATION

When `/testing` is invoked, Claude asks:

---

"Testing session started.

1. Which gate are we testing? (e.g. v0.2.0 Data Layer)
2. Are we in PRE-BUILD mode (writing tests before code) or
   POST-BUILD mode (validating after code is written)?
3. What is the stack for this gate? (backend only, frontend only, both)
4. Are there multiple user roles in this app? If yes, list them --
   Playwright will test critical paths for each role.

Type READY when done."

---

## PRE-BUILD MODE

### Purpose
Define what success looks like BEFORE Claude writes a single line of feature code.
Tests become the acceptance criteria. If the tests pass, the gate passes.

### Process

**Step 1 -- Claude reads the current gate scope from VERSION_ROADMAP.md**
Identifies every deliverable in the current gate.

**Step 2 -- Claude identifies what needs testing:**

For each deliverable, Claude categorizes it:
- Backend logic → Pytest unit test
- API route → Pytest integration test
- UI component → Vitest + React Testing Library
- User journey → Playwright E2E
- Agent/AI call → Pytest mock test with assertion on output shape

**Step 3 -- Claude proposes the test plan:**

```
TEST PLAN: [GATE VERSION]

Backend tests (Pytest):
- [test name]: [what it validates]
- [test name]: [what it validates]

Component tests (Vitest + RTL):
- [test name]: [what it validates]
- [test name]: [what it validates]

E2E tests (Playwright):
- [journey name]: [screens covered, roles tested]
- [journey name]: [screens covered, roles tested]

Total tests to write: [X]
Estimated coverage of critical paths: [X]%

Type APPROVE to generate test files, or request changes."
```

**Step 4 -- After APPROVE, Claude generates all test files**

Files are written to the correct test directories:
```
backend/tests/[gate_version]/test_[feature].py
src/__tests__/[gate_version]/[component].test.tsx
e2e/[gate_version]/[journey].spec.ts
```

**Step 5 -- Claude updates TESTS.md with all new tests (status: PENDING)**

**Step 6 -- Claude confirms:**
"Test files generated. All tests are PENDING.
Begin building [GATE VERSION] features now.
Run /testing POST-BUILD when the gate is complete."

---

## POST-BUILD MODE

### Purpose
Validate that everything built in the gate works correctly and
that no regressions were introduced from prior gates.

### Process

**Step 1 -- Run the full test suite**

```bash
# Backend
pytest tests/ -v --cov=app --cov-report=term-missing

# Frontend components
npx vitest run --coverage

# E2E
npx playwright test --reporter=list
```

**Step 2 -- Claude evaluates results against two thresholds:**

| Threshold | Requirement | Result if failed |
|-----------|-------------|-----------------|
| Written tests passing | 100% | HARD BLOCK -- gate cannot close |
| Critical path coverage | 90%+ | HARD BLOCK -- gate cannot close |
| Regression check | All prior gate tests still pass | HARD BLOCK -- fix before proceeding |

**Step 3 -- Claude reports:**

```
POST-BUILD TEST REPORT: [GATE VERSION]
Date: [DATE]

RESULTS:
Backend:    [X]/[X] passing | Coverage: [X]%
Components: [X]/[X] passing | Coverage: [X]%
E2E:        [X]/[X] passing

PRIOR GATE REGRESSION CHECK: PASS / FAIL

THRESHOLD STATUS:
100% written tests passing: YES / NO
90%+ critical path coverage: YES / NO
Zero regressions: YES / NO

GATE STATUS: PASS / BLOCKED

[If BLOCKED:]
Failing tests:
- [test name]: [what failed] -- [likely cause]

Fix all failing tests before this gate can close.
Run /testing POST-BUILD again after fixes.

[If PASS:]
All thresholds met. Gate [VERSION] is validated.
Updating TESTS.md. You may type GO in Build Rules to proceed.
```

**Step 4 -- Claude updates TESTS.md with final results**

**Step 5 -- Build Rules integration**
Claude CANNOT output `GATE COMPLETE` in Build Rules until
POST-BUILD mode confirms GATE STATUS: PASS.
This is a hard block. No exceptions.

---

## PLAYWRIGHT E2E RULES

### Coverage requirement
Every screen in the final polished version gets at least one E2E test.
Critical screens get tests for every user role.

### What every E2E test must cover
- Happy path (everything works correctly)
- Auth boundary (unauthenticated user cannot access protected content)
- Empty state (screen renders correctly with no data)
- Error state (screen handles API failure gracefully)

### Multi-role testing
If the app has multiple roles (e.g. admin, member, host):
- Each role gets its own test file
- Critical journeys are tested for each role
- Permission boundaries are explicitly tested
  (role A cannot access role B's features)

### Mobile viewport testing
For web apps, Playwright runs tests at:
- Mobile: 375x812 (iPhone 14)
- Tablet: 768x1024 (iPad)
- Desktop: 1440x900

For Expo apps, Detox handles native mobile testing.

### Playwright config standard
```typescript
// playwright.config.ts
import { defineConfig, devices } from '@playwright/test'

export default defineConfig({
  testDir: './e2e',
  fullyParallel: true,
  retries: 2,
  reporter: 'list',
  use: { baseURL: 'http://localhost:3000', trace: 'on-first-retry' },
  projects: [
    { name: 'Desktop Chrome', use: { ...devices['Desktop Chrome'] } },
    { name: 'Mobile Safari', use: { ...devices['iPhone 14'] } },
    { name: 'Tablet', use: { ...devices['iPad Pro'] } },
  ],
})
```

---

## PYTEST RULES

### Structure
```
backend/
  tests/
    [gate_version]/
      test_[feature]_unit.py       # Unit tests
      test_[feature]_integration.py # Integration tests (real DB, mocked external APIs)
    conftest.py                     # Shared fixtures
```

### Required fixtures (conftest.py)
- Test database (separate from dev/prod -- never test against real data)
- Authenticated test client for each user role
- Mock for every external API call (Anthropic, Supabase, Plaid, etc.)

### Coverage command
```bash
pytest tests/ -v --cov=app --cov-report=term-missing --cov-fail-under=90
```

### Agent/AI test rule
Never call the real Anthropic API in tests.
Always mock the API call and assert on:
- The shape of the output (correct fields, correct types)
- The agent's behavior given a specific mocked response
- Error handling when the API returns a failure

---

## VITEST + REACT TESTING LIBRARY RULES

### Structure
```
src/
  __tests__/
    [gate_version]/
      [ComponentName].test.tsx
```

### What to test
- Component renders without crashing
- User interactions (click, type, submit) produce correct output
- Loading states display correctly
- Error states display correctly
- Empty states display correctly
- Props variations render correctly

### What NOT to test
- Internal state values
- Implementation methods
- CSS classes (unless critical to functionality)
- Third-party library internals

### Standard test pattern
```typescript
import { render, screen, fireEvent, waitFor } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { ComponentName } from '../ComponentName'

describe('ComponentName', () => {
  it('renders correctly', () => {
    render(<ComponentName />)
    expect(screen.getByRole('...')).toBeInTheDocument()
  })

  it('handles user interaction', async () => {
    const user = userEvent.setup()
    render(<ComponentName />)
    await user.click(screen.getByRole('button', { name: '...' }))
    await waitFor(() => {
      expect(screen.getByText('...')).toBeInTheDocument()
    })
  })
})
```

---

## TESTS.md -- THE TEST REGISTRY

TESTS.md lives in the project root alongside the blueprint files.
It is the permanent record of every test across every gate.
Claude reads it at the start of every testing session.

### TESTS.md structure

```markdown
# TESTS.md — Test Registry
# App: [APP NAME]
# Last updated: [DATE]

---

## COVERAGE SUMMARY

| Gate | Backend | Components | E2E | Status |
|------|---------|------------|-----|--------|
| v0.0.0 | N/A | N/A | N/A | SKIPPED (foundation only) |
| v0.1.0 | 94% | 91% | 8/8 | PASS |
| v0.2.0 | 92% | 90% | 12/12 | PASS |
| [current] | PENDING | PENDING | PENDING | IN PROGRESS |

---

## TEST FILES

### v0.1.0 — Scaffold

**Backend (Pytest)**
| File | Tests | Status |
|------|-------|--------|
| tests/v0.1.0/test_health_unit.py | 3 | PASS |
| tests/v0.1.0/test_config_unit.py | 4 | PASS |

**Components (Vitest + RTL)**
| File | Tests | Status |
|------|-------|--------|
| __tests__/v0.1.0/Button.test.tsx | 5 | PASS |
| __tests__/v0.1.0/Input.test.tsx | 6 | PASS |

**E2E (Playwright)**
| File | Journeys | Roles | Status |
|------|----------|-------|--------|
| e2e/v0.1.0/app_loads.spec.ts | App loads on all viewports | All | PASS |

---

## REGRESSION LOG

| Date | Gate | Issue | Fixed |
|------|------|-------|-------|
| [DATE] | v0.2.0 | [test name] broke [prior gate test] | YES |

---

## KNOWN SKIPS

Tests intentionally skipped with justification:
| Test | Reason | Gate |
|------|--------|------|
| [test] | [reason] | [gate] |
```

---

## COMMAND WORDS

| You type | What happens |
|----------|--------------|
| `/testing` | Invoke testing session, ask gate questions |
| `READY` | Questions answered, begin PRE or POST build process |
| `APPROVE` | Test plan approved, generate test files |
| `COVERAGE` | Show current coverage report without running full suite |
| `REGRESSION` | Run only prior gate tests to check for regressions |
| `FIX [test name]` | Claude diagnoses and fixes a specific failing test |
| `SKIP [test name] [reason]` | Mark a test as intentionally skipped with justification |

---

## INTEGRATION WITH BUILD RULES

Testing skill integrates with Build Rules at two points:

**Point 1 -- Gate open (PRE-BUILD)**
When Build Rules opens a new gate, it automatically prompts:
"Run /testing PRE-BUILD for [GATE VERSION] before writing feature code."

**Point 2 -- Gate close (POST-BUILD)**
Build Rules CANNOT output GATE COMPLETE until:
- /testing POST-BUILD has been run for the current gate
- GATE STATUS: PASS is confirmed in the test report
- TESTS.md has been updated with final results

This is enforced in BUILD_RULES.md. It is a hard block.

---

## RULES

- Never skip PRE-BUILD -- tests define acceptance criteria, not an afterthought
- Never call real external APIs in tests -- always mock
- Never test against production or development database -- test DB only
- Never mark a gate complete with a failing test -- fix it or justify the skip
- Always run the regression check -- prior gates must stay green
- TESTS.md is version controlled -- commit it after every gate
- If 3 consecutive attempts to fix a failing test fail -- stop, report, ask Brian

---

# END OF TESTING SKILL v1.0
# Next version: v1.1 -- informed by first real testing session
