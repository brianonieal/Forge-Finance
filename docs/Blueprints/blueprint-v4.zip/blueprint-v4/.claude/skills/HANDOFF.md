---
name: handoff
description: "Client handoff and project completion skill. Auto-triggered at v1.0.0 gate close. Generates three deliverables: a non-technical client handoff PDF, a technical handoff PDF for future developers, and a professional handoff email draft. Pulls all data from CONTRACT.md, DEPLOYMENT.md, CHANGELOG.md, VERSION_ROADMAP.md, and TECH_STACK.md automatically. Only leaves blanks for information it cannot find."
---

# HANDOFF SKILL
# Owner: Brian Onieal | Freelance AI Systems Engineer
# Version: 1.0 | April 2026
# Auto-triggered at v1.0.0 gate close in Build Rules

---

## WHAT THIS IS

The Handoff skill generates everything needed to close out a client project
professionally and completely.

It produces three deliverables:
1. **Client Handoff PDF** -- non-technical, what was built, how to use it,
   credentials and access, plain English changelog, what's next
2. **Technical Handoff PDF** -- for a future developer, full architecture,
   local setup, agent definitions, test suite, known issues
3. **Handoff Email Draft** -- professional email for Brian to send with PDFs attached

All content is pulled automatically from project files.
Claude only leaves blanks for information it genuinely cannot find.

---

## AUTO-TRIGGER

This skill triggers automatically when Build Rules closes the v1.0.0 gate.

Build Rules outputs:
```
GATE COMPLETE: v1.0.0

All tests passing. Deployment confirmed. Production is live.
Initiating handoff sequence...

Running /handoff -- generating client and technical documents.
```

Can also be invoked manually at any time with `/handoff`.

---

## INVOCATION

When `/handoff` is invoked manually, Claude asks:

---

"Handoff session started.

I'll pull everything I can from your project files automatically.
Just confirm a few things first:

1. What is the client's full name and company name?
2. What is the client's email address?
3. Is the project fully complete, or is this a milestone handoff?
4. Are there any known issues or limitations Brian wants to disclose?
5. What is the next phase or next project opportunity with this client, if any?
6. Any credentials or access details that aren't in CONTRACT.md or DEPLOYMENT.md?

Type READY when done."

---

## DATA EXTRACTION

Before generating any document, Claude reads and extracts from:

| Source file | What Claude extracts |
|-------------|---------------------|
| CONTRACT.md | App name, all env var names, service names, URLs, agent names, DB provider |
| DEPLOYMENT.md | Production URLs, deploy dates, health check status, version history |
| CHANGELOG.md | All entries for the full project history + final version summary |
| VERSION_ROADMAP.md | What was built per gate, what was explicitly out of scope |
| TECH_STACK.md | Full stack with rationale, deployment targets, rejected technologies |
| COUNCIL_AGENTS.md | Agent names, roles, models, tool permissions |
| HARNESS.md | Active harness layers, tool registry |
| DESIGN_SYSTEM.md | Color palette, fonts, component registry |
| ERRORS.md | Known issues and regression history |
| TESTS.md | Test coverage summary, known skips |
| TIMELOG.md | Total hours, total billed, gate breakdown |
| PLANS.md | Completed tasks, session log |

Claude states upfront what it found and what's missing:
```
DATA EXTRACTION COMPLETE

Found: CONTRACT.md, DEPLOYMENT.md, CHANGELOG.md, VERSION_ROADMAP.md,
       TECH_STACK.md, COUNCIL_AGENTS.md, TESTS.md, TIMELOG.md

Missing or incomplete:
- Client email: NOT FOUND -- please provide
- Next phase details: NOT IN PROJECT FILES -- please provide

Generating documents with available data.
Items marked [FILL IN] require Brian's input before sending."
```

---

## DOCUMENT 1 -- CLIENT HANDOFF PDF

### Audience
The client. Non-technical. Focused on value delivered, how to use the app,
who owns what, and what happens next.

### Structure

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Brian Onieal | Freelance AI Systems Engineer
[EMAIL] | Brooklyn, NY | github.com/brianonieal
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

PROJECT HANDOFF
[APP NAME]
Prepared for: [CLIENT NAME], [CLIENT COMPANY]
Date: [DATE]
Version: [FINAL VERSION]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SECTION 1 -- WHAT WAS BUILT

[2-3 paragraph plain English summary of the app -- what it does,
who uses it, what problem it solves. Pulled from VERSION_ROADMAP.md
and CLAUDE.md project description. Written for a non-technical reader.]

WHAT'S INCLUDED IN THIS DELIVERY
[Pulled from VERSION_ROADMAP.md v1.0.0 deliverables]
✓ [deliverable 1]
✓ [deliverable 2]
✓ [deliverable 3]

WHAT IS NOT INCLUDED (FUTURE PHASES)
[Pulled from VERSION_ROADMAP.md out of scope section]
- [item] -- available in a future engagement
- [item]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SECTION 2 -- YOUR APP IS LIVE

[APP NAME] is live and accessible at:

Application: [PROD_FRONTEND_URL from DEPLOYMENT.md]
API:         [PROD_BACKEND_URL from DEPLOYMENT.md]

Last deployed: [DATE from DEPLOYMENT.md]
Status: ✓ All systems healthy

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SECTION 3 -- HOW TO USE YOUR APP

[Screen-by-screen plain English usage guide.
Pulled from VERSION_ROADMAP.md feature descriptions and PLANS.md.
Written as simple numbered steps. No technical jargon.]

GETTING STARTED
1. Go to [PROD_FRONTEND_URL]
2. [first step]
3. [next step]

[KEY FEATURE 1]
[Plain English description of how to use it]

[KEY FEATURE 2]
[Plain English description of how to use it]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SECTION 4 -- YOUR ACCESS & CREDENTIALS

You own all of the following. These are your accounts and your infrastructure.

APPLICATION
URL: [PROD_FRONTEND_URL from DEPLOYMENT.md]
Admin login: [FILL IN if not in project files]

HOSTING (VERCEL)
Dashboard: https://vercel.com/dashboard
Project: [PROJECT_NAME from CONTRACT.md]
Team/Account: [FILL IN]

DATABASE ([DB_PROVIDER from CONTRACT.md])
Dashboard: [FILL IN -- Supabase/Neon/etc. dashboard URL]
Project name: [FILL IN]
Connection: Managed by the application -- no direct access needed for normal use

[AI SERVICES -- if applicable]
Provider: Anthropic / [OTHER from TECH_STACK.md]
API Key: Stored securely in your hosting environment
Usage dashboard: [FILL IN]

[ADDITIONAL SERVICES from CONTRACT.md]
[List any other services -- Plaid, SendGrid, Stripe, etc.]
[FILL IN] -- [purpose]

IMPORTANT: Keep all credentials private.
Do not share API keys or passwords via email or chat.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SECTION 5 -- WHAT WAS BUILT, VERSION BY VERSION

[Plain English changelog pulled from CHANGELOG.md.
Technical terms translated to plain English.
Organized by version gate.]

[VERSION v0.1.0] -- [GATE NAME]
- [changelog entry translated to plain English]
- [changelog entry translated to plain English]

[VERSION v0.2.0] -- [GATE NAME]
- [changelog entry translated to plain English]

[...continues through v1.0.0...]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SECTION 6 -- KNOWN LIMITATIONS

[Pulled from ERRORS.md and VERSION_ROADMAP.md out of scope.
Honest, clear, no technical jargon.]

The following are known limitations of this version:
- [limitation 1] -- [plain English explanation]
- [limitation 2]

These are not bugs -- they are features planned for future phases.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SECTION 7 -- INTELLECTUAL PROPERTY

As of receipt of final payment in full, all intellectual property,
source code, design assets, and documentation for [APP NAME] transfer
to [CLIENT NAME] / [CLIENT COMPANY] in full.

Brian Onieal retains no ongoing rights to the codebase.
Source code is available at: [GITHUB REPO URL if applicable, else FILL IN]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SECTION 8 -- PROJECT SUMMARY

Total hours: [from TIMELOG.md]
Total invoiced: $[from TIMELOG.md]
Build duration: [start date to end date from TIMELOG.md]
Versions shipped: [count from VERSION_ROADMAP.md]
Tests written: [from TESTS.md]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SECTION 9 -- WHAT'S NEXT

[If next phase exists:]
We discussed the following for a future phase:
- [next phase feature 1]
- [next phase feature 2]
I'd be glad to continue building. Let's schedule a call to discuss.

[If no next phase discussed:]
If you need additional features, bug fixes, or support,
don't hesitate to reach out: [EMAIL]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Thank you for the opportunity to build [APP NAME].

Brian Onieal
Freelance AI Systems Engineer
[EMAIL] | Brooklyn, NY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**Saved to:** `handoff/[APP_NAME]_CLIENT_HANDOFF_v[VERSION]_[DATE].pdf`

---

## DOCUMENT 2 -- TECHNICAL HANDOFF PDF

### Audience
A future developer (or Brian returning after a long break) who needs to
understand, run, and continue building the codebase from scratch.

### Structure

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
TECHNICAL HANDOFF DOCUMENT
[APP NAME] -- v[FINAL VERSION]
Prepared by: Brian Onieal
Date: [DATE]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

SECTION 1 -- SYSTEM OVERVIEW
[1-2 paragraphs: what the system does technically,
 its architecture pattern, and key design decisions]

SECTION 2 -- TECH STACK
[Pulled verbatim from TECH_STACK.md]
[Frontend, backend, database, AI/LLM, infrastructure]
[Include rationale for each major decision]
[Include explicitly rejected technologies and why]

SECTION 3 -- ARCHITECTURE
[Pulled from HARNESS.md and COUNCIL_AGENTS.md]

System diagram (text):
[ASCII or text representation of how components connect]

Agent architecture:
[Each agent from COUNCIL_AGENTS.md with role, model, tools, permissions]

Active harness layers:
[From HARNESS.md -- which of s01-s09 are active and why]

SECTION 4 -- LOCAL SETUP

Prerequisites:
[Node version, Python version, any required global tools]

Environment setup:
1. Clone the repository: [REPO URL or FILL IN]
2. Install dependencies:
   Frontend: npm install
   Backend: pip install -r requirements.txt
3. Copy .env.example to .env.local
4. Fill in the following environment variables:
   [Every var from CONTRACT.md with description of what it does]
5. Run database migrations: [MIGRATE_COMMAND from CLAUDE.md]
6. Start development server: [DEV_COMMAND from CLAUDE.md]

Health check:
[DEV_FRONTEND_URL] -- should return the app
[DEV_BACKEND_URL]/api/health -- should return 200

SECTION 5 -- PROJECT STRUCTURE
[DIRECTORY_MAP from CLAUDE.md]
[Brief description of what lives where]

SECTION 6 -- KEY COMMANDS
[All commands from CLAUDE.md]
Development: [DEV_COMMAND]
Tests: [TEST_COMMAND]
Build: [BUILD_COMMAND]
Lint: [LINT_COMMAND]
Migrations: [MIGRATE_COMMAND]

SECTION 7 -- DATABASE
Provider: [DB_PROVIDER from CONTRACT.md]
Schema: [location of schema files]
Migrations: [how to run, how to create new ones]
Branching: [if applicable]

SECTION 8 -- AI & AGENTS
[Pulled from COUNCIL_AGENTS.md]
[For each agent: name, role, model, system prompt summary, tools]
[How agents communicate]
[How to modify agent behavior]
[Cost management notes]

SECTION 9 -- DESIGN SYSTEM
[Pulled from DESIGN_SYSTEM.md]
Color tokens: [palette]
Fonts: [font pairing]
Component registry: [list of built components and their locations]
Mockup references: [location of screen mockups]

SECTION 10 -- TEST SUITE
[Pulled from TESTS.md]
Stack: Pytest + Vitest + React Testing Library + Playwright
Run all tests: [TEST_COMMAND]
Coverage report: [coverage command]
Current coverage: [from TESTS.md]
Known skips: [from TESTS.md]

SECTION 11 -- DEPLOYMENT
[Pulled from DEPLOYMENT.md]
Frontend: Vercel -- [project name]
Backend: [Render/Railway] -- [service name]
Deploy command: [from DEPLOYMENT.md]
Staging URL: [URL]
Production URL: [URL]
Health check endpoint: [endpoint]

SECTION 12 -- KNOWN ISSUES & GOTCHAS
[Pulled from ERRORS.md]
[Every entry in ERRORS.md listed with: what happened, root cause, fix applied]
[Prevention rules added as a result]

SECTION 13 -- VERSION HISTORY
[Full gate history from VERSION_ROADMAP.md]
[What shipped in each gate, dates, test counts]

SECTION 14 -- CHANGELOG
[Full raw CHANGELOG.md -- technical version, unedited]

SECTION 15 -- BUILD RULES REFERENCE
This project was built using the Build Rules methodology.
Blueprint files are in: [PROJECT_ROOT]
To continue building: invoke /build-rules in Claude Code
Current version gate: v[VERSION]
Next planned gate: [NEXT VERSION from VERSION_ROADMAP.md or FILL IN]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**Saved to:** `handoff/[APP_NAME]_TECHNICAL_HANDOFF_v[VERSION]_[DATE].pdf`

---

## DOCUMENT 3 -- HANDOFF EMAIL DRAFT

Plain text draft for Brian to review, personalize, and send.

```
Subject: [APP NAME] v[VERSION] -- Project Complete + Handoff Documents

Hi [CLIENT NAME],

[APP NAME] is officially live and ready to use.

I've attached two documents to this email:

1. Client Handoff Guide -- everything you need to know to use your app,
   your access credentials, and a plain English summary of what was built.

2. Technical Documentation -- for any future developer who works on
   the codebase, or for your own records.

Your app is live at: [PROD_FRONTEND_URL]

It's been a pleasure building [APP NAME]. [ONE GENUINE SENTENCE about
something specific to the project -- pulled from PLANS.md session notes
or Brian fills in.]

[If next phase:]
I'd love to continue with [NEXT PHASE DESCRIPTION]. Let me know when
you're ready to discuss what's next.

[If no next phase:]
If you ever need additional features or support, I'm always available.

All the best,
Brian Onieal
Freelance AI Systems Engineer
[EMAIL]
```

**Saved to:** `handoff/[APP_NAME]_HANDOFF_EMAIL_DRAFT_[DATE].txt`

---

## OUTPUT FOLDER STRUCTURE

```
[PROJECT_ROOT]/
  handoff/
    [APP_NAME]_CLIENT_HANDOFF_v[VERSION]_[DATE].pdf
    [APP_NAME]_TECHNICAL_HANDOFF_v[VERSION]_[DATE].pdf
    [APP_NAME]_HANDOFF_EMAIL_DRAFT_[DATE].txt
```

---

## FILL IN TRACKER

After generating all documents, Claude outputs:

```
HANDOFF DOCUMENTS GENERATED

Saved to: [PROJECT_ROOT]/handoff/

Items requiring Brian's input before sending:
[ ] [APP_NAME]_CLIENT_HANDOFF -- Section 4: Vercel account name
[ ] [APP_NAME]_CLIENT_HANDOFF -- Section 4: Supabase dashboard URL
[ ] [APP_NAME]_CLIENT_HANDOFF -- Section 4: [SERVICE] credentials
[ ] [APP_NAME]_HANDOFF_EMAIL -- Personal sentence about the project
[ ] [APP_NAME]_TECHNICAL_HANDOFF -- Repository URL

Items auto-populated from project files:
✓ Production URLs (from DEPLOYMENT.md)
✓ Tech stack (from TECH_STACK.md)
✓ All commands (from CLAUDE.md)
✓ Changelog (from CHANGELOG.md)
✓ Test coverage (from TESTS.md)
✓ Agent definitions (from COUNCIL_AGENTS.md)
✓ Known issues (from ERRORS.md)
✓ Total hours and billed amount (from TIMELOG.md)
✓ Version history (from VERSION_ROADMAP.md)

Complete the [FILL IN] items, then send the documents to [CLIENT EMAIL].
```

---

## INTEGRATION WITH BUILD RULES

Triggered automatically at v1.0.0 gate close after:
- /testing confirms GATE STATUS: PASS
- /deploy confirms PRODUCTION DEPLOYMENT: SUCCESS

Build Rules sequence at project completion:
```
1. /testing POST-BUILD → GATE STATUS: PASS
2. /deploy → PRODUCTION DEPLOYMENT: SUCCESS
3. /handoff → AUTO-TRIGGERED
4. Documents generated → Brian fills in blanks → sends to client
5. Project marked COMPLETE in MASTER_BILLING.md
6. Final invoice generated via freelance-billing skill
```

---

## COMMAND WORDS

| You type | What happens |
|----------|--------------|
| `/handoff` | Invoke manually |
| `READY` | Questions answered, extract data and generate documents |
| `REGENERATE CLIENT` | Regenerate only the client PDF |
| `REGENERATE TECHNICAL` | Regenerate only the technical PDF |
| `REGENERATE EMAIL` | Regenerate only the email draft |
| `FILL [section] [value]` | Fill in a specific blank before regenerating |

---

## RULES

- Never send documents with [FILL IN] placeholders -- complete them first
- Client PDF must use plain English -- no technical jargon, no code
- Technical PDF must be complete enough for a stranger to run the app locally
- IP clause must appear in every client handoff -- ownership transfers on full payment
- Always generate all three documents in one session -- never partial handoff
- Save all documents to the handoff/ folder -- never overwrite previous handoffs
- After handoff is complete -- update MASTER_BILLING.md project status to COMPLETE
- After handoff is complete -- generate final invoice via /billing

---

# END OF HANDOFF SKILL v1.0
# Next version: v1.1 -- informed by first real handoff
