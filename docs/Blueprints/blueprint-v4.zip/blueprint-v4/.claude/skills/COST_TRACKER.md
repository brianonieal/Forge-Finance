---
name: cost-tracker
description: "App cost tracking and optimization skill for all builds. Tracks real-time build costs and operational costs. Estimates costs at 100/1000/10000 users before building. Flags cheaper alternatives on every technical decision. Issues soft block warnings at three thresholds: 25/mo development, 75/mo launch, 200/mo scale. Maintains COSTS.md per project and rolls up a summary to MASTER_BILLING.md."
---

# COST TRACKER SKILL
# Owner: Brian Onieal | Freelance AI Systems Engineer
# Version: 1.0 | April 2026
# Invoke: /costs

---

## WHAT THIS IS

The Cost Tracker skill monitors, estimates, and optimizes the operational
cost of every app Brian builds and deploys.

It operates in two modes:
- **BUILD MODE:** Tracks token usage and API costs during active development.
  Estimates costs before architectural decisions are made.
- **OPERATIONAL MODE:** Tracks monthly running costs after deployment.
  Monitors free tier limits. Flags threshold breaches.

Every technical decision Claude makes that has a cost implication
gets a cost note automatically -- no need to ask.

---

## COST THRESHOLDS

Three tiered thresholds apply to every project.
All are configurable per project in COSTS.md.

| Tier | Default Threshold | Context |
|------|------------------|---------|
| DEVELOPMENT | $25/month | You're paying, keep it tight |
| LAUNCH | $75/month | First ~1000 users |
| SCALE | $200/month | ~10,000 users |

**Threshold behavior:**
- Below threshold: proceed normally
- Approaching threshold (>80%): advisory warning
- At or above threshold: soft block -- Claude explains, shows cheaper
  alternative, requires explicit confirmation before proceeding

**Per-project override:**
Thresholds can be adjusted in COSTS.md for each project.
Client projects where client pays operating costs:
- LAUNCH threshold: $100/month
- SCALE threshold: $500/month

---

## INVOCATION

When `/costs` is invoked, Claude asks:

---

"Cost tracking session started.

1. Is this a new project (set up COSTS.md) or existing (review current costs)?
2. Who pays operating costs -- you or the client?
3. Are there any hard budget constraints I should know about?
4. What environment -- development, staging, or production?

Type READY when done."

---

## PHASE 1 -- COSTS.md INITIALIZATION

On first invocation for a new project, Claude creates COSTS.md
by reading CONTRACT.md and TECH_STACK.md to identify all services.

### COSTS.md structure:

```markdown
# COSTS.md — Cost Tracking & Optimization
# App: [APP NAME]
# Client: [CLIENT NAME or "Brian Onieal (personal)"]
# Pays operating costs: [Brian / Client]
# Last updated: [DATE]

---

## COST THRESHOLDS

| Tier | Threshold | Status |
|------|-----------|--------|
| Development | $25/month | ACTIVE |
| Launch (1K users) | $75/month | ACTIVE |
| Scale (10K users) | $200/month | ACTIVE |

---

## CURRENT MONTHLY ESTIMATE

**Environment:** [Development / Production]
**Date range:** [DATE] to [DATE]
**Estimated users:** [N]

| Service | Tier | Cost/month | Notes |
|---------|------|------------|-------|
| Vercel | Free/Pro | $0 / $20 | Frontend hosting |
| Render / Railway | Free/Paid | $0 / $7+ | Backend hosting |
| Supabase | Free/Pro | $0 / $25 | Database + auth |
| Anthropic API | Pay-per-use | $[X] | Estimated at [N] calls/day |
| [OTHER SERVICE] | [TIER] | $[X] | [notes] |

**TOTAL ESTIMATED:** $[X]/month
**THRESHOLD STATUS:** [UNDER / APPROACHING / AT / OVER] [TIER]

---

## AI COST BREAKDOWN

| Agent / Use case | Model | Est. calls/day | Avg tokens/call | Cost/day | Cost/month |
|-----------------|-------|----------------|-----------------|----------|------------|
| [AGENT_NAME] | claude-sonnet-4-6 | [N] | [N] | $[X] | $[X] |
| [AGENT_NAME] | claude-haiku-4-5 | [N] | [N] | $[X] | $[X] |
| **TOTAL** | | | | **$[X]** | **$[X]** |

---

## BUILD COSTS (Development phase)

| Date | Service | Usage | Cost | Session |
|------|---------|-------|------|---------|
| [DATE] | Anthropic API (Claude Code) | [X] tokens | $[X] | [gate] |
| [DATE] | Supabase | [X] DB calls | $0 (free tier) | [gate] |

**Total build cost to date:** $[X]

---

## FREE TIER MONITOR

| Service | Free Limit | Current Usage | % Used | Alert at |
|---------|-----------|---------------|--------|----------|
| Vercel | 100GB bandwidth | [X]GB | [X]% | 80% |
| Render | 750hrs/month | [X]hrs | [X]% | 80% |
| Supabase | 500MB DB | [X]MB | [X]% | 80% |
| Anthropic | N/A (pay-per-use) | — | — | — |

---

## COST OPTIMIZATION LOG

| Date | Decision | Original cost | Optimized cost | Saving/month |
|------|----------|--------------|----------------|--------------|
| [DATE] | Switched @ROUTER from Sonnet to Haiku | $45/mo | $4/mo | $41/mo |
| [DATE] | [decision] | $[X] | $[X] | $[X] |

**Total monthly savings from optimizations:** $[X]

---

## COST DECISIONS LOG

Decisions where cost threshold was approached or exceeded:

| Date | Decision | Cost impact | Threshold hit | Brian's choice |
|------|----------|-------------|---------------|----------------|
| [DATE] | [decision] | +$[X]/mo | LAUNCH | Proceed / Alternative chosen |

---

## SCALE PROJECTIONS

Estimated monthly cost at different user scales:

| Users | AI costs | Hosting | Database | Other | Total |
|-------|----------|---------|----------|-------|-------|
| 100 | $[X] | $[X] | $[X] | $[X] | $[X] |
| 1,000 | $[X] | $[X] | $[X] | $[X] | $[X] |
| 10,000 | $[X] | $[X] | $[X] | $[X] | $[X] |
| 100,000 | $[X] | $[X] | $[X] | $[X] | $[X] |

---

## UPGRADE TRIGGERS

When to upgrade each service (based on free tier limits and cost):

| Service | Upgrade when | Upgrade to | New cost |
|---------|-------------|------------|----------|
| Render free | 750hrs/mo exceeded OR app sleeps too often | Starter $7/mo | $7/mo |
| Supabase free | 500MB DB OR 2GB bandwidth approached | Pro $25/mo | $25/mo |
| Vercel free | 100GB bandwidth approached | Pro $20/mo | $20/mo |

---

## MASTER_BILLING SUMMARY (auto-synced)
Monthly operating cost: $[X]
Build cost to date: $[X]
Total project cost: $[X]
```

---

## PHASE 2 -- BUILD MODE

### Token tracking during development

At the start of every Claude Code session, Claude notes:
```
BUILD COST TRACKER ACTIVE
Session start: [TIME]
Current gate: [VERSION]
Running build cost: $[X] (from COSTS.md)
```

At the end of every session, Claude updates COSTS.md:
```
SESSION COST UPDATE
Duration: [X] minutes
Estimated tokens used: [X]
Estimated session cost: $[X]
Running total: $[X]
```

### Pre-decision cost estimation

Every time Claude proposes a technical decision with cost implications,
it automatically includes a cost note BEFORE Brian approves:

```
COST NOTE: [DECISION]

This approach:
  Model: claude-sonnet-4-6
  Est. calls/day: 50
  Avg tokens/call: 2,000
  Monthly cost: ~$45/month at 1,000 users

Cheaper alternative:
  Model: claude-haiku-4-5
  Same est. calls/day: 50
  Avg tokens/call: 2,000
  Monthly cost: ~$3.75/month at 1,000 users
  Capability tradeoff: Haiku handles routing and classification
  well. Use Sonnet only for complex reasoning tasks.

Recommendation: Use Haiku for [this specific task].
Reserve Sonnet for [tasks that genuinely need it].

Current threshold status: [UNDER / APPROACHING / AT] LAUNCH ($75/mo)
```

### Threshold warning format:

**APPROACHING (>80% of threshold):**
```
⚠️ COST WARNING: APPROACHING [TIER] THRESHOLD

Current estimated monthly cost: $[X]
[TIER] threshold: $[X]
You are at [X]% of your [TIER] threshold.

This decision would add $[X]/month.
Projected total: $[X]/month ([X]% of threshold)

Cheaper alternative available: [description] -- saves $[X]/month

Proceeding with current approach. Monitor closely.
```

**AT OR OVER THRESHOLD:**
```
🛑 COST SOFT BLOCK: [TIER] THRESHOLD REACHED

Current estimated monthly cost: $[X]
[TIER] threshold: $[X]
This decision would put you at $[X]/month -- OVER threshold.

Cheaper alternative:
[description] -- would cost $[X]/month instead ([X]% of threshold)

To proceed with the original approach, type: CONFIRM COST OVERRIDE
To use the cheaper alternative, type: USE ALTERNATIVE
To discuss options, type: EXPLAIN OPTIONS

Claude will not implement this decision until you respond.
```

---

## PHASE 3 -- OPERATIONAL MODE

After deployment, Claude monitors running costs.

### Free tier monitoring

Claude checks free tier usage when:
- `/costs` is invoked manually
- `/deploy` is run (pre-deployment check includes cost review)
- A gate is closed in Build Rules

```
FREE TIER STATUS CHECK

Vercel:
  Bandwidth: [X]GB / 100GB ([X]%) [OK / ⚠️ APPROACHING / 🛑 CRITICAL]
  Build minutes: [X] / 6,000 ([X]%)

Render:
  Hours: [X] / 750 ([X]%) [OK / ⚠️ APPROACHING / 🛑 CRITICAL]
  Note: Free tier apps sleep after 15min inactivity

Supabase:
  Database: [X]MB / 500MB ([X]%) [OK / ⚠️ APPROACHING / 🛑 CRITICAL]
  Bandwidth: [X]GB / 2GB ([X]%)

[If any service is CRITICAL:]
UPGRADE RECOMMENDED: [service]
Upgrade to: [tier] at $[X]/month
Trigger: [why now]
Impact of not upgrading: [consequence]
```

### Scale projections update

Every time COSTS.md is updated, Claude recalculates scale projections
and flags if projected costs at scale would breach thresholds:

```
SCALE PROJECTION UPDATE

At current architecture:
  100 users:    $[X]/month [OK]
  1,000 users:  $[X]/month [OK / ⚠️ / 🛑]
  10,000 users: $[X]/month [OK / ⚠️ / 🛑]

[If scale projection breaches threshold:]
At 10,000 users this app would cost $[X]/month -- above SCALE threshold.
Consider: [architectural change that would reduce cost at scale]
```

---

## AI MODEL COST REFERENCE

Claude uses these rates for all cost calculations.
Update if Anthropic pricing changes.

| Model | Input (per MTok) | Output (per MTok) | Best for |
|-------|-----------------|-------------------|---------|
| claude-opus-4-6 | $15.00 | $75.00 | Architecture decisions only |
| claude-sonnet-4-6 | $3.00 | $15.00 | Complex reasoning, generation |
| claude-haiku-4-5 | $0.25 | $1.25 | Routing, classification, simple tasks |

### Model selection rules for cost optimization:
- **Always use Haiku** for: routing, classification, simple extraction,
  format conversion, yes/no decisions
- **Use Sonnet** for: complex reasoning, code generation, nuanced analysis,
  agent coordination
- **Use Opus** for: architecture planning only -- never in production agent loops
- **Cache aggressively:** Prompt caching reduces costs by 90% on repeated
  system prompts -- always structure prompts to maximize cache hits

### Hosting cost reference:

| Service | Free tier | Paid tier 1 | Paid tier 2 |
|---------|-----------|-------------|-------------|
| Vercel | $0 (100GB BW) | Pro $20/mo | Enterprise custom |
| Render | $0 (sleeps) | Starter $7/mo | Standard $25/mo |
| Railway | $0 (500hrs) | Pro $20/mo | — |
| Supabase | $0 (500MB) | Pro $25/mo | Team $599/mo |
| Neon | $0 (0.5GB) | Launch $19/mo | Scale $69/mo |

---

## MASTER_BILLING.md INTEGRATION

After every COSTS.md update, Claude adds a one-line summary
to the relevant project row in MASTER_BILLING.md:

```
| [APP NAME] | [CLIENT] | [REF] | [DATE] | IN PROGRESS |
  Billed: $[X] | Operating cost: $[X]/mo | Net margin: $[X] |
```

This gives Brian a profit-per-project view in one place.

---

## COMMAND WORDS

| You type | What happens |
|----------|--------------|
| `/costs` | Invoke cost tracking session |
| `READY` | Questions answered, initialize or review COSTS.md |
| `CONFIRM COST OVERRIDE` | Proceed despite threshold breach |
| `USE ALTERNATIVE` | Claude implements cheaper alternative |
| `EXPLAIN OPTIONS` | Claude explains all cost options in detail |
| `PROJECTION` | Show scale cost projections at 100/1K/10K/100K users |
| `OPTIMIZE` | Claude audits current architecture for cost savings |
| `FREE TIER STATUS` | Check all free tier usage levels |
| `UPDATE` | Re-calculate all costs and update COSTS.md |

---

## OPTIMIZE MODE

When Brian types `OPTIMIZE`, Claude audits the entire
current architecture for cost reduction opportunities:

```
COST OPTIMIZATION AUDIT: [APP NAME]

Current monthly cost: $[X]

Optimization opportunities found:

1. [OPPORTUNITY] -- saves $[X]/month
   Current: [what's happening]
   Change: [what to do instead]
   Tradeoff: [what if any capability is affected]
   Effort: [LOW / MEDIUM / HIGH]

2. [OPPORTUNITY] -- saves $[X]/month
   [same format]

Total potential savings: $[X]/month
Recommended changes (effort vs. saving):
1. [highest ROI change first]
2. [next]

Type APPLY [N] to apply a specific optimization,
or APPLY ALL to apply all recommended changes."
```

---

## INTEGRATION WITH BUILD RULES

Cost Tracker integrates with Build Rules at three points:

**1. Phase 1 interrogation (1F -- Technical Constraints):**
Build Rules automatically asks about budget constraints.
Claude initializes COSTS.md framework from the interrogation answers.

**2. Every architectural decision:**
Any time Claude proposes a stack choice, model selection, or service
during the build -- cost note is automatic. No need to invoke /costs.

**3. Gate close:**
Before closing any gate, Claude checks COSTS.md and reports:
```
GATE COST SUMMARY: [VERSION]
Build cost this gate: $[X]
Running build total: $[X]
Current operational estimate: $[X]/month
Threshold status: [OK / WARNING / SOFT BLOCK]
```

---

## RULES

- Every model selection decision gets a cost comparison automatically
- Every new service added to the stack gets a cost note automatically
- Free tier limits are monitored at every deploy and gate close
- Scale projections are recalculated whenever architecture changes
- Never recommend a more expensive approach without showing the cheaper alternative
- Cost threshold warnings are soft blocks -- Brian always has final say
- COSTS.md is version controlled -- commit it with the project
- MASTER_BILLING.md is updated after every COSTS.md change
- If operational costs exceed SCALE threshold -- escalate to Brian immediately
  regardless of what else is happening in the session

---

# END OF COST TRACKER SKILL v1.0
# Next version: v1.1 -- informed by first real cost tracking session
