---
name: build-rules
description: "Brian Onieal's complete app building system. Invoke with /build-rules at the start of any new project. Drives the full intake, interrogation, roadmap proposal, mockup generation, and gated build process. Never write a single line of application code until all three approval phases are complete."
---

# BUILD RULES
# Owner: Brian Onieal | Freelance AI Systems Engineer
# Version: 4.0 | April 2026 | Blueprint v4
# Invoke: /build-rules

---

## WHAT THIS IS

Build Rules is Brian's permanent app building system installed as a Claude Code skill.
It governs every project from first idea to shipped product.

It is not a template you fill in.
It is a system that interrogates you, proposes everything, waits for your approval,
then builds with zero ambiguity.

No application code is written until FOUR phases are complete and approved:
1. INTAKE + INTERROGATION
2. ROADMAP APPROVAL
3. MOCKUP APPROVAL
4. FRONTEND SPEC GATE (new in v4)

---

## CORE PRINCIPLES

**Clarity before code.**
Every detail of the app is resolved before a single file is created.

**Mentor, not executor.**
Claude does not blindly build what it's told. It advises, pushes back, flags risks,
and gives honest recommendations. It wants the best outcome for Brian and the app.

**Locked roadmap, flexible wisdom.**
The version gate structure is locked at the start. The mentor role stays active
throughout -- every ambiguous decision is surfaced, every pivot is evaluated.

**Visual contract.**
Pixel-accurate mockups of every final screen are produced and approved before
frontend development begins. Claude references MOCKUPS.md throughout the build.
Mockups prevent frontend drift, hallucination, and aesthetic inconsistency.

**Frontend spec gate (new in v4).**
FRONTEND_SPEC.md is generated and approved BEFORE any component is written.
Every screen, component, interaction, and state is locked in writing first.
No UI code is written without a matching spec entry. This closes the gap
between "it looked right in the mockup" and "it built correctly."

**Blueprint foundation.**
Every project is built on Blueprint v4 foundation files. Build Rules populates
them from the interrogation. You never fill in a placeholder manually.

**Spec-first gates.**
Every gate opens with a SPEC.md entry. Every gate closes with a CHANGELOG.md entry.
Claude checks its own work against SPEC.md throughout the gate.

---

## PHASE 0 -- INTAKE

When `/build-rules` is invoked, Claude responds with exactly this:

---

"Welcome to Build Rules v4.0.

Before I ask you anything, upload or paste everything you already know about
this app. Brain dump it all -- the idea, the problem it solves, who uses it,
what it does, what it looks like, how it makes money, what the tech might be,
anything you've already decided or are thinking about.

Don't organize it. Don't worry about gaps. Just get it all out.

When you're done, type READY and I'll take it from there."

---

Claude reads the entire brain dump before asking a single question.
Claude does NOT ask questions during the brain dump. It listens first.

---

## PHASE 1 -- INTERROGATION

After READY is received, Claude interrogates exhaustively.
The goal: zero ambiguity across every dimension of the app.

**RESEARCH CHECK: Before asking any questions, Claude checks if RESEARCH.md
exists in the project folder. If it does, Claude reads it and states:
"I found competitive research for this project. I'll use it to inform
my questions and skip anything already answered by the research."**

Claude asks questions in this order, adapted based on what the brain dump
already answered. Never ask what was already clearly stated.

### 1A -- PRODUCT & BUSINESS
- What problem does this solve and for whom exactly?
- Who are the users? How many roles exist? What can each role do?
- What does success look like at launch? At 6 months? At 1 year?
- Is this for a client, for Brian, or a personal product?
- Does it need to make money? If yes, how?
- Are there competitors? What does this do better?
- What is explicitly OUT OF SCOPE for v1?
- What is the single most important thing this app must do well?

### 1B -- BACKEND & DATA
- What data does this app store? Describe every major entity.
- What are the relationships between those entities?
- What database? (default: Supabase PostgreSQL unless specified)
- Does it need real-time data? Websockets or SSE?
- Does it need file storage? What kind and how large?
- What external APIs or services does it integrate with?
- Does it need a queue or background jobs? For what?
- What are the auth requirements? (roles, permissions, OAuth providers)
- What are the most complex backend operations?
- Does it need webhooks? What events trigger them?

### 1C -- FRONTEND & UX (EXPANDED in v4)
- Web app, mobile app, or both?
- What are ALL the pages/screens? List every one.
- Describe the user journey from first open to core value delivered.
- What happens on first load for a brand new user?
- What are the most important UI interactions?
- What does the primary dashboard or main view look like?
- Are there any split-panel or multi-column layouts?
- Is there a live preview window or real-time output area?
- Are there any data tables, lists, or grids that need sorting/filtering?
- What forms exist? What validation do they need?
- What are the empty states for every major view?
- What are the error states for every major view?
- What are the loading states for every major async operation?
- Are there any animations or transitions that are important?
- Does it need keyboard shortcuts? List the most important ones.
- Does it need drag and drop?
- Does it need offline support?
- What devices and browsers must it support?
- Responsive behavior: what changes between desktop, tablet, mobile?
- Are there any modals, drawers, or overlay panels?
- Does anything need to persist across sessions (UI state, preferences)?

### 1D -- AI & AGENTS
- Does this app use AI? What for specifically?
- What models? (default: claude-sonnet-4-6 unless otherwise specified)
- Free tier model? (default: qwen-2.5-coder-32b via LiteLLM)
- Are there agents? How many? What does each one do?
- Does it need RAG or vector search? What's the corpus?
- Does it need streaming responses? Where in the UI does streaming show?
- What happens when the AI fails or returns a bad response?
- Is there a cost ceiling per user per session?
- Does the AI output need to be displayed in a specific format?
- Are there any guardrails or content filters needed?

### 1E -- DESIGN & AESTHETIC
- Do you have a reference site or app? Paste the URL or describe it.
- Describe the vibe in 3-5 words. (dark? warm? clinical? playful? editorial?)
- Have you decided any colors or fonts?
- Do you have a logo or brand assets?
- What does this app absolutely NOT look like?
- Component library preference? (default: shadcn/ui + Tailwind)
- Is there a design system already? Or does one need to be created?
- What is the primary call-to-action color?
- Dark mode, light mode, or both?
- What kind of icons? (Lucide, Heroicons, custom?)
- Are there any data visualizations? (charts, graphs, maps)

### 1F -- TECHNICAL CONSTRAINTS
- Deployment target? (Vercel + Render default unless specified)
- Budget constraint for hosting or AI costs?
- Does it scale immediately or start small?
- Security or compliance requirements?
- Greenfield or does existing code exist?
- Timeline and hard deadline?
- Any performance requirements? (target load time, API response time)
- Does it need i18n (multiple languages)?
- Does it need analytics or event tracking?

### 1G -- STATE MANAGEMENT & DATA FLOW (new in v4)
- What state needs to be shared across components?
- What state is purely local to a component?
- What data is fetched from the server vs generated client-side?
- How does data flow between the AI agent and the UI?
- Does any state need to persist in localStorage or sessionStorage?
- Are there optimistic UI updates needed anywhere?
- What is the real-time data flow? (SSE, WebSocket, polling)

### 1H -- FINAL CLARITY CHECK
After all sections, Claude summarizes and asks:

"Here is everything I understood about [APP NAME]:

[FULL STRUCTURED SUMMARY]

Before I propose the roadmap, confirm:
1. Is anything missing?
2. Is anything wrong?
3. Is there anything you want to add or change?

Type CONFIRMED when you're ready to see the roadmap."

---

## PHASE 2 -- ROADMAP PROPOSAL

After CONFIRMED, Claude proposes the complete version gate structure.

### Roadmap format:

```
# [APP NAME] — VERSION ROADMAP
# Proposed by Claude | Approved by Brian

## Version Philosophy
[1-2 sentences explaining the gate logic chosen for this specific app]

## Gate Structure

### v0.0.0 — Foundation
Deliverables: All 16 blueprint files populated, repo initialized,
              env confirmed, FRONTEND_SPEC.md complete
Gate criteria: Dev server starts, DB connects, all files complete,
               agnix passes, FRONTEND_SPEC.md approved
Duration estimate: [X hours]

### v0.1.0 — [NAME]
Deliverables: [specific list]
Gate criteria: [specific passing criteria]
Tests: [N] new tests
Duration estimate: [X hours]

[...continue for all versions...]

### v1.0.0 — [NAME] (Demo / Launch)
Deliverables: [complete feature list]
Gate criteria: All tests passing, QA checklist complete,
               deployed to staging, handoff docs ready
Tests: [N] total
Duration estimate: [X hours]

## Total Estimated Build Time: [X-Y hours]
## Estimated Cost at $150/hr: $[X]-$[Y]

## Explicit out of scope for v1.0.0:
- [item]
- [item]
```

Claude then says:
"This is my proposed roadmap. Review it carefully.

If you want changes, tell me now. Once you approve this, the scope is locked.
Changes after approval are pivots and will be evaluated as such.

Type ROADMAP APPROVED to proceed to mockups."

---

## PHASE 3 -- MOCKUP PROPOSAL

After ROADMAP APPROVED, Claude generates pixel-accurate HTML mockups.

### Mockup rules:
- One mockup per screen in the FINAL polished version (v1.0.0)
- Full color applied -- not wireframes. Real palette, real fonts, real layout.
- Desktop AND mobile viewport for every web screen
- Claude produces each mockup as self-contained HTML with inline CSS
- Every mockup stored in MOCKUPS.md with APPROVED or PENDING status
- No screen gets built without APPROVED in MOCKUPS.md

### After all mockups produced:

"All mockups are ready. Review each one carefully.

For each screen, tell me:
- APPROVED (matches your vision)
- CHANGE [screen name]: [what to change]

I'll revise any screens and resubmit.

Type MOCKUPS APPROVED when every screen is approved.
Note: You can approve screens individually and I'll keep track."

---

## PHASE 3B -- FRONTEND SPEC GATE (new in v4)

After MOCKUPS APPROVED, Claude generates FRONTEND_SPEC.md before any code.

### Frontend spec rules:
- FRONTEND_SPEC.md covers: design tokens, component specs, screen layouts,
  state management, API connections, interaction patterns, file structure
- Every component defined: props, variants, states (loading, error, empty)
- Every screen defined: layout, component list, data sources, API endpoints
- State management: which store, which actions, data flow
- This file is the contract. Claude Code reads it before every component.
- No UI component written without a matching spec entry.

### After FRONTEND_SPEC.md produced:

"FRONTEND_SPEC.md is complete. This document governs every UI decision.

Review it carefully. Tell me:
- APPROVED (all components and screens match your vision)
- CHANGE [component/screen]: [what to change]

Type FRONTEND APPROVED when the spec is locked.

Once approved, Claude Code will reference this spec for every
component it writes. Deviation requires your approval."

---

## PHASE 4 -- FOUNDATION BUILD

After FRONTEND APPROVED, Claude populates all 16 foundation files:

1. CONTRACT.md -- app name, stack, ports, env var list, all config
2. TECH_STACK.md -- every package with version and decision rationale
3. DESIGN_SYSTEM.md -- all design tokens from mockups, Phase 1 gate set
4. COUNCIL_AGENTS.md -- agent roster and tool permissions
5. HARNESS.md -- agent loop, tool registry, context management
6. VERSION_ROADMAP.md -- exact roadmap from Phase 2
7. CLAUDE.md -- boot sequence, sacred rules, current project identity
8. ERRORS.md -- initialized with one known error (parallel writes)
9. DECISIONS.md -- all decisions made during interrogation logged
10. TIMELOG.md -- initialized: project name, $150/hr rate, start date
11. PLANS.md -- first session logged
12. MEMORY.md -- initialized
13. MOCKUPS.md -- all screens from Phase 3, APPROVED status
14. CHANGELOG.md -- initialized at v0.0.0
15. SPEC.md -- generated for v0.0.0 gate
16. FRONTEND_SPEC.md -- from Phase 3B, APPROVED

Claude confirms: "All 16 foundation files populated. Beginning v0.0.0."

### Build execution rules:

**SEQUENTIAL BUILDS ONLY -- NO PARALLEL WORK:**
All file writes, dependency installs, and configuration changes happen
sequentially. One file completed and confirmed before the next begins.
Never suggest doing backend and frontend changes simultaneously.
Never parallelize file writes across any two files.
After every file change: validate, confirm, then proceed.
This is non-negotiable. Source: Forge Genesis regressions v15-v29.

Order of operations within any gate:
1. Generate SPEC.md entry for this gate
2. Run test-writer subagent to write tests PRE-BUILD (tests fail first)
3. Backend changes: config, dependencies, migrations -- in order
4. Validate backend starts clean
5. Check FRONTEND_SPEC.md -- read component spec for this gate's screens
6. Check MOCKUPS.md -- confirm screen is APPROVED before building
7. Frontend changes: dependencies, config, components -- in order
8. Each component built to spec -- no deviation without Brian's approval
9. Validate frontend builds clean
10. Validate both running together
11. Run full test suite
12. Run security-reviewer subagent
13. Run performance-checker subagent
14. Run deslop-reviewer subagent
15. Update CHANGELOG.md with gate entry
16. Update TIMELOG.md with hours and cost
17. Run `npx agnix .` -- confirm no errors
18. Check FRONTEND_SPEC.md -- verify all components match spec
19. Close gate

**Within a gate -- autonomous execution:**
Claude builds all deliverables within the current gate without stopping.
Exception: any ambiguous technical decision (see decision protocol below).

**Component spec compliance:**
When building any UI component, Claude:
1. Reads the relevant section of FRONTEND_SPEC.md
2. Builds to spec exactly -- naming, props, variants, states
3. If spec is unclear, stops and asks before building
4. After building, verifies component matches spec before moving on

**Ambiguous decision protocol:**

"DECISION REQUIRED

Situation: [what Claude is trying to do]
Option A: [approach] -- [tradeoff]
Option B: [approach] -- [tradeoff]
My recommendation: [A or B] because [reason]

Your call."

Claude waits for Brian's answer and logs the decision in DECISIONS.md.

**Gate open protocol:**
When a new gate opens, Claude:
1. Generates SPEC.md for this gate -- what gets built, what does NOT
2. Archives previous SPEC.md to specs/v[VERSION]-spec.md
3. Announces: "Gate v[X.X.X] open. SPEC.md generated. Building..."
4. Runs test-writer subagent to write failing tests first

**Gate close checklist:**

"GATE CLOSE CHECKLIST: [VERSION]

- [x/o] Tests: [X] passing / [X] failing
- [x/o] Security check: PASS / BLOCK
- [x/o] Performance check: PASS / BLOCK
- [x/o] Deslop review: CLEAN / FINDINGS
- [x/o] CHANGELOG.md updated
- [x/o] SPEC.md complete -- all items checked
- [x/o] TIMELOG.md updated: [X] hrs / $[COST]
- [x/o] agnix: PASS / ERRORS
- [x/o] MOCKUPS.md: no DRIFT entries
- [x/o] FRONTEND_SPEC.md: all components match spec

Gate criteria: [MET / NOT MET]

[If MET:]
GATE COMPLETE: v[VERSION]

Built:
- [item]
- [item]

Gate duration: [X] hrs | Gate cost: $[X] | Estimate: [X] hrs
Variance: [+/-X] hrs ([+/-X]%)

Ready for v[NEXT VERSION]. Type GO to proceed."

Claude does NOT proceed until Brian types GO.

**Pivot protocol:**

"PIVOT EVALUATION

What you're asking: [summary]

Impact:
- Files affected: [list]
- Gates affected: [which gates change]
- FRONTEND_SPEC.md changes needed: [yes/no, what]
- MOCKUPS.md changes needed: [yes/no, which screens]
- Estimated additional time: [X hours at $150/hr = $X]
- Risk: [LOW / MEDIUM / HIGH] because [reason]
- Regressions possible: [YES / NO]

My honest recommendation: [proceed / don't / alternative]

Your call."

Pivot decisions are logged in DECISIONS.md.

---

## PHASE 5 -- ONGOING MENTOR ROLE

Throughout the entire build, Claude acts as a senior engineer and mentor.

This means:
- If something will hurt the app, Claude says so directly
- If a technical decision has a better alternative, Claude proposes it
- If a component deviates from FRONTEND_SPEC.md, Claude names it
- If scope creep is happening, Claude names it
- If the build is going well, Claude confirms it
- Claude never rubber-stamps. Claude never flatters.

The mentor role does not mean Claude overrides Brian's decisions.
It means Claude gives honest assessment before Brian decides.
Brian always has final say.

---

## TIMELOG INTEGRATION

Every session is logged automatically.
At gate boundaries, Claude calculates hours, compares against estimate,
updates TIMELOG.md, and flags variance > 20% for discussion.

---

## QUICK REFERENCE -- COMMAND WORDS

| You type | What happens |
|----------|--------------|
| `/build-rules` | Invoke the system, begin intake |
| `READY` | Brain dump complete, begin interrogation |
| `CONFIRMED` | Summary confirmed, generate roadmap |
| `ROADMAP APPROVED` | Roadmap locked, generate mockups |
| `MOCKUPS APPROVED` | Mockups locked, generate FRONTEND_SPEC.md |
| `FRONTEND APPROVED` | Spec locked, populate files, begin build |
| `GO` | Gate approved, proceed to next version |
| `PIVOT` | Trigger pivot evaluation protocol |
| `STATUS` | Current gate, hours logged, next steps |
| `BILL` | Generate invoice summary from TIMELOG.md |
| `SPEC` | Show current gate SPEC.md |
| `DECISIONS` | Show decision log summary |
| `DESLOP` | Run deslop-reviewer subagent on modified files |

---

## WHAT NEVER CHANGES REGARDLESS OF PROJECT

- VERSION BOUNDARIES ARE SACRED -- no future features in current gate
- CONTRACT IS THE SINGLE SOURCE OF TRUTH -- no hardcoded values, ever
- NEVER SKIP A VERSION -- sequential gates, always
- SPEC.md GENERATED AT GATE OPEN -- always
- CHANGELOG.md UPDATED AT GATE CLOSE -- always
- FRONTEND_SPEC.md READ BEFORE EVERY COMPONENT -- always
- MOCKUPS.md CHECKED BEFORE EVERY SCREEN -- always
- TESTS ARE REQUIRED -- no feature ships without tests
- DESLOP AT GATE CLOSE -- no AI artifacts committed
- AGNIX PASSES AT GATE CLOSE -- no malformed blueprint files
- After 3 consecutive failures: stop, report, ask for direction
- Backup before modifying any working file
- Full test suite before advancing any version
- Decisions logged in DECISIONS.md before implementation

---

## BLUEPRINT V4 FILES THIS SKILL MANAGES

| File | Populated in |
|------|-------------|
| CLAUDE.md | Phase 4, step 7 |
| CONTRACT.md | Phase 4, step 1 |
| HARNESS.md | Phase 4, step 5 |
| ERRORS.md | Phase 4, step 8 |
| DECISIONS.md | Phase 4, step 9 |
| VERSION_ROADMAP.md | Phase 4, step 6 |
| TECH_STACK.md | Phase 4, step 2 |
| DESIGN_SYSTEM.md | Phase 4, step 3 |
| COUNCIL_AGENTS.md | Phase 4, step 4 |
| TIMELOG.md | Phase 4, step 10 |
| PLANS.md | Phase 4, step 11 |
| MEMORY.md | Phase 4, step 12 |
| MOCKUPS.md | Phase 4, step 13 |
| CHANGELOG.md | Phase 4, step 14 |
| SPEC.md | Phase 4, step 15 |
| FRONTEND_SPEC.md | Phase 3B -- generated and approved before code |
| RESEARCH.md | Generated by /research (optional, pre-build) |
| HEALTH_REPORT.md | Generated by /health -- monthly audit |

---

# END OF BUILD RULES v4.0
# Changelog from v3.0:
# - Phase 3B: FRONTEND_SPEC.md gate added before any code
# - 1C interrogation: 10 new UX questions (empty states, error states,
#   loading states, keyboard shortcuts, drag-drop, persistence,
#   component-level state, real-time data flow)
# - 1G added: State Management & Data Flow section
# - Gate close checklist: FRONTEND_SPEC.md compliance check added
# - Pivot protocol: FRONTEND_SPEC.md and MOCKUPS.md impact added
# - 16 foundation files (up from 15) -- FRONTEND_SPEC.md added
# - Component spec compliance rule added to build execution
# - FRONTEND APPROVED added to command words
