---
name: performance
description: "Comprehensive performance auditing skill for all app builds. Covers frontend load speed, backend API response time, database query performance, and AI agent pipeline optimization. Runs lightweight checks at every gate and a full audit before production deployment alongside security. Auto-triggers pre-deploy. Fixes CRITICAL and HIGH issues autonomously. Maintains PERFORMANCE.md as the permanent performance log across all sessions."
---

# PERFORMANCE SKILL
# Owner: Brian Onieal | Freelance AI Systems Engineer
# Version: 1.0 | April 2026
# Invoke: /performance OR auto-triggered before production deploy

---

## WHAT THIS IS

The Performance skill audits and optimizes every app Brian builds
across four layers:

1. **Frontend** -- load speed, bundle size, rendering, images, caching
2. **Backend** -- API response time, middleware overhead, endpoint efficiency
3. **Database** -- query performance, N+1 problems, missing indexes, pgvector
4. **AI Pipeline** -- LLM call chains, token efficiency, latency, parallelization

It runs in two modes:
- **LIGHTWEIGHT:** Quick check at every gate boundary (~12 checks)
- **FULL AUDIT:** Comprehensive four-layer audit before production

CRITICAL and HIGH findings are fixed autonomously.
MEDIUM and LOW findings are surfaced with severity and wait for approval.

---

## PERFORMANCE THRESHOLDS

These are the targets every app Brian builds must hit before production.

### Frontend
| Metric | Target | Critical threshold |
|--------|--------|-------------------|
| First Contentful Paint (FCP) | < 1.8s | > 3.0s |
| Largest Contentful Paint (LCP) | < 2.5s | > 4.0s |
| Time to Interactive (TTI) | < 3.8s | > 7.3s |
| Cumulative Layout Shift (CLS) | < 0.1 | > 0.25 |
| Total bundle size (JS) | < 200KB gzipped | > 500KB |
| Lighthouse score | > 90 | < 70 |

### Backend
| Metric | Target | Critical threshold |
|--------|--------|-------------------|
| API response time (p50) | < 200ms | > 1000ms |
| API response time (p95) | < 500ms | > 2000ms |
| API response time (p99) | < 1000ms | > 5000ms |
| Health check endpoint | < 50ms | > 200ms |

### Database
| Metric | Target | Critical threshold |
|--------|--------|-------------------|
| Simple query | < 10ms | > 100ms |
| Complex join | < 50ms | > 500ms |
| Full text / vector search | < 100ms | > 1000ms |
| Write operations | < 20ms | > 200ms |

### AI Pipeline
| Metric | Target | Critical threshold |
|--------|--------|-------------------|
| Single LLM call (Haiku) | < 1s | > 3s |
| Single LLM call (Sonnet) | < 3s | > 8s |
| Full agent response (simple) | < 5s | > 10s |
| Full agent response (complex) | < 15s | > 30s |
| Streaming first token | < 500ms | > 2s |

---

## AUTO-TRIGGER

Performance auto-triggers at two points:

**1. Gate boundary (lightweight):**
When Build Rules closes any gate, Claude runs the lightweight
performance check automatically before logging GATE COMPLETE.

**2. Pre-production (full audit):**
When `/deploy` reaches the PROMOTE step, Claude runs the full
performance audit alongside the security audit:

```
PERFORMANCE AUDIT REQUIRED

Production deployment is blocked until performance audit passes.
Running full performance audit for [APP NAME] v[VERSION]...
```

---

## LIGHTWEIGHT GATE CHECK

Runs at every gate close. Covers the 12 most impactful checks.

### The 12 Lightweight Checks:

**P-01: Bundle size**
Check JavaScript bundle size after build.
```bash
npm run build
# Check .next/analyze or build output for bundle sizes
npx next-bundle-analyzer  # if configured
```
Flag if any route's JS exceeds 200KB gzipped.

**P-02: N+1 query detection**
Scan all database queries in the codebase for loop patterns:
```python
# PROBLEM pattern:
for user in users:
    transactions = db.query(Transaction).filter_by(user_id=user.id).all()

# CORRECT pattern:
transactions = db.query(Transaction).filter(
    Transaction.user_id.in_([u.id for u in users])
).all()
```
Flag any query inside a loop without eager loading.

**P-03: Missing database indexes**
Check schema for:
- Foreign key columns without indexes
- Columns used in WHERE clauses without indexes
- Columns used in ORDER BY without indexes
- pgvector columns without HNSW or IVFFlat index

**P-04: Unoptimized images**
For Next.js: confirm all images use `next/image` not raw `<img>`
For Expo: confirm images are appropriately sized for device
Flag any image over 500KB being served uncompressed.

**P-05: Unnecessary re-renders (React)**
Check for:
- Components missing `React.memo` where appropriate
- useEffect dependencies arrays that cause excessive re-renders
- State updates that trigger full tree re-renders unnecessarily

**P-06: Sequential LLM calls that could be parallel**
Scan agent code for:
```typescript
// PROBLEM: Sequential
const result1 = await agent1.run(input)
const result2 = await agent2.run(input)

// CORRECT: Parallel where agents don't depend on each other
const [result1, result2] = await Promise.all([
    agent1.run(input),
    agent2.run(input)
])
```
Flag sequential LLM calls where outputs are independent.

**P-07: Token waste in prompts**
Check agent system prompts for:
- Redundant instructions repeated across multiple prompts
- Full conversation history passed when summary would suffice
- Large context passed to agents that don't need it
- No prompt caching on stable system prompts

**P-08: Missing API response caching**
Check for repeated identical API calls that could be cached:
- Same database query called multiple times per request
- External API calls (weather, exchange rates) without caching
- LLM responses for deterministic inputs without caching

**P-09: Synchronous operations blocking event loop**
For Node.js backends -- check for:
- Synchronous file system operations
- Blocking crypto operations without async versions
- CPU-intensive operations without worker threads

**P-10: Missing pagination**
Check all list endpoints and UI components for:
- Returning unlimited records from database
- Loading all records into memory before filtering
- No cursor-based or offset pagination on large datasets

**P-11: Frontend waterfall requests**
Check for:
- Data fetching that happens sequentially when parallel is possible
- Components that fetch data on mount creating request waterfalls
- Missing React Suspense boundaries causing full-page loading states

**P-12: Memory leaks**
Check for:
- Event listeners not cleaned up in useEffect
- Subscriptions (websockets, realtime) not unsubscribed on unmount
- Intervals and timeouts not cleared on unmount
- Large objects held in state that should be derived

### Lightweight check output:
```
LIGHTWEIGHT PERFORMANCE CHECK: [GATE VERSION]
Date: [DATE]

P-01 Bundle size:              PASS / FAIL ([X]KB)
P-02 N+1 queries:             PASS / FAIL
P-03 Missing indexes:          PASS / FAIL
P-04 Unoptimized images:       PASS / FAIL
P-05 Unnecessary re-renders:   PASS / FAIL
P-06 Sequential LLM calls:     PASS / FAIL
P-07 Token waste:              PASS / FAIL
P-08 Missing caching:          PASS / FAIL
P-09 Blocking operations:      PASS / FAIL
P-10 Missing pagination:       PASS / FAIL
P-11 Request waterfalls:       PASS / FAIL
P-12 Memory leaks:             PASS / FAIL

Result: [X]/12 PASSING

[If all pass:]
PERFORMANCE CHECK PASSED. Gate [VERSION] cleared.

[If any fail:]
PERFORMANCE ISSUES FOUND.
[CRITICAL/HIGH findings auto-fixed]
[MEDIUM/LOW findings listed for Brian's decision]
```

---

## FULL AUDIT (PRE-PRODUCTION)

Comprehensive four-layer audit before every production deployment.

---

### LAYER 1 -- FRONTEND PERFORMANCE

**F-01: Lighthouse audit**
```bash
npx lighthouse [STAGING_URL] --output json --quiet
```
Report scores for: Performance, Accessibility, Best Practices, SEO.
Flag any score below 90.

**F-02: Core Web Vitals**
Measure and report:
- FCP, LCP, TTI, CLS, FID/INP
- Flag anything below threshold table above

**F-03: Bundle analysis**
```bash
npm run build
npx @next/bundle-analyzer  # Next.js
# or
npx vite-bundle-analyzer   # Vite
```
Identify:
- Largest dependencies by size
- Duplicate packages
- Packages that could be lazy-loaded
- Code splitting opportunities

**F-04: Image optimization audit**
- All images served in WebP or AVIF format
- Images lazy-loaded below the fold
- Responsive images with appropriate srcset
- No layout shift from images without dimensions

**F-05: Font loading optimization**
- Fonts loaded with `font-display: swap`
- Font files subset to used characters
- No render-blocking font loads
- Font preloading for above-fold text

**F-06: Caching headers**
- Static assets cached with long TTL (1 year)
- HTML served with short TTL or no-cache
- API responses cached appropriately
- Service worker configured if PWA

**F-07: Third-party scripts**
- No render-blocking third-party scripts
- Analytics loaded asynchronously
- No unnecessary third-party dependencies

---

### LAYER 2 -- BACKEND PERFORMANCE

**B-01: API endpoint profiling**
Test every endpoint under the load it will experience:
```bash
# Install wrk or use Artillery
wrk -t12 -c400 -d30s http://[STAGING_URL]/api/[endpoint]

# Or Artillery for more complex scenarios
artillery run performance-test.yml
```
Report p50, p95, p99 response times.
Flag anything exceeding threshold table.

**B-02: Middleware overhead**
Profile middleware chain execution time.
Identify any middleware running on every request that could be:
- Cached
- Run only on specific routes
- Optimized or removed

**B-03: Payload size**
Check API response sizes:
- No unnecessary fields returned (over-fetching)
- Large arrays paginated
- Nested data not over-expanded
- Response compression (gzip/brotli) enabled

**B-04: Connection pooling**
Confirm database connection pooling is configured:
```python
# SQLAlchemy example
engine = create_engine(DATABASE_URL, pool_size=10, max_overflow=20)
```
Not creating new DB connections per request.

**B-05: Background job offloading**
Identify operations that shouldn't block the API response:
- Email sending
- File processing
- Third-party API calls that don't affect the response
- Any operation taking > 500ms

These should be offloaded to background jobs (Celery/BullMQ).

---

### LAYER 3 -- DATABASE PERFORMANCE

**D-01: Query analysis with EXPLAIN**
Run EXPLAIN ANALYZE on the 10 most frequent queries:
```sql
EXPLAIN ANALYZE SELECT * FROM transactions
WHERE user_id = $1
ORDER BY created_at DESC
LIMIT 50;
```
Flag: sequential scans on large tables, nested loops without indexes,
high actual vs. estimated row counts.

**D-02: Index audit**
Check every table:
```sql
-- Find missing indexes on foreign keys
SELECT tc.table_name, kcu.column_name
FROM information_schema.table_constraints tc
JOIN information_schema.key_column_usage kcu
  ON tc.constraint_name = kcu.constraint_name
WHERE tc.constraint_type = 'FOREIGN KEY'
AND NOT EXISTS (
    SELECT 1 FROM pg_indexes
    WHERE tablename = tc.table_name
    AND indexdef LIKE '%' || kcu.column_name || '%'
);
```
Flag all foreign keys without indexes.
Flag all WHERE clause columns without indexes on tables > 1000 rows.

**D-03: pgvector optimization (if used)**
Check vector search configuration:
```sql
-- Confirm HNSW index exists
SELECT indexname, indexdef FROM pg_indexes
WHERE indexdef LIKE '%hnsw%';

-- Check index parameters
-- m=16, ef_construction=64 is good default
-- Increase for better recall at cost of build time
```
Flag missing vector indexes.
Flag vector searches without proper index configuration.

**D-04: Slow query log**
Enable and check slow query log:
```sql
-- In Supabase: check pg_stat_statements
SELECT query, mean_exec_time, calls
FROM pg_stat_statements
ORDER BY mean_exec_time DESC
LIMIT 20;
```
Flag any query with mean execution time > 100ms.

**D-05: Database connection count**
Confirm connections are not being exhausted:
```sql
SELECT count(*) FROM pg_stat_activity;
SELECT setting FROM pg_settings WHERE name = 'max_connections';
```
Flag if connection count exceeds 80% of max.

**D-06: RLS performance impact**
Row Level Security adds overhead to every query.
Check that RLS policies use indexed columns:
```sql
-- RLS policy should filter on indexed columns
-- BAD: filter on unindexed column
-- GOOD: filter on user_id which has an index
```

---

### LAYER 4 -- AI PIPELINE PERFORMANCE

**A-01: LLM call chain profiling**
Instrument every agent call with timing:
```typescript
const start = Date.now()
const result = await agent.run(input)
const duration = Date.now() - start
console.log(`[AGENT_NAME] completed in ${duration}ms`)
```
Map the full call chain for every user-facing action.
Identify total latency from user request to response.

**A-02: Sequential vs. parallel opportunity analysis**
For every agent pipeline, Claude draws the dependency graph:
```
User request
    ↓
@ROUTER (100ms) -- sequential, must run first
    ↓
@ORACLE (800ms) ←→ @SENTINEL (600ms) -- these could run in parallel!
    ↓
@FORGE (1200ms) -- depends on both above
    ↓
Response

Current total: 2700ms
Optimized total: 100 + 1200 + 1200 = 2500ms (parallel ORACLE + SENTINEL)
```

**A-03: Token usage audit**
For each agent, analyze:
- Average tokens per call (input + output)
- Monthly cost projection at current usage
- Opportunities to reduce without capability loss:
  - Summarize conversation history instead of passing full history
  - Remove redundant instructions from system prompts
  - Use structured output to reduce output tokens
  - Cache responses for identical or near-identical inputs

**A-04: Prompt caching effectiveness**
Check that stable system prompts are being cached:
```typescript
// Prompt caching structure
messages: [
  {
    role: "user",
    content: [
      {
        type: "text",
        text: systemPrompt,
        cache_control: { type: "ephemeral" }  // Cache this
      },
      {
        type: "text",
        text: userInput  // Don't cache this -- it changes
      }
    ]
  }
]
```
Flag any agent not using prompt caching on stable system prompts.
Potential savings: up to 90% on repeated calls.

**A-05: Streaming implementation**
For user-facing LLM responses -- confirm streaming is implemented:
- First token appears within 500ms
- User sees progressive output, not a blank wait then full response
- Streaming handles errors gracefully (doesn't leave partial output)

**A-06: Model right-sizing**
Audit every agent's model selection:
```
For each agent:
  Task type: [routing / classification / generation / analysis]
  Current model: [model]
  Recommended model: [model]
  Reason: [why this task doesn't need a larger model]
  Monthly saving: $[X]
```

**A-07: Fallback and timeout handling**
Confirm every LLM call has:
- Timeout set (max 30s -- don't let users wait forever)
- Retry logic with exponential backoff (max 3 retries)
- Fallback behavior if all retries fail
- Error state in UI that doesn't leave user hanging

---

## FINDING SEVERITY LEVELS

| Level | Definition | Fix |
|-------|-----------|-----|
| CRITICAL | Will cause timeouts or failures under normal load | Auto-fix |
| HIGH | Significant user experience degradation at expected scale | Auto-fix |
| MEDIUM | Noticeable performance impact, acceptable short-term | Surface + wait |
| LOW | Best practice improvement, minimal user impact | Surface + wait |
| INFO | Optimization opportunity worth noting | Log only |

---

## FINDING OUTPUT FORMAT

```
PERFORMANCE FINDING: [SEVERITY]

ID: PERF-[NNN]
Layer: Frontend / Backend / Database / AI Pipeline
Check: [which check found it]

What: [clear description of the issue]
Where: [specific file, function, or query]
Impact: [what the user experiences -- in plain terms]
At scale: [what happens at 10x current load]

Fix: [specific remediation with code example]
Estimated improvement: [X]ms reduction / [X]% faster / $[X] saved

[If CRITICAL or HIGH:]
Auto-fixing now...
[Claude applies fix]
Validation: [confirms improvement]

[If MEDIUM or LOW:]
Awaiting your decision.
Type FIX [PERF-ID] to fix
Type DEFER [PERF-ID] to defer to a later gate
Type ACCEPT [PERF-ID] [reason] to accept as known limitation
```

---

## PERFORMANCE.md -- PERFORMANCE LOG

Lives in project root alongside blueprint files.

```markdown
# PERFORMANCE.md — Performance Audit Log
# App: [APP NAME]
# Last updated: [DATE]

---

## PERFORMANCE TARGETS

| Metric | Target | Current | Status |
|--------|--------|---------|--------|
| FCP | < 1.8s | [X]s | PASS/FAIL |
| LCP | < 2.5s | [X]s | PASS/FAIL |
| API p50 | < 200ms | [X]ms | PASS/FAIL |
| API p95 | < 500ms | [X]ms | PASS/FAIL |
| DB query avg | < 50ms | [X]ms | PASS/FAIL |
| Agent response | < 5s | [X]s | PASS/FAIL |

---

## AUDIT HISTORY

| # | Date | Type | Gate | Findings | Status |
|---|------|------|------|----------|--------|
| 1 | [DATE] | Lightweight | v0.1.0 | 0 | PASSED |
| 2 | [DATE] | Lightweight | v0.2.0 | 1 MEDIUM | PASSED |
| 3 | [DATE] | Full Audit | v1.0.0 | 1 HIGH, 2 MED | PASSED |

---

## FINDING LOG

### PERF-001 -- [SHORT TITLE]
**Date:** [DATE]
**Severity:** CRITICAL / HIGH / MEDIUM / LOW
**Layer:** [layer]
**Gate:** v[X.X.X]

**Issue:** [what was wrong]
**Location:** [file/query/endpoint]
**User impact:** [what user experienced]

**Fix applied:** [what was changed]
**Improvement:** [before vs. after metrics]
**Status:** FIXED / DEFERRED / ACCEPTED

---

## OPTIMIZATION LOG

Optimizations applied and their measured impact:

| Date | Optimization | Layer | Before | After | Saving |
|------|-------------|-------|--------|-------|--------|
| [D] | Added HNSW index on embeddings | DB | 850ms | 45ms | 805ms |
| [D] | Parallelized @ORACLE + @SENTINEL | AI | 2700ms | 1900ms | 800ms |
| [D] | Enabled prompt caching on @ROUTER | AI | $45/mo | $4/mo | $41/mo |

---

## CURRENT PERFORMANCE PROFILE

Last measured: [DATE] on [STAGING/PRODUCTION]

Frontend:
  Lighthouse: [score]
  LCP: [X]s | FCP: [X]s | CLS: [X]

Backend:
  p50: [X]ms | p95: [X]ms | p99: [X]ms

Database:
  Avg query: [X]ms | Slowest query: [X]ms ([query])

AI Pipeline:
  Avg agent response: [X]s
  Monthly AI cost at current usage: $[X]
  Monthly AI cost projected at 1K users: $[X]
```

---

## COMMAND WORDS

| You type | What happens |
|----------|--------------|
| `/performance` | Invoke full performance audit |
| `/performance quick` | Run lightweight check only |
| `/performance frontend` | Frontend layer only |
| `/performance backend` | Backend layer only |
| `/performance database` | Database layer only |
| `/performance ai` | AI pipeline layer only |
| `FIX [PERF-ID]` | Fix a specific MEDIUM/LOW finding |
| `DEFER [PERF-ID]` | Defer a finding to a later gate |
| `ACCEPT [PERF-ID] [reason]` | Accept as known limitation |
| `PROFILE [endpoint]` | Profile a specific endpoint |
| `BASELINE` | Record current metrics as baseline in PERFORMANCE.md |

---

## INTEGRATION WITH OTHER SKILLS

**Deploy skill:**
Full performance audit runs alongside security audit before PROMOTE.
Production deploy blocked until both pass.

**Cost Tracker:**
AI pipeline optimization findings feed directly into /costs.
Token savings and model right-sizing recommendations
update COSTS.md monthly projections automatically.

**Build Rules:**
Lightweight check at every gate close.
PERFORMANCE.md initialized when foundation files are populated.

**Critical Thinker:**
Performance implications are included in every architectural
decision critique. "This approach will cause N+1 queries at scale"
is a Critical Thinker concern, not just a Performance concern.

---

## RULES

- Lightweight check runs at every gate -- non-negotiable
- Full audit runs before every production deploy -- non-negotiable
- CRITICAL findings block the gate from closing until fixed
- Never ship code with a known CRITICAL performance issue
- Always measure before and after any optimization -- no blind fixes
- Performance findings are not negotiated down in severity to avoid fixing
- PERFORMANCE.md is version controlled -- commit it with the project
- If a performance fix causes a test failure -- debug skill takes
  priority, then performance fix is re-applied cleanly
- Report performance metrics to client in handoff PDF
  (pulled from PERFORMANCE.md current profile section)

---

# END OF PERFORMANCE SKILL v1.0
# Next version: v1.1 -- informed by first real performance audit
