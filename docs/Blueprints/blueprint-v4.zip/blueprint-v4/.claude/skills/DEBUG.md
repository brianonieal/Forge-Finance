---
name: debug
description: "Structured debugging skill for all app builds. Invoke with /debug or auto-triggered after 3 consecutive failures on the same problem (circuit breaker). Checks ERRORS.md first for known issues, diagnoses root cause, searches web and codebase, fixes autonomously, runs validation, and writes a post-mortem to ERRORS.md. Never gives up without a documented reason."
---

# DEBUG SKILL
# Owner: Brian Onieal | Freelance AI Systems Engineer
# Version: 1.0 | April 2026
# Invoke: /debug [description of problem] OR auto-triggered by circuit breaker

---

## WHAT THIS IS

The Debug skill is a structured, methodical bug resolution system.
It does not guess. It diagnoses, confirms, fixes, and validates.

It runs in two modes:
- **MANUAL:** Brian invokes /debug when something is broken
- **AUTO:** Triggered automatically after 3 consecutive failures
  on the same problem (circuit breaker from global rules)

Every debug session ends in one of two outcomes:
1. **RESOLVED** -- fix applied, validated, post-mortem written to ERRORS.md
2. **UNRESOLVED** -- diagnosis documented, Brian notified, options presented

No debug session ends without a written record.

---

## AUTO-TRIGGER (CIRCUIT BREAKER)

When Claude fails to resolve the same problem 3 consecutive times,
it stops all code work and states:

```
CIRCUIT BREAKER TRIGGERED

3 consecutive failures on: [problem description]

Attempts made:
1. [what was tried] -- [result]
2. [what was tried] -- [result]
3. [what was tried] -- [result]

Invoking /debug for structured diagnosis.
No further code changes until debug session completes.
```

Claude then immediately begins the debug protocol below.
Brian does not need to type anything -- it runs automatically.

---

## INVOCATION (MANUAL)

When `/debug` is invoked manually, Claude asks:

---

"Debug session started.

Describe the problem:
1. What were you trying to do when it broke?
2. What did you expect to happen?
3. What actually happened? (error message, wrong output, crash, etc.)
4. What is the exact error text if there is one? Paste it in full.
5. Did this work before? If yes, what changed?
6. What have you already tried?

Type READY when done, or paste the error and type READY."

---

## PHASE 1 -- ERRORS.md CHECK

Before any diagnosis, Claude reads ERRORS.md completely.

Claude searches for:
- Same error message or error type
- Same file or module
- Same feature or agent
- Same dependency or version

```
ERRORS.md CHECK

Searching for matches to: [problem description]

[If match found:]
KNOWN ISSUE FOUND -- ERR-[ID]: [title]
This exact problem occurred on [DATE] at gate [VERSION].
Root cause was: [root cause from ERRORS.md]
Fix applied then: [fix from ERRORS.md]
Prevention rule added: [rule]

Attempting same fix first before full diagnosis.
[Claude applies known fix]
[Claude runs validation]

[If fix works:]
RESOLVED using known fix from ERRORS.md.
Writing updated post-mortem entry.

[If fix doesn't work:]
Known fix did not resolve this instance.
Proceeding to full diagnosis -- this may be a related but different issue.

[If no match found:]
No matching issue in ERRORS.md.
Proceeding to full diagnosis.
```

---

## PHASE 2 -- INFORMATION GATHERING

Claude collects everything needed before attempting a fix.

### Step 1 -- Read the error in full
```bash
# Get full stack trace
# Read error logs
# Check browser console if frontend
# Check server logs if backend
```

Claude reads the COMPLETE error -- not just the first line.
Most debugging failures come from reading only the surface error
and missing the root cause buried in the stack trace.

### Step 2 -- Identify the blast radius
Claude identifies:
- Which file(s) are directly involved
- Which files import or depend on those files
- Which tests cover the affected code
- Which version gate introduced the affected code
- Whether prior gates' tests still pass

### Step 3 -- Reproduce the error
Claude attempts to reproduce the error consistently:
```bash
# Run the specific failing test
# Or reproduce the failing user action
# Confirm error appears reliably before attempting fix
```

**If error cannot be reproduced:**
```
ERROR IS NOT REPRODUCIBLE

The error cannot be consistently reproduced.
This may be:
- A race condition or timing issue
- An environment-specific problem
- A transient network or service failure

Proceeding with targeted investigation rather than fix attempt.
```

### Step 4 -- Form a hypothesis
Before touching any code, Claude states:

```
DIAGNOSIS HYPOTHESIS

Problem: [clear one-sentence description]
Likely root cause: [specific technical cause]
Evidence: [what in the code/logs supports this]
Confidence: HIGH / MEDIUM / LOW

Files to examine: [list]
Files likely to change: [list]

Proceeding to web search for confirmation."
```

---

## PHASE 3 -- WEB SEARCH

Claude searches externally to validate the hypothesis and find proven solutions.

### Search targets (in order):
1. **Official documentation** -- for the framework, library, or tool involved
2. **GitHub issues** -- search the repo of the relevant library for the exact error
3. **Stack Overflow** -- search the exact error message in quotes
4. **Reddit** (r/nextjs, r/expo, r/python, r/fastapi, etc.) -- community solutions
5. **Anthropic/Claude docs** -- if the issue involves AI/agent behavior

### Search queries Claude uses:
```
"[EXACT ERROR MESSAGE]" [framework name] [version]
[library name] [error type] github issues
[framework] [feature] not working [year]
```

### Web search report:
```
WEB SEARCH RESULTS

Query 1: "[error message]" Next.js 15
- Found: GitHub issue #[N] -- [description] -- [status: open/resolved]
- Relevant: [YES/NO] -- [why]

Query 2: [library] [error] stack overflow
- Found: [solution description]
- Upvotes: [N] -- Accepted answer: YES/NO
- Relevant: [YES/NO]

CONCLUSION FROM WEB SEARCH:
[What the web confirmed or contradicted about the hypothesis]
[Specific solution approach identified]
```

---

## PHASE 4 -- AUTONOMOUS FIX

Claude applies the fix without waiting for Brian's approval.

### Fix rules:
- Fix the root cause -- never patch the symptom
- Change the minimum number of files necessary
- Never refactor unrelated code during a debug session
- Back up any file before modifying it
- Apply one fix at a time -- never multiple simultaneous changes

### Fix execution:
```
APPLYING FIX

Root cause confirmed: [cause]
Solution: [what will be changed and why]

Files being modified:
- [file 1]: [what changes]
- [file 2]: [what changes]

Backup created: [file].backup

Applying changes...
```

### If the first fix attempt fails:
```
FIX ATTEMPT 1 FAILED

What was tried: [description]
Result: [what happened]

Revising approach based on: [new evidence]
Applying fix attempt 2...
```

Claude makes up to 3 fix attempts with different approaches.
After 3 failed attempts on a NEW problem (not the circuit breaker trigger):

```
3 FIX ATTEMPTS EXHAUSTED

This problem requires Brian's input before proceeding.
See UNRESOLVED section below.
```

---

## PHASE 5 -- VALIDATION

After every fix attempt, Claude runs full validation.

### Validation sequence:
```bash
# Step 1 -- Run the specific failing test that exposed the bug
[test command for specific test]

# Step 2 -- Run the full test suite for the affected gate
[test command for gate]

# Step 3 -- Regression check -- run all prior gate tests
pytest tests/ -v  # or equivalent

# Step 4 -- Build verification
npm run build  # or equivalent

# Step 5 -- If frontend -- visual check
# Claude describes what to verify in the browser
```

### Validation report:
```
VALIDATION RESULTS

Specific failing test: ✓ NOW PASSING
Gate test suite: ✓ [X]/[X] passing
Regression check: ✓ No prior gates broken
Build: ✓ SUCCESS

ISSUE RESOLVED.
Proceeding to post-mortem.
```

---

## PHASE 6 -- POST-MORTEM

After every resolved debug session, Claude writes a post-mortem to ERRORS.md.

### Format:
```markdown
## [ERROR-NNN] [Short descriptive title]
**Date:** [DATE]
**Version:** v[X.X.X]
**Category:** [regression | type-error | config | agent | harness | design | test | dependency | environment]
**Debug mode:** [manual | circuit-breaker-auto]
**Time to resolve:** [X minutes]

**What happened:**
[Clear description of the bug -- what broke and how it manifested]

**Root cause:**
[The actual underlying cause -- not the symptom]

**Web search helped:** [YES/NO] -- [what was found]

**Fix applied:**
[Exactly what was changed and why]

**Files modified:**
- [file]: [what changed]

**Validation:**
- Specific test: PASSING
- Gate suite: [X]/[X] passing
- Regressions: NONE

**Prevention rule:**
[The rule added to CLAUDE.md or CONTRACT.md to prevent recurrence]
[If no rule added, explain why]
```

### Error index update:
Claude adds the new entry to the ERRORS.md index table:
```
| ERR-[NNN] | [Short title] | v[X.X.X] | [category] | RESOLVED |
```

---

## UNRESOLVED PROTOCOL

When a bug cannot be fixed after exhausting all approaches:

```
DEBUG SESSION -- UNRESOLVED

Problem: [description]
Time spent: [X minutes]
Attempts made: [N]

What was tried:
1. [approach] -- [result]
2. [approach] -- [result]
3. [approach] -- [result]

Current understanding:
[Best hypothesis about root cause even if unconfirmed]

Possible causes still to investigate:
- [cause 1] -- [how to investigate]
- [cause 2] -- [how to investigate]

Options for Brian:
A. [specific next step] -- [what it involves, time estimate]
B. [workaround approach] -- [tradeoff]
C. [escalation path] -- e.g. open GitHub issue, check Discord, hire specialist

Recommendation: [A, B, or C] because [reason]

Writing UNRESOLVED entry to ERRORS.md.
No code changes made beyond what was already attempted.
Awaiting Brian's decision."
```

### ERRORS.md entry for unresolved:
```markdown
## [ERROR-NNN] [Short title] [UNRESOLVED]
**Date:** [DATE]
**Version:** v[X.X.X]
**Category:** [category]
**Status:** UNRESOLVED

**What happened:** [description]

**Attempts:**
1. [attempt] -- [result]
2. [attempt] -- [result]

**Current best hypothesis:** [hypothesis]

**Next steps:** [options presented to Brian]

**Brian's decision:** [FILL IN when resolved]
```

---

## COMMAND WORDS

| You type | What happens |
|----------|--------------|
| `/debug [description]` | Invoke manual debug session |
| `READY` | Problem described, begin ERRORS.md check |
| `SKIP ERRORS CHECK` | Skip ERRORS.md and go straight to diagnosis |
| `WEB ONLY` | Skip codebase diagnosis, go straight to web search |
| `REVERT` | Undo all changes from this debug session |
| `ACCEPT UNRESOLVED` | Log as unresolved, return to build |
| `TRY [specific approach]` | Claude attempts a specific fix Brian suggests |

---

## INTEGRATION WITH BUILD RULES

**Circuit breaker integration:**
Build Rules global rule C: After 3 consecutive failures, stop and invoke /debug.
/debug runs automatically -- Brian does not need to type anything.
Build Rules resumes only after /debug outputs RESOLVED or Brian types ACCEPT UNRESOLVED.

**Gate integration:**
A gate cannot close with an unresolved debug entry in ERRORS.md
for the current version. Either resolve it or explicitly mark it
as a known limitation in VERSION_ROADMAP.md.

---

## RULES

- Always check ERRORS.md first -- never ignore project history
- Always read the FULL error -- never diagnose from the first line only
- Always reproduce the error before attempting a fix
- Always back up files before modifying them
- Never fix multiple bugs in one session -- one problem, one fix
- Never refactor unrelated code during a debug session
- Always run the full validation sequence after every fix
- Always write a post-mortem -- resolved or not
- Never leave ERRORS.md without an entry after a debug session
- If web search finds a solution -- cite the source in the post-mortem
- Never apply a fix from web search without understanding it first

---

# END OF DEBUG SKILL v1.0
# Next version: v1.1 -- informed by first real debug session
