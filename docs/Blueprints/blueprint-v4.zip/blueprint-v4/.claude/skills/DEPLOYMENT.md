---
name: deployment
description: "Production deployment skill for all app builds. Invoke with /deploy to run pre-deployment checks, deploy frontend (Vercel) and backend (Render/Railway) atomically, run health checks, verify staging, promote to production, handle rollbacks, log all deployments to DEPLOYMENT.md, and generate a PDF client notification on successful production deploy. Hard blocks production deploy until staging is verified."
---

# DEPLOYMENT SKILL
# Owner: Brian Onieal | Freelance AI Systems Engineer
# Version: 1.0 | April 2026
# Invoke: /deploy

---

## WHAT THIS IS

The Deployment skill governs every deployment from local to production.
It deploys frontend and backend atomically in one session.
It never deploys straight to production -- staging is always verified first.
It generates a PDF client notification on every successful production deploy.
It maintains DEPLOYMENT.md as the permanent deployment log.

No production deployment happens without:
1. Full pre-deployment checks passing
2. Staging deployment succeeding
3. Health checks passing on staging URLs
4. Brian's explicit visual verification and PROMOTE command
5. Production health checks confirming live app is responding

---

## INVOCATION

When `/deploy` is invoked, Claude asks:

---

"Deployment session started.

1. What version are we deploying? (e.g. v0.4.0)
2. Is this a staging deploy or a full staging-to-production promotion?
3. What is the app name and client name? (for the deployment log and client PDF)
4. Confirm deployment targets:
   - Frontend: Vercel -- project name?
   - Backend: Render or Railway -- service name?
5. What is the health check endpoint? (e.g. /api/health -- must return 200)
6. What is the staging URL and production URL?

Type READY when done."

---

## PHASE 1 -- PRE-DEPLOYMENT CHECKS

Before any deployment command runs, Claude executes all checks below.
Any single failure is a hard block. Fix it before proceeding.

### Check 1 -- Test suite
```bash
# Backend
pytest tests/ -v --cov=app --cov-fail-under=90

# Frontend components
npx vitest run

# E2E (staging config)
npx playwright test
```
**Block condition:** Any failing test. Gate cannot deploy with red tests.
**Reference:** TESTS.md must show GATE STATUS: PASS for current version.

### Check 2 -- Build verification
```bash
# Frontend
npm run build

# Backend
python -m py_compile app/main.py  # or equivalent
```
**Block condition:** Build fails for any reason.

### Check 3 -- Lint and typecheck
```bash
npm run lint
npx tsc --noEmit
```
**Block condition:** Any type errors or lint errors that affect runtime behavior.

### Check 4 -- Environment variable audit
Claude reads CONTRACT.md and extracts every env var name defined.
Then confirms each exists in the deployment platform:

```
ENV VAR AUDIT: [VERSION]

Checking Vercel environment variables...
Checking Render/Railway environment variables...

Required vars from CONTRACT.md:
✓ NEXT_PUBLIC_API_URL -- set in Vercel
✓ ANTHROPIC_API_KEY -- set in Render
✗ SUPABASE_SERVICE_KEY -- MISSING from Render

[If any missing:]
DEPLOYMENT BLOCKED -- missing env vars must be added before proceeding.
Add the missing vars to the platform dashboard, then type RECHECK.
```

### Check 5 -- CHANGELOG.md verification
Confirms CHANGELOG.md has been updated with entries for the current version.
**Block condition:** No changelog entries for the version being deployed.

### Check 6 -- Git state
```bash
git status
git log --oneline -5
```
**Block condition:** Uncommitted changes exist. All changes must be committed
before deploying. Branch must be main or the designated release branch.

### Pre-deployment report:
```
PRE-DEPLOYMENT REPORT: [VERSION]

✓ Test suite: [X]/[X] passing
✓ Build: SUCCESS
✓ Lint + typecheck: CLEAN
✓ Env vars: [X]/[X] confirmed
✓ CHANGELOG.md: updated
✓ Git state: clean, on main

ALL CHECKS PASSED. Ready to deploy to staging.
Type GO to begin staging deployment."
```

---

## PHASE 2 -- STAGING DEPLOYMENT

Claude deploys frontend and backend to staging atomically.

### Frontend (Vercel)
```bash
# Deploy to staging/preview
vercel --target preview

# Or via Git (if auto-deploy is configured)
git push origin main
```

Claude monitors the Vercel deployment URL and waits for build completion.

### Backend (Render)
```bash
# Trigger deploy via Render API or Git push
# Claude monitors deploy logs until completion
```

### Backend (Railway)
```bash
railway up --detach
railway logs --tail
```

Claude waits for both deployments to complete before proceeding.
If either fails, both are flagged and rollback is initiated.

### Staging deployment report:
```
STAGING DEPLOYMENT: [VERSION]

Frontend (Vercel):
  Status: SUCCESS / FAILED
  Preview URL: [URL]
  Build time: [X]s

Backend (Render/Railway):
  Status: SUCCESS / FAILED
  Service URL: [URL]
  Deploy time: [X]s
```

---

## PHASE 3 -- STAGING HEALTH CHECKS

After both deployments succeed, Claude runs automated health checks.

### Health check protocol
```bash
# Frontend health check
curl -f [STAGING_FRONTEND_URL] --max-time 30

# Backend health check
curl -f [STAGING_BACKEND_URL]/api/health --max-time 30

# Expected response: HTTP 200
# Acceptable response time: under 3 seconds
```

### Extended checks
Claude also verifies:
- Auth endpoint responds (POST /api/auth/login returns 200 or 401, not 500)
- Database connection is live (health endpoint confirms DB ping)
- Any critical API routes respond correctly

### Health check report:
```
STAGING HEALTH CHECKS: [VERSION]

Frontend: ✓ 200 OK ([X]ms)
Backend /api/health: ✓ 200 OK ([X]ms)
Auth endpoint: ✓ responding
Database: ✓ connected

ALL HEALTH CHECKS PASSED.

Staging is live at: [STAGING_URL]

Brian -- please verify the following manually:
1. Open [STAGING_URL] in your browser
2. Complete the core user journey end to end
3. Check that the UI matches the approved mockups
4. Confirm no console errors

Type PROMOTE to deploy to production, or ROLLBACK if anything is wrong."
```

Claude waits. Does not proceed until Brian types PROMOTE or ROLLBACK.

---

## PHASE 4 -- PRODUCTION DEPLOYMENT

Only triggered by Brian typing PROMOTE.

### Production deployment
```bash
# Frontend -- promote preview to production
vercel --target production

# Backend -- same service, production environment
# (Render/Railway production service is separate from staging)
```

Claude monitors both deployments to completion.

### Production health checks
Identical to staging health checks, run against production URLs.

```bash
curl -f [PROD_FRONTEND_URL] --max-time 30
curl -f [PROD_BACKEND_URL]/api/health --max-time 30
```

### Production deployment report:
```
PRODUCTION DEPLOYMENT: [VERSION]

Frontend (Vercel):
  Status: SUCCESS
  Production URL: [URL]
  Deploy time: [X]s

Backend (Render/Railway):
  Status: SUCCESS
  API URL: [URL]
  Deploy time: [X]s

HEALTH CHECKS:
  Frontend: ✓ 200 OK ([X]ms)
  Backend: ✓ 200 OK ([X]ms)
  Database: ✓ connected

PRODUCTION IS LIVE.

Updating DEPLOYMENT.md...
Generating client notification PDF...
```

---

## PHASE 5 -- ROLLBACK PROTOCOL

Triggered by Brian typing ROLLBACK at any point, or by automatic
detection of health check failure after production deploy.

### Automatic rollback triggers
- Production health check fails after deploy
- Backend returns 500 on health endpoint
- Frontend build deploys but returns non-200

### Rollback commands
```bash
# Vercel -- revert to previous deployment
vercel rollback [previous-deployment-id]

# Render -- redeploy previous commit
# Railway -- rollback to previous deploy
railway rollback
```

### Rollback report:
```
ROLLBACK INITIATED: [VERSION]

Reason: [health check failure / Brian requested]

Rolling back frontend to: [previous version]
Rolling back backend to: [previous version]

Frontend rollback: SUCCESS / IN PROGRESS
Backend rollback: SUCCESS / IN PROGRESS

Health checks after rollback:
  Frontend: ✓/✗
  Backend: ✓/✗

[If successful:]
Previous version is restored and healthy.
Production is stable.
DEPLOYMENT.md updated with rollback record.
Do NOT generate client notification -- deployment did not succeed.

[If rollback also fails:]
CRITICAL: Both deploy and rollback failed.
Manual intervention required.
Contact Vercel/Render/Railway support immediately.
Do not attempt further automated actions.
```

---

## DEPLOYMENT.md -- THE DEPLOYMENT LOG

Lives in the project root. Tracks every deployment permanently.

### Structure:
```markdown
# DEPLOYMENT.md — Deployment Log
# App: [APP NAME]
# Client: [CLIENT NAME]
# Last updated: [DATE]

---

## DEPLOYMENT SUMMARY

| # | Version | Date | Deployed By | Staging | Production | Status |
|---|---------|------|-------------|---------|------------|--------|
| 1 | v0.1.0 | [DATE] | Brian Onieal | ✓ | ✓ | SUCCESS |
| 2 | v0.2.0 | [DATE] | Brian Onieal | ✓ | ✓ | SUCCESS |
| 3 | v0.3.0 | [DATE] | Brian Onieal | ✓ | ✗ | ROLLBACK |

---

## DEPLOYMENT DETAILS

### Deploy #[N] -- v[VERSION]
**Date:** [DATE]
**Version:** [VERSION]
**Deployer:** Brian Onieal

**Pre-deployment checks:**
- Tests: [X]/[X] passing
- Build: PASS
- Env vars: [X]/[X] confirmed
- Git: clean

**Staging:**
- Frontend URL: [URL]
- Backend URL: [URL]
- Health checks: PASS
- Brian verified: YES
- Verified at: [TIMESTAMP]

**Production:**
- Frontend URL: [URL]
- Backend URL: [URL]
- Health checks: PASS
- Deployed at: [TIMESTAMP]

**What shipped (from CHANGELOG.md):**
- [changelog entry]
- [changelog entry]

**Status:** SUCCESS / ROLLBACK
**Rollback reason (if applicable):** [reason]

---

## ENVIRONMENT CONFIGURATION

### Vercel
| Variable | Set | Last verified |
|----------|-----|---------------|
| [VAR_NAME] | ✓ | [DATE] |

### Render / Railway
| Variable | Set | Last verified |
|----------|-----|---------------|
| [VAR_NAME] | ✓ | [DATE] |
```

---

## CLIENT NOTIFICATION PDF

Generated automatically after every successful production deployment.
Uses Python + ReportLab (same generator as invoices).

### PDF content:
```
[YOUR NAME / BUSINESS NAME]
[YOUR EMAIL]

DEPLOYMENT NOTIFICATION
[APP NAME] -- Version [VERSION]
Deployed: [DATE] at [TIME]

Dear [CLIENT NAME],

Version [VERSION] of [APP NAME] has been successfully deployed
to production and is now live.

WHAT'S NEW IN THIS RELEASE
[Pulled from CHANGELOG.md for this version]
- [feature/fix]
- [feature/fix]

PRODUCTION URLS
Application: [PROD_FRONTEND_URL]
API: [PROD_BACKEND_URL]

DEPLOYMENT VERIFICATION
- Pre-deployment tests: [X]/[X] passing
- Staging verified: YES
- Health checks: PASSED
- Deployed at: [TIMESTAMP]

NEXT MILESTONE
[Next version from VERSION_ROADMAP.md and what it contains]
Estimated completion: [DATE/timeframe]

If you notice any issues, please contact me at [EMAIL].

Brian Onieal
Freelance AI Systems Engineer
```

PDF is saved to: `deployments/[APP_NAME]_v[VERSION]_deployment_[DATE].pdf`

---

## INTEGRATION WITH BUILD RULES

The deployment skill integrates with Build Rules at the production gate:

When VERSION_ROADMAP.md marks a version as the production release gate
(typically v1.0.0), Build Rules automatically prompts:
"This is the production release gate. Run /deploy after all tests pass."

Build Rules marks a gate as PRODUCTION READY only after:
- /testing POST-BUILD confirms GATE STATUS: PASS
- /deploy confirms PRODUCTION DEPLOYMENT: SUCCESS
- DEPLOYMENT.md is updated
- Client notification PDF is generated

---

## COMMAND WORDS

| You type | What happens |
|----------|--------------|
| `/deploy` | Invoke deployment session |
| `READY` | Questions answered, begin pre-deployment checks |
| `RECHECK` | Re-run env var audit after adding missing vars |
| `GO` | Pre-deployment checks passed, deploy to staging |
| `PROMOTE` | Staging verified, deploy to production |
| `ROLLBACK` | Revert to previous working deployment |
| `STATUS` | Show current deployment status and health |
| `LOG` | Show DEPLOYMENT.md summary |

---

## RULES

- Never deploy straight to production -- staging always comes first
- Never deploy with failing tests -- /testing must confirm PASS first
- Never deploy with missing env vars -- audit must be clean
- Never deploy with uncommitted changes -- git must be clean
- Never skip health checks -- both frontend and backend must return 200
- Always update DEPLOYMENT.md after every deploy attempt (success or failure)
- Always generate client PDF after successful production deploy
- After rollback -- root cause must be identified before attempting redeploy
- If 2 consecutive deploys fail -- stop, report, investigate before trying again

---

# END OF DEPLOYMENT SKILL v1.0
# Next version: v1.1 -- informed by first real deployment run
