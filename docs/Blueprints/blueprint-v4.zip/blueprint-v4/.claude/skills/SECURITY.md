---
name: security
description: "Comprehensive security auditing skill for all app builds. Covers application code, infrastructure, and AI-specific vulnerabilities. Runs lightweight checks at every gate and a full OWASP Top 10 plus stack-specific deep audit before every production deployment. Auto-triggers before /deploy PROMOTE step. Fixes CRITICAL and HIGH vulnerabilities autonomously. Maintains SECURITY.md as the permanent vulnerability and audit log. Generates a security summary for client handoff PDF."
---

# SECURITY SKILL
# Owner: Brian Onieal | Freelance AI Systems Engineer
# Version: 1.0 | April 2026
# Invoke: /security OR auto-triggered before production deploy

---

## WHAT THIS IS

The Security skill audits every app Brian builds for vulnerabilities
across three domains:

1. **Application code** -- auth, injection, data exposure, access control
2. **Infrastructure** -- env vars, RLS policies, API key handling, config
3. **AI-specific** -- prompt injection, agent tool misuse, LLM data leakage

It runs in two modes:
- **LIGHTWEIGHT:** Quick check at every gate boundary (~10 checks)
- **DEEP AUDIT:** Full OWASP Top 10 + stack-specific audit before production

CRITICAL and HIGH vulnerabilities are fixed autonomously.
MEDIUM and LOW vulnerabilities are surfaced with severity rating
and wait for Brian's go-ahead before fixing.

---

## AUTO-TRIGGER

Security auto-triggers at two points:

**1. Gate boundary (lightweight):**
When Build Rules closes any gate, before logging GATE COMPLETE,
Claude runs the lightweight security check automatically.

**2. Pre-production (deep audit):**
When `/deploy` reaches the PROMOTE step (staging verified, about
to push to production), Claude hard blocks and runs:

```
SECURITY AUDIT REQUIRED

Production deployment is blocked until the security audit passes.
Running full security audit for [APP NAME] v[VERSION]...
```

Production deploy cannot proceed until the deep audit passes
or all findings are explicitly accepted by Brian.

---

## LIGHTWEIGHT GATE CHECK

Runs at every gate close. Takes 5-10 minutes.
Covers the 10 most common and highest-impact issues.

### The 10 Lightweight Checks:

**L-01: Hardcoded secrets**
Scan all files for hardcoded API keys, passwords, tokens, and
connection strings. Check git history for accidentally committed secrets.
```bash
git log --all --full-history -- "*.env"
grep -r "sk-" src/ --include="*.ts" --include="*.py"
grep -r "password" src/ --include="*.ts" --include="*.py"
```

**L-02: Environment variable exposure**
Confirm all secrets are in .env files, not in source code.
Confirm .env is in .gitignore.
Confirm no NEXT_PUBLIC_ prefix on secret variables (exposes to browser).

**L-03: Unprotected API routes**
Check every API route has authentication middleware.
No route should be accessible without a valid session token
unless explicitly designed to be public.

**L-04: Supabase RLS policies**
Confirm Row Level Security is enabled on every table.
Confirm no table has RLS disabled in production.
Confirm policies prevent users from reading other users' data.

**L-05: Input validation**
Check that user input is validated and sanitized before:
- Database queries
- LLM prompts
- File operations
- External API calls

**L-06: Error message exposure**
Confirm error responses don't leak:
- Stack traces to the client
- Database error messages
- Internal file paths
- API keys or tokens in error logs

**L-07: CORS configuration**
Confirm CORS is not set to wildcard (*) in production.
Confirm allowed origins are explicitly listed.

**L-08: Auth token handling**
Confirm JWT tokens are not stored in localStorage (use httpOnly cookies).
Confirm token expiry is set appropriately.
Confirm refresh token rotation is implemented.

**L-09: Dependency vulnerabilities**
```bash
npm audit --audit-level=high
pip-audit  # Python equivalent
```
Flag any HIGH or CRITICAL dependency vulnerabilities.

**L-10: Agent tool permissions**
Confirm no agent has more tool permissions than defined in COUNCIL_AGENTS.md.
Confirm destructive tools (mutate_db, run_bash) require approval.
Confirm coordinator is the only agent that can spawn subagents.

### Lightweight check output:
```
LIGHTWEIGHT SECURITY CHECK: [GATE VERSION]
Date: [DATE]

L-01 Hardcoded secrets:     PASS / FAIL
L-02 Env var exposure:      PASS / FAIL
L-03 Unprotected routes:    PASS / FAIL
L-04 Supabase RLS:          PASS / FAIL
L-05 Input validation:      PASS / FAIL
L-06 Error exposure:        PASS / FAIL
L-07 CORS config:           PASS / FAIL
L-08 Auth token handling:   PASS / FAIL
L-09 Dependencies:          PASS / FAIL
L-10 Agent permissions:     PASS / FAIL

Result: [X]/10 PASSING

[If all pass:]
SECURITY CHECK PASSED. Gate [VERSION] cleared.

[If any fail:]
SECURITY ISSUES FOUND -- Gate cannot close until resolved.
See findings below.
```

---

## DEEP AUDIT (PRE-PRODUCTION)

Full audit before every production deployment.
Covers OWASP Top 10 extended for Brian's stack.

### OWASP TOP 10 -- EXTENDED FOR YOUR STACK

**A01: Broken Access Control**
- Every protected route requires authentication
- Role-based access control enforced at API layer, not just UI
- Supabase RLS prevents cross-user data access
- Agent tool permissions match COUNCIL_AGENTS.md exactly
- No IDOR (Insecure Direct Object Reference) -- users can't access
  other users' resources by changing an ID in the URL

**A02: Cryptographic Failures**
- Passwords hashed with bcrypt/argon2 (never MD5 or SHA1)
- Data in transit encrypted (HTTPS enforced, no HTTP fallback)
- Sensitive data encrypted at rest if stored (PII, financial data)
- No sensitive data in URL parameters or logs
- JWT signed with strong secret (min 256-bit)

**A03: Injection**
- No raw SQL queries -- ORM used exclusively (Prisma/SQLAlchemy)
- User input sanitized before reaching database
- NoSQL injection prevented if using document DB
- Command injection prevented (no user input in shell commands)
- LDAP injection prevented if applicable

**A04: Insecure Design**
- Threat model reviewed for this specific app
- Sensitive operations require re-authentication
- Rate limiting on auth endpoints (prevent brute force)
- Account lockout after N failed attempts
- Password reset flow doesn't leak user existence

**A05: Security Misconfiguration**
- No default credentials anywhere
- Debug mode disabled in production
- Unnecessary features/endpoints disabled
- Security headers set (CSP, HSTS, X-Frame-Options, etc.)
- Stack trace not exposed in production error responses
- Cloud storage (S3/Supabase storage) not publicly readable

**A06: Vulnerable and Outdated Components**
- npm audit clean (no HIGH or CRITICAL)
- pip-audit clean (Python deps)
- No abandoned packages with known CVEs
- Dependencies pinned to specific versions

**A07: Identification and Authentication Failures**
- Multi-factor authentication available for sensitive accounts
- Session invalidated on logout
- Concurrent session handling defined
- Auth tokens expire appropriately
- Refresh token rotation implemented
- No weak default passwords

**A08: Software and Data Integrity Failures**
- npm package integrity verified (package-lock.json committed)
- No untrusted CDN scripts loaded without integrity hash
- CI/CD pipeline protected from unauthorized changes
- Deployment artifacts verified before promotion

**A09: Security Logging and Monitoring Failures**
- Auth events logged (login, logout, failed attempts)
- Privilege escalation attempts logged
- Agent actions logged with user context
- Logs don't contain sensitive data (passwords, tokens)
- Log retention policy defined

**A10: Server-Side Request Forgery (SSRF)**
- User-provided URLs validated before server-side fetch
- Internal network not accessible via user-controlled URLs
- Allowlist of permitted external domains for server fetches

---

### AI-SPECIFIC SECURITY CHECKS

**AI-01: Prompt Injection**
The most critical AI-specific vulnerability for Brian's apps.
An attacker crafts user input that hijacks agent behavior.

Check for:
- User input passed directly to agent system prompts without sanitization
- No separation between user data and agent instructions
- Agent can be instructed to ignore its system prompt via user message
- Tool calls can be triggered by malicious user input

Mitigations Claude checks for:
- User input treated as data, never as instructions
- System prompt and user content clearly separated in message structure
- Agent outputs validated before being used as tool inputs
- Sensitive tool calls (mutate_db, external APIs) require structured
  input validation, not free-form text from user

**AI-02: LLM Data Leakage**
Agent inadvertently reveals sensitive data in responses.

Check for:
- System prompt contains secrets that could leak in response
- Agent has access to more data than needed for its task
- RAG retrieval returns documents the current user shouldn't see
- Agent response includes data from other users' context

Mitigations:
- System prompts contain no secrets
- RAG retrieval filtered by user permissions
- Agent responses reviewed for PII before returning to client
- Least-privilege data access per agent

**AI-03: Agent Tool Misuse**
Attacker manipulates agent into calling destructive tools.

Check for:
- Destructive tools (mutate_db, delete, external API writes) accessible
  without explicit approval gates
- Agent can be convinced to call tools outside its defined permissions
- No audit log of agent tool calls

Mitigations:
- Tool permissions enforced at harness level, not just prompt level
- Destructive operations require structured confirmation
- All tool calls logged with user context and timestamp

**AI-04: Insecure Model Configuration**
Model configuration exposes vulnerabilities.

Check for:
- Temperature set too high for security-sensitive decisions
- No max_tokens limit (enables resource exhaustion)
- System prompt can be extracted via prompt engineering
- Model used for security decisions without validation layer

**AI-05: Training Data Poisoning (if fine-tuning)**
Only relevant if Brian is fine-tuning models.
Check that training data is validated and from trusted sources.

---

### INFRASTRUCTURE SECURITY CHECKS

**I-01: Vercel Configuration**
- Environment variables set in Vercel dashboard (not in code)
- No sensitive vars with NEXT_PUBLIC_ prefix
- Preview deployments don't have production secrets
- Custom domain has valid SSL certificate
- Security headers configured in vercel.json

**I-02: Render/Railway Configuration**
- Environment variables set in platform dashboard
- No secrets in Dockerfile or docker-compose
- Service not publicly accessible except intended endpoints
- Auto-deploy only from main branch

**I-03: Supabase Configuration**
- RLS enabled on ALL tables
- No service role key used client-side (only anon key)
- Storage buckets not publicly readable unless intended
- Auth email templates use secure links
- JWT expiry set appropriately
- Database password is strong and rotated if compromised

**I-04: API Key Management**
- All API keys stored in environment variables
- No API keys in source code, comments, or git history
- API keys have minimum required permissions (principle of least privilege)
- Separate API keys for development and production
- Rotation plan defined for compromised keys

**I-05: Git Security**
- .env files in .gitignore
- No secrets in git history (check with git-secrets or trufflehog)
- Branch protection on main (no direct pushes)
- No sensitive data in commit messages

---

## FINDING SEVERITY LEVELS

| Level | Definition | Fix |
|-------|-----------|-----|
| CRITICAL | Actively exploitable, immediate data or system risk | Auto-fix |
| HIGH | Serious vulnerability, likely to be exploited | Auto-fix |
| MEDIUM | Vulnerability exists, exploitation requires specific conditions | Surface + wait |
| LOW | Best practice violation, low exploitation risk | Surface + wait |
| INFO | Informational, no direct security risk | Log only |

---

## FINDING OUTPUT FORMAT

For each vulnerability found:

```
SECURITY FINDING: [SEVERITY]

ID: SEC-[NNN]
Category: [OWASP category / AI / Infrastructure]
Check: [which check found it]

What: [clear description of the vulnerability]
Where: [specific file, line, or config location]
Risk: [what an attacker could do with this]

Fix: [specific remediation]
Effort: LOW / MEDIUM / HIGH

[If CRITICAL or HIGH:]
Auto-fixing now...
[Claude applies fix]
Validation: [confirms fix works]

[If MEDIUM or LOW:]
Awaiting your decision.
Type FIX [SEC-ID] to fix this issue
Type ACCEPT-RISK [SEC-ID] [reason] to accept and document this risk
```

---

## SECURITY.md -- VULNERABILITY AND AUDIT LOG

Lives in project root. Never committed to a public repo without redaction.

```markdown
# SECURITY.md — Security Audit Log
# App: [APP NAME]
# Last updated: [DATE]
# Classification: CONFIDENTIAL -- do not commit to public repos

---

## AUDIT SUMMARY

| Audit # | Date | Type | Gate | Findings | Status |
|---------|------|------|------|----------|--------|
| 1 | [DATE] | Lightweight | v0.1.0 | 0 | PASSED |
| 2 | [DATE] | Lightweight | v0.2.0 | 1 LOW | PASSED |
| 3 | [DATE] | Deep Audit | v1.0.0 | 2 MED, 0 HIGH | PASSED |

---

## VULNERABILITY LOG

### SEC-001 -- [SHORT TITLE]
**Date found:** [DATE]
**Audit:** #[N]
**Severity:** CRITICAL / HIGH / MEDIUM / LOW
**Category:** Application / Infrastructure / AI
**Check:** [which check]

**Description:** [what the vulnerability is]
**Location:** [file/config]
**Risk:** [what attacker could do]

**Status:** FIXED / ACCEPTED RISK / PENDING
**Fixed in:** [gate version]
**Fix applied:** [description of fix]
**Accepted risk reason (if applicable):** [reason]
**Verified by:** Claude / Brian

---

## ACCEPTED RISKS

Vulnerabilities Brian chose not to fix with documented justification:

| ID | Description | Severity | Reason | Date |
|----|-------------|----------|--------|------|
| SEC-[N] | [description] | [level] | [why accepted] | [date] |

---

## SECURITY POSTURE SUMMARY
(Auto-generated for client handoff)

Last full audit: [DATE]
Audit type: OWASP Top 10 + AI Security + Infrastructure
Findings: [N] CRITICAL, [N] HIGH, [N] MEDIUM, [N] LOW
All CRITICAL/HIGH resolved: YES / NO
Accepted risks: [N] (see above)
Overall posture: STRONG / ADEQUATE / NEEDS ATTENTION
```

---

## CLIENT HANDOFF SECURITY SUMMARY

Auto-generated non-technical security section for the client handoff PDF:

```
SECURITY

[APP NAME] underwent security testing throughout development
and a comprehensive audit before production deployment.

WHAT WAS TESTED
- Application security (authentication, data access, input handling)
- Infrastructure security (hosting configuration, secret management)
- AI security (agent behavior, data handling, prompt safety)

AUDIT RESULTS
Full security audit completed: [DATE]
Critical vulnerabilities found and fixed: [N]
All known vulnerabilities resolved before launch: YES

SECURITY MEASURES IN PLACE
- All data transmitted over encrypted HTTPS connections
- User authentication via [AUTH_PROVIDER]
- Database access restricted per user (Row Level Security)
- All API keys stored securely, never in source code
- Input validation on all user-submitted data
- Regular dependency security scanning

YOUR RESPONSIBILITIES
To maintain the security of [APP NAME]:
- Never share API keys or admin credentials via email or chat
- Rotate API keys immediately if they are ever compromised
- Keep all platform accounts (Vercel, Supabase) secured with
  strong passwords and two-factor authentication
- Report any suspicious behavior immediately to [EMAIL]
```

---

## COMMAND WORDS

| You type | What happens |
|----------|--------------|
| `/security` | Invoke manual security audit |
| `/security quick` | Run lightweight check only |
| `/security full` | Run full deep audit |
| `FIX [SEC-ID]` | Fix a specific MEDIUM/LOW finding |
| `ACCEPT-RISK [SEC-ID] [reason]` | Accept and document a risk |
| `FIX ALL MEDIUM` | Fix all medium findings autonomously |
| `AUDIT REPORT` | Generate full audit report from SECURITY.md |
| `STATUS` | Show current security posture summary |

---

## INTEGRATION WITH OTHER SKILLS

**Build Rules:**
Lightweight check auto-runs at every gate close.
Deep audit auto-runs before PROMOTE in /deploy.

**Deploy skill:**
Production deploy hard blocked until deep audit passes.
Security posture added to DEPLOYMENT.md after each deploy.

**Handoff skill:**
Security summary auto-included in client handoff PDF.
SECURITY.md referenced in technical handoff PDF.

**Debug skill:**
Security vulnerabilities that manifest as bugs route through
both /debug and /security to ensure root cause is addressed
from both a functionality and security perspective.

---

## RULES

- Lightweight check runs at every gate -- non-negotiable
- Deep audit runs before every production deploy -- non-negotiable
- CRITICAL and HIGH findings are fixed before any other work continues
- SECURITY.md is never committed to a public repository unredacted
- Accepted risks must have a documented reason -- never accept silently
- Security findings are not negotiated down in severity to avoid fixing them
- A clean audit is not a guarantee of security -- document this to clients
- If a fix introduces a regression -- debug skill takes priority,
  then security fix is re-applied cleanly
- All agent tool calls must be logged -- no silent destructive operations

---

# END OF SECURITY SKILL v1.0
# Next version: v1.1 -- informed by first real security audit
