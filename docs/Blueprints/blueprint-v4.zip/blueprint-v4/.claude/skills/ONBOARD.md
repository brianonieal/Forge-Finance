---
name: onboard
description: "Client onboarding skill for freelance AI engineering work. Invoke with /onboard to go from new client inquiry to signed agreement. Handles vague and detailed briefs. Generates a polished PDF proposal, a project contract, a gate-by-gate cost estimate, and a short email draft. Creates a CLIENTS.md record for every prospect. Integrates with Build Rules and freelance-billing."
---

# ONBOARD SKILL
# Owner: Brian Onieal | Freelance AI Systems Engineer
# Version: 1.0 | April 2026
# Invoke: /onboard

---

## WHAT THIS IS

The Onboard skill takes a new client inquiry -- from vague idea to
detailed brief -- and produces everything needed to close the deal
and start building professionally.

It generates four deliverables:
1. **Project Proposal PDF** -- polished, client-facing, includes why Brian,
   methodology, scope, estimate, and payment schedule
2. **Project Contract PDF** -- legally clear agreement covering scope,
   payment, IP, revisions, kill fee, and timeline
3. **Proposal Email Draft** -- short professional email to send with the PDFs
4. **CLIENTS.md entry** -- permanent prospect record in your freelance folder

---

## INVOCATION

When `/onboard` is invoked, Claude responds:

---

"Client onboarding started.

Tell me everything you know about this client and project.
Brain dump it all -- who they are, what they want, what they've told you,
what platform, what budget if they mentioned one, any details at all.

If you have a brief, email, or notes from a call -- paste them in.
Don't organize it. Just get it all out.

Type READY when done."

---

## PHASE 1 -- INTAKE INTERROGATION

After READY, Claude reads the brain dump and identifies gaps.
Claude never asks for something already clearly stated.

Claude interrogates across six areas:

### 1A -- CLIENT & BUSINESS CONTEXT
- What is the client's company name and industry?
- Who is the decision maker? What is their role?
- Is this a startup, small business, or enterprise?
- Do they have an existing tech team or are they non-technical?
- Have they built software before? Do they have previous vendors?
- What is driving this project -- a specific pain point, opportunity, or deadline?
- Is there a hard launch deadline? Why that date?

### 1B -- PROJECT SCOPE
- What does the app need to do at its core -- one sentence?
- Who are the end users and how many are expected at launch?
- What platforms -- web, mobile, or both?
- What integrations are required -- third-party services, existing systems?
- Does it need AI features? What specifically?
- What does success look like at launch? At 6 months?
- What is explicitly out of scope?

### 1C -- BUDGET & COMMERCIAL
- Has the client mentioned a budget? What is it?
- If no budget mentioned -- what is the market rate for this type of project
  and what is Brian's estimate based on the scope?
- Is this a fixed-price project or hourly?
- Who pays operating costs after launch -- client or Brian?
- Is there potential for ongoing work after v1.0?

### 1D -- TIMELINE
- When does the client want the project done?
- Is the timeline realistic given the scope?
- If not realistic -- what scope reduction makes it achievable?
- Are there external dependencies (third-party APIs, approvals, content)
  that could delay the build?

### 1E -- DECISION AND COMPETITION
- Has the client talked to other developers or agencies?
- What is their decision timeline?
- What matters most to them -- price, speed, quality, or methodology?
- Is there anything specific Brian needs to address to win this?

### 1F -- BRIAN'S ASSESSMENT
Before generating the proposal, Claude gives Brian an honest assessment:

```
BRIAN'S HONEST ASSESSMENT

Project viability: STRONG / MODERATE / WEAK
Reasoning: [why]

Scope vs. budget alignment: ALIGNED / GAP EXISTS
[If gap:] Budget is [X]% below market rate for this scope.
Options: [reduce scope / increase price / decline]

Timeline realism: REALISTIC / TIGHT / UNREALISTIC
[If unrealistic:] This scope needs [X] weeks minimum.
Recommend: [what to propose instead]

Red flags: [any concerns about the client or project]
Green flags: [what looks promising]

Recommendation: PURSUE / PURSUE WITH CONDITIONS / DECLINE
Reason: [honest assessment]

Type PROCEED to generate proposal documents.
Type ADJUST [item] to change something before proceeding.
Type DECLINE to log as declined and close the session."
```

---

## PHASE 2 -- GATE STRUCTURE ESTIMATE

Before generating documents, Claude proposes a gate structure
for this project type -- the same logic Build Rules uses.

```
PROPOSED GATE STRUCTURE: [APP NAME]

Based on the scope described, here is how I would structure this build:

| Gate | Name | Deliverables | Hours | Cost |
|------|------|-------------|-------|------|
| v0.0.0 | Foundation | Blueprint files, repo, env setup | 3 hrs | $450 |
| v0.1.0 | Scaffold | Project structure, dependencies, CI | 4 hrs | $600 |
| v0.2.0 | [NAME] | [deliverables] | [N] hrs | $[X] |
| v0.3.0 | [NAME] | [deliverables] | [N] hrs | $[X] |
| v0.4.0 | [NAME] | [deliverables] | [N] hrs | $[X] |
| v1.0.0 | Launch | QA, deployment, handoff | [N] hrs | $[X] |

ESTIMATE SUMMARY
Total hours: [N] hrs
Total cost: $[X] (at $150/hr)
Timeline: [N] weeks (at [N] hrs/week)

Buffer recommendation: Add 15% contingency for scope clarifications
Buffered total: $[X]

Payment structure:
- 50% upfront ($[X]) -- project begins
- Per gate ($[X] each) -- paid before next gate opens
- Final payment ($[X]) -- on production deployment

Type APPROVE ESTIMATE to use this for the proposal.
Type ADJUST [gate] [change] to modify before approving."
```

---

## DOCUMENT 1 -- PROJECT PROPOSAL PDF

### Structure:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Brian Onieal | Freelance AI Systems Engineer
[EMAIL] | Brooklyn, NY | github.com/brianonieal
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

PROJECT PROPOSAL
[APP NAME or PROJECT NAME]
Prepared for: [CLIENT NAME], [CLIENT COMPANY]
Date: [DATE]
Valid for: 30 days

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SECTION 1 -- THE OPPORTUNITY

[2-3 paragraphs: Brian's understanding of the client's problem
and the opportunity the app addresses. Written in language that
resonates with the client -- not technical. Shows Brian listened.]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SECTION 2 -- THE SOLUTION

[What Brian proposes to build. Plain English.
What it does, who uses it, what problem it solves.]

WHAT'S INCLUDED
[Bullet list of major features from the approved gate structure]
✓ [feature]
✓ [feature]
✓ [feature]

WHAT'S NOT INCLUDED
[Explicit out-of-scope items to prevent scope creep]
- [item] -- available in a future phase

PLATFORM
[Web / Mobile / Both] built on [brief stack description
in non-technical terms -- "a modern, scalable web application"
not "Next.js 15 App Router with Supabase pgvector"]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SECTION 3 -- HOW I WORK

I build using a methodology called Build Rules -- a structured,
gated development process that eliminates the most common
reasons software projects fail.

HOW IT WORKS
Every project is divided into milestone gates. Each gate has
explicit deliverables and passing criteria. The next gate
doesn't open until the current one is complete and tested.
You see exactly what was built at every milestone before
more work begins.

WHAT THIS MEANS FOR YOU
- No surprises -- you know what you're getting at every stage
- No scope creep -- changes are evaluated and priced transparently
- No untested code -- automated tests run before every milestone
- No mystery deployments -- staging is verified before going live

TRANSPARENCY
Every hour is logged. Every decision is documented.
You receive a detailed handoff package at project close --
what was built, how to use it, and everything you own.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SECTION 4 -- WHY BRIAN

[Pulled from global rules and current projects.
Written in third person or first person -- Claude decides
based on what reads more naturally for this client.]

I'm a freelance AI systems engineer based in Brooklyn, NY,
pursuing a Master's in AI Engineering at Johns Hopkins University.

Recent work:
- Forge Finance -- AI-native personal finance platform with
  multi-agent LangGraph architecture, 151 tests, Plaid integration
- Feast-AI -- autonomous community management platform for a global
  dinner gathering organization with 100,000+ members
- EOM-AI -- voice-to-Substack publishing platform with Deepgram,
  Tiptap, and Hugging Face image generation

My methodology (Build Rules) was developed from real project
failures and validated against Anthropic's own internal
agent architecture patterns. Every project I build has:
- Structured version gates with explicit passing criteria
- Comprehensive automated testing before any gate closes
- Security auditing before every production deployment
- Complete technical documentation at handoff

Rate: $150/hour
Availability: [FILL IN based on current project load]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SECTION 5 -- PROJECT ESTIMATE

[Gate-by-gate breakdown from approved estimate]

| Milestone | Deliverables | Hours | Investment |
|-----------|-------------|-------|------------|
| [Gate] | [deliverables] | [N] hrs | $[X] |
| [Gate] | [deliverables] | [N] hrs | $[X] |
| [Gate] | [deliverables] | [N] hrs | $[X] |

TOTAL INVESTMENT: $[X]
TIMELINE: [N] weeks

Note: This estimate includes a 15% contingency buffer.
Scope changes requested after project start are evaluated
and priced transparently before implementation.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SECTION 6 -- PAYMENT SCHEDULE

50% upfront: $[X] -- project begins immediately upon receipt
[GATE NAME]: $[X] -- due before next gate opens
[GATE NAME]: $[X] -- due before next gate opens
Final payment: $[X] -- due on production deployment

Payment methods: [from generate_invoice.py payment methods]
Late fee: 1.5% per month on balances unpaid after due date

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SECTION 7 -- NEXT STEPS

To move forward:
1. Review and sign the attached Project Contract
2. Submit the 50% deposit ($[X])
3. I'll schedule a kickoff call within 48 hours of receipt

Questions? [EMAIL]

This proposal is valid for 30 days from [DATE].

Brian Onieal
Freelance AI Systems Engineer
[EMAIL] | Brooklyn, NY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**Saved to:** `onboarding/[CLIENT_COMPANY]_PROPOSAL_[DATE].pdf`

---

## DOCUMENT 2 -- PROJECT CONTRACT PDF

### Structure:

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PROJECT CONTRACT
[APP NAME]
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

This agreement is between:
Developer: Brian Onieal, Freelance AI Systems Engineer
           Brooklyn, NY | [EMAIL]

Client:    [CLIENT NAME]
           [CLIENT COMPANY]
           [CLIENT EMAIL]

Effective date: [DATE]
Project: [APP NAME]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. SCOPE OF WORK

Developer will design, build, and deploy [APP NAME] as described
in the Project Proposal dated [DATE], attached as Exhibit A.

The scope includes:
[List of major deliverables from proposal]

The scope explicitly excludes:
[List of out-of-scope items from proposal]

Changes to scope requested after project start will be evaluated,
priced, and must be approved in writing by both parties before
implementation begins.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
2. PAYMENT TERMS

Total project fee: $[X] USD
Payment schedule:
  Deposit (50%): $[X] -- due before project begins
  [Gate payment]: $[X] -- due before [gate] begins
  [Gate payment]: $[X] -- due before [gate] begins
  Final payment: $[X] -- due on production deployment

Payment methods: [methods]
Late fee: 1.5% per month on balances unpaid after due date
Work may be paused if payment is not received within 7 days of due date.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
3. TIMELINE

Estimated project duration: [N] weeks from deposit receipt
Timeline assumes timely client feedback (within 48 hours of requests)
and no scope changes.

Developer will communicate delays promptly if they occur.
Client-caused delays (late feedback, scope changes, missing assets)
may extend the timeline without penalty to Developer.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
4. REVISIONS

This contract includes [N] rounds of revisions per milestone.
A revision round is defined as a consolidated list of changes
submitted in a single communication.

Additional revision rounds: $150/hour, billed in 30-minute increments.
Revision rounds do not include new features or scope changes.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
5. INTELLECTUAL PROPERTY

Upon receipt of final payment in full, all intellectual property
including source code, design assets, and documentation transfers
to Client in full.

Developer retains no ongoing rights to the codebase after
full payment is received.

Developer may reference the project in their portfolio unless
Client requests confidentiality in writing.

Prior to full payment, Developer retains all intellectual property
rights and Client may not use, deploy, or distribute the work.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
6. KILL FEE

If Client terminates this project after work has begun:

  After deposit, before v0.2.0: Deposit is non-refundable
  After v0.2.0: 50% of remaining contract value is due within 14 days
  After v0.5.0: 75% of remaining contract value is due within 14 days

Developer will deliver all completed work to date upon termination.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
7. CONFIDENTIALITY

Developer agrees to keep Client's business information,
data, and project details confidential during and after
the project, except as required by law.

Client agrees to keep Developer's proprietary methodology,
processes, and tooling confidential.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
8. WARRANTIES AND LIMITATIONS

Developer warrants that:
- The work will be original and not infringe third-party rights
- The delivered application will function as described in the proposal
- All critical and high security vulnerabilities will be resolved
  before production deployment

Developer does not warrant:
- Specific business outcomes or revenue results
- Third-party service availability or performance
- That the application will be free of all bugs after handoff

LIABILITY: Developer's total liability is limited to the total
fees paid under this contract.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
9. INDEPENDENT CONTRACTOR

Developer is an independent contractor, not an employee of Client.
Developer is responsible for their own taxes and insurance.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
10. GOVERNING LAW

This agreement is governed by the laws of New York State.
Disputes will be resolved in New York County.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
SIGNATURES

Developer:
Brian Onieal _________________ Date: _______

Client:
[CLIENT NAME] ________________ Date: _______
[CLIENT COMPANY]

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
EXHIBIT A: Project Proposal dated [DATE] is attached
and incorporated into this agreement by reference.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```

**Saved to:** `onboarding/[CLIENT_COMPANY]_CONTRACT_[DATE].pdf`

**Note:** This contract is a starting point. Brian should have
a lawyer review it before using with high-value clients.

---

## DOCUMENT 3 -- PROPOSAL EMAIL DRAFT

```
Subject: Project Proposal -- [APP NAME] for [CLIENT COMPANY]

Hi [CLIENT NAME],

It was great [speaking with you / connecting with you] about [APP NAME].
I've put together a proposal and contract based on our conversation.

Quick summary:
- Scope: [one sentence description]
- Investment: $[X]
- Timeline: [N] weeks
- Start date: [when Brian can start]

I've attached two documents:
1. Project Proposal -- full scope, methodology, and estimate
2. Project Contract -- terms, payment schedule, and IP transfer

To move forward, sign the contract and submit the 50% deposit ($[X]).
I can kick off within 48 hours of receipt.

Happy to answer any questions -- just reply to this email
or grab time here: [CALENDLY or FILL IN]

Brian Onieal
Freelance AI Systems Engineer
[EMAIL]
```

**Saved to:** `onboarding/[CLIENT_COMPANY]_PROPOSAL_EMAIL_[DATE].txt`

---

## CLIENTS.md -- PROSPECT AND CLIENT RECORD

Lives at: `[FREELANCE_FOLDER]/CLIENTS.md`
Same location as MASTER_BILLING.md.

```markdown
# CLIENTS.md — Prospect and Client Record
# Brian Onieal | Freelance AI Systems Engineer
# Last updated: [DATE]

---

## ACTIVE CLIENTS

| Client | Company | Project | Start | Gate | Billed | Status |
|--------|---------|---------|-------|------|--------|--------|
| [NAME] | [CO] | [APP] | [DATE] | v[X] | $[X] | ACTIVE |

---

## PROSPECTS (not yet converted)

| Client | Company | Project | Date | Proposal | Budget | Status |
|--------|---------|---------|------|----------|--------|--------|
| [NAME] | [CO] | [APP] | [DATE] | SENT | $[X] | PENDING |
| [NAME] | [CO] | [APP] | [DATE] | SENT | $[X] | DECLINED |
| [NAME] | [CO] | [APP] | [DATE] | SENT | $[X] | GHOSTED |

---

## COMPLETED PROJECTS

| Client | Company | Project | Dates | Total | Outcome |
|--------|---------|---------|-------|-------|---------|
| [NAME] | [CO] | [APP] | [D]-[D] | $[X] | COMPLETE |

---

## CLIENT NOTES

### [CLIENT NAME] -- [COMPANY]
**First contact:** [DATE]
**Project:** [APP NAME]
**Decision maker:** [NAME, ROLE]
**Budget:** $[X] (mentioned / estimated)
**Timeline pressure:** [what's driving their deadline]
**Decision criteria:** [price / speed / quality / methodology]
**Competitors pitched:** [others they talked to if known]
**Outcome:** [CONVERTED / DECLINED / GHOSTED / PENDING]
**Outcome notes:** [why they chose or didn't choose Brian]
**Follow-up date:** [DATE -- for pending prospects]
```

---

## OUTPUT FOLDER STRUCTURE

```
[FREELANCE_FOLDER]/
  onboarding/
    [CLIENT_CO]_PROPOSAL_[DATE].pdf
    [CLIENT_CO]_CONTRACT_[DATE].pdf
    [CLIENT_CO]_PROPOSAL_EMAIL_[DATE].txt
  CLIENTS.md
  MASTER_BILLING.md
  generate_invoice.py
```

---

## INTEGRATION WITH OTHER SKILLS

**Build Rules:**
When a client converts and signs, `/onboard` passes the approved
gate structure to Build Rules so VERSION_ROADMAP.md is pre-populated
from the proposal. No re-doing the scoping work.

**Freelance Billing:**
When a client converts, Claude creates a new entry in MASTER_BILLING.md
with the contract value, payment schedule, and project start date.
TIMELOG.md is initialized for the project.

**Cost Tracker:**
Client's operating cost responsibility (they pay / Brian pays)
is logged to COSTS.md when the project begins.

---

## COMMAND WORDS

| You type | What happens |
|----------|--------------|
| `/onboard` | Invoke client onboarding session |
| `READY` | Brain dump complete, begin interrogation |
| `PROCEED` | Assessment confirmed, generate estimate |
| `APPROVE ESTIMATE` | Estimate approved, generate documents |
| `ADJUST [item]` | Change something before generating |
| `DECLINE` | Log prospect as declined, close session |
| `CONVERTED` | Mark prospect as converted in CLIENTS.md |
| `FOLLOW UP [date]` | Set follow-up reminder in CLIENTS.md |

---

## RULES

- Never generate documents without Brian approving the estimate first
- Always give Brian an honest assessment before proceeding -- including
  recommending against pursuing a project if the signals are bad
- Contract note must always appear -- remind Brian to get legal review
  for high-value engagements
- CLIENTS.md must be updated for every prospect -- converted or not
- Declined and ghosted prospects are as important to log as conversions
- Proposal is valid for 30 days -- state this on every proposal
- Never adjust the hourly rate below $150 in any generated document
- If client's budget is below project estimate -- surface the gap
  honestly and give Brian options before generating documents

---

# END OF ONBOARD SKILL v1.0
# Next version: v1.1 -- informed by first real client onboarding
