---
name: health
description: "Knowledge health check skill for all app builds. Invoke with /health to audit all blueprint files for contradictions, stale information, missing connections, and drift from current decisions. Runs agnix validation, transcript pattern analysis, and research staleness check. Auto-triggers monthly. Produces HEALTH_REPORT.md with targeted fixes. Makes the blueprint system compound over time."
---

# HEALTH SKILL
# Owner: Brian Onieal | Freelance AI Systems Engineer
# Version: 2.0 | April 2026 | Blueprint v3
# Invoke: /health
# Inspired by: Karpathy's LLM Knowledge Base linting concept

---

## WHAT THIS IS

The Health skill audits all blueprint files for decay, contradiction,
and missed connections. It makes the build system compound over time
rather than become stale and misleading.

v2.0 adds three new capabilities:
1. **agnix validation** -- lint all blueprint files for malformed configs
2. **Transcript analysis** -- read Claude Code session logs for recurring
   patterns and suggest new skills or hooks to automate them
3. **Improved research staleness** -- market-specific refresh cadences

---

## WHEN IT RUNS

**Automatic monthly prompt:**
At the start of every new project session, /start checks the last
health check date in MEMORY.md and prompts when 30 days have passed:
```
HEALTH CHECK DUE: Last check was [X] days ago.
1. Run /health now (recommended)
2. Skip for this session
```

**Manual:** `/health` anytime
**Quick mode:** `/health quick` -- contradictions only, ~60 seconds
**Triggered:** After any major pivot, after adding new skills, after a gate
with many ERRORS.md entries, or any time /start detects inconsistencies.

---

## INVOCATION

When `/health` is invoked:

```
Health check started for [APP NAME].

Running 5-dimension audit:
1. Contradictions between files
2. Stale data
3. Missed connections
4. Orphaned content
5. Memory gaps

Also running:
- agnix blueprint file validation
- Transcript pattern analysis
- Research staleness check

Estimated time: 10-15 minutes.
```

---

## DIMENSION 1 -- CONTRADICTIONS

Files that disagree with each other.

Examples:
- CONTRACT.md model vs DECISIONS.md rejected model
- TECH_STACK.md migration tool vs CLAUDE.md reference (Prisma vs Alembic)
- COUNCIL_AGENTS.md agents vs VERSION_ROADMAP.md deferred agents
- HARNESS.md tool in registry not granted to any agent in COUNCIL_AGENTS.md
- DESIGN_SYSTEM.md Phase 1 complete but tokens show {{HEX}} placeholders
- MOCKUPS.md shows APPROVED but DECISIONS.md shows that design was changed
- SPEC.md passing criteria vs actual tests written in TESTS.md
- Two DECISIONS.md entries with conflicting resolutions

Severity: HIGH -- contradictions cause active harm during builds.

---

## DIMENSION 2 -- STALE DATA

Information that was true but may no longer be.

Examples:
- RESEARCH.md last updated more than 60 days ago (fintech)
- RESEARCH.md last updated more than 90 days ago (other markets)
- Competitor pricing in RESEARCH.md that has likely changed
- DECISIONS.md result fields blank for decisions made more than 30 days ago
- COSTS.md AI model pricing that has changed
- TECH_STACK.md dependency versions more than 2 major versions behind
- PERFORMANCE.md metrics from more than 3 gates ago
- SECURITY.md last audit more than 60 days old on a production app
- MEMORY.md open questions older than 60 days with no resolution

Severity: MEDIUM

---

## DIMENSION 3 -- MISSED CONNECTIONS

Relationships between files not yet made explicit.

Examples:
- ERRORS.md has 3+ entries with the same root cause not in MEMORY.md patterns
- DECISIONS.md decision affects file not listed in its impact section
- RESEARCH.md gap not reflected in VERSION_ROADMAP.md features
- MEMORY.md "what doesn't work" entry not in ERRORS.md as a prevention rule
- COSTS.md optimization not reflected in TECH_STACK.md rationale
- SECURITY.md finding implying HARNESS.md permission needs updating
- PERFORMANCE.md bottleneck implying DATABASE schema index is missing
- SPEC.md out-of-scope list not matching what MOCKUPS.md shows as approved

Severity: LOW to MEDIUM

---

## DIMENSION 4 -- ORPHANED CONTENT

Decisions or rules that no longer apply.

Examples:
- DECISIONS.md entries for features cut from scope
- ERRORS.md prevention rules for technologies no longer in stack
- COUNCIL_AGENTS.md entries for agents deferred post-MVP without DEFERRED label
- HARNESS.md layers checked active for features not yet built
- CONTRACT.md feature flags for features not in current VERSION_ROADMAP.md
- MOCKUPS.md screens for features cut from roadmap

Severity: LOW

---

## DIMENSION 5 -- MEMORY GAPS

New entries MEMORY.md should have based on current project state.

- Patterns in ERRORS.md not yet in MEMORY.md pattern library
- Cross-file connections not yet in MEMORY.md connections table
- "What works / what doesn't" observations from DECISIONS.md results
- Open questions answered elsewhere but not resolved in MEMORY.md

---

## AGNIX VALIDATION (new in v2.0)

As part of every health check, Claude runs:

```bash
npx agnix . --target claude-code
```

This validates all blueprint files against 385 rules covering:
- CLAUDE.md instruction quality and line count
- AGENTS.md subagent definition format
- SKILL.md frontmatter correctness (name format, description length)
- settings.json hook syntax and event matcher validity
- MCP configuration format
- Hook injection risk detection

**Why this matters:**
A skill named `Review-Code` never auto-triggers -- agnix catches this.
A hook using `type: "prompt"` on PreToolUse silently does nothing -- agnix catches this.
A CLAUDE.md over 200 lines -- agnix catches this.

**agnix output interpretation:**
```
AGNIX VALIDATION RESULTS

Errors: [N] -- must fix before building
Warnings: [N] -- should fix
Auto-fixable: [N] -- run `npx agnix --fix .`

[List of findings with file, line, rule, fix]
```

CRITICAL/HIGH agnix findings block gate close.
Claude runs `npx agnix --fix-safe .` to auto-fix what it can,
then reports remaining manual fixes.

---

## TRANSCRIPT PATTERN ANALYSIS (new in v2.0)

Claude Code saves session transcripts to `~/.claude/sessions/`.
The health check reads recent transcripts and identifies:

**Recurring manual tasks:**
Things you type in every session that could be automated.
Examples: "run the tests", "check the gate", "show current status"
Recommendation: Create a custom slash command for repeated tasks.

**Repeated corrections:**
Things Claude gets wrong repeatedly that should be a hook or rule.
Examples: Consistently forgetting to update TIMELOG.md, consistently
using wrong model name.
Recommendation: Add a hook or strengthen the rule in CLAUDE.md.

**Common pain points:**
Tasks that take multiple back-and-forth exchanges to accomplish.
Recommendation: Create a new skill or subagent for this task type.

**Transcript analysis output:**
```
TRANSCRIPT ANALYSIS: Last [N] sessions

Recurring patterns identified:

PATTERN-001: You manually trigger test runs [N] times per session.
RECOMMENDATION: Add a PostToolUse hook that runs tests after
every file write to backend/app/ directory.

PATTERN-002: TIMELOG.md update is frequently forgotten at session end.
RECOMMENDATION: Add to Stop hook to prompt for session time logging.

PATTERN-003: [N] sessions spent debugging Supabase RLS policies.
RECOMMENDATION: Create a supabase-rls-debug subagent with
focused RLS troubleshooting context.

[List additional patterns]

Proposed new commands/hooks/skills: [N]
Type APPLY PATTERNS to implement recommendations.
```

---

## RESEARCH.md AUTO-REFRESH

When /health detects RESEARCH.md is stale:

**Cadence by market:**
- Fintech (Forge Finance): 60 days
- Community/SaaS (Feast-AI): 90 days
- Slow-moving markets: 180 days
- After any major competitor announcement: immediately

**Refresh output:**
```
RESEARCH REFRESH: [APP NAME]

RESEARCH.md was last updated [X] days ago.
Re-researching: [competitor list]
Focus: pricing changes, new features, new entrants

CHANGES DETECTED:

Pricing changes:
- [Competitor]: [old] → [new]

New features shipped:
- [Competitor]: [feature] -- Threat: LOW/MED/HIGH
  Impact on roadmap: [which gate/feature affected]

New competitors:
- [Name]: [description] | Threat: LOW/MED/HIGH

No longer relevant:
- [Competitor]: [why]

Unchanged: [N] items

ROADMAP ALERT (if any):
[Competitor] shipped [feature] you planned as differentiator at v[X.X.X].
Recommend: keep / accelerate / differentiate / drop

RESEARCH.md updated.
```

---

## HEALTH REPORT OUTPUT

```markdown
# HEALTH_REPORT.md
# App: [APP NAME]
# Generated: [DATE]
# Files audited: [N]

---

## OVERALL HEALTH: EXCELLENT / GOOD / NEEDS ATTENTION / CRITICAL

| Dimension | Findings | Severity |
|-----------|----------|----------|
| Contradictions | [N] | HIGH |
| Stale data | [N] | MEDIUM |
| Missed connections | [N] | MEDIUM |
| Orphaned content | [N] | LOW |
| Memory gaps | [N] | LOW |
| agnix errors | [N] | HIGH |
| agnix warnings | [N] | MEDIUM |
| Transcript patterns | [N] | LOW |

---

## FINDINGS

### CONTRADICTION-001 [HIGH]
Files: [FILE A] ↔ [FILE B]
What: [specific conflict]
Fix: [what to change]
Auto-fix: YES / NO
Type FIX CONTRADICTION-001 to apply.

[...additional findings...]

---

## RECOMMENDED ACTIONS (priority order)

1. [action] -- [severity] -- [auto-fix available]
2. [action] -- [severity] -- [auto-fix available]

Type FIX ALL to apply all auto-fixable findings.
Type FIX [ID] to apply individual fix.
Type DEFER [ID] to skip for now.

---

## MEMORY.md PROPOSED ADDITIONS

[N] new entries proposed based on this audit.
Type ACCEPT MEMORY to add all.
```

---

## HEALTH SCORE

| Finding type | Points deducted |
|-------------|----------------|
| Contradiction (HIGH) | -10 each |
| agnix error (HIGH) | -8 each |
| Stale data >90 days (MEDIUM) | -5 per file |
| Missed connection (MEDIUM) | -3 each |
| agnix warning (MEDIUM) | -2 each |
| Orphaned content (LOW) | -1 each |
| Memory gap (LOW) | -1 each |

Excellent: 90-100 | Good: 75-89 | Needs attention: 60-74 | Critical: <60

Health history tracked in MEMORY.md.

---

## COMMAND WORDS

| You type | What happens |
|----------|--------------|
| `/health` | Full audit |
| `/health quick` | Contradictions + agnix only |
| `/health research` | Research staleness only |
| `/health memory` | Memory gap analysis only |
| `/health transcripts` | Transcript pattern analysis only |
| `/health agnix` | agnix validation only |
| `FIX ALL` | Apply all auto-fixable findings |
| `FIX [ID]` | Apply specific fix |
| `DEFER [ID]` | Skip this finding |
| `UPDATE RESEARCH` | Trigger research refresh |
| `ACCEPT MEMORY` | Add proposed MEMORY.md entries |
| `APPLY PATTERNS` | Implement transcript recommendations |
| `HISTORY` | Show health score history |

---

## INTEGRATION

**START skill:** Health prompt at session start when >30 days since last check.
**BUILD RULES:** agnix check at every gate close is part of gate close checklist.
**RESEARCH skill:** /health triggers /research UPDATE when stale.
**MEMORY.md:** Health history stored here. Proposed entries reviewed here.
**DECISIONS.md:** Health contradictions may require new decisions -- log them.

---

## RULES

- Never auto-fix a contradiction without showing what will change
- Never delete content -- mark as DEFERRED or ORPHANED
- Always run full audit before proposing fixes
- Health score below 60 = CRITICAL -- resolve before building
- agnix errors block gate close -- they are not optional
- Transcript analysis reads only ~/.claude/sessions/ -- no other data
- All fixes sequential, never parallel
- MEMORY.md additions are proposals -- Brian approves

---

# END OF HEALTH v2.0
# Changelog from v1.0:
# - agnix validation added as core audit step
# - Transcript pattern analysis for skill/hook recommendations
# - Market-specific research staleness cadences
# - agnix findings integrated into health score
# - APPLY PATTERNS command for transcript recommendations
# - MOCKUPS.md included in contradiction checks
# - DECISIONS.md result fields checked for staleness
# - SPEC.md passing criteria cross-referenced with TESTS.md
