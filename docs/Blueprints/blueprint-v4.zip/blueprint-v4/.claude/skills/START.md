---
name: start
description: "Master session orchestration skill for Brian Onieal. Invoke with /start at the beginning of every coding session. Asks if starting a new project or continuing an existing one. Automatically activates and sequences all relevant skills in the correct order. New project: research, critical-thinker, build-rules, costs, testing, security, performance, debug. Continuing: reads project files, reconstructs state, confirms with Brian, resumes at current gate. Optional: onboard and freelance-billing for new client projects."
---

# START
# Owner: Brian Onieal | Freelance AI Systems Engineer
# Version: 4.0 | April 2026 | Blueprint v4
# Invoke: /start

---

## WHAT THIS IS

START is the single command Brian types at the beginning of every
coding session. It orchestrates all relevant skills automatically
in the correct order.

One command. Everything activates.

---

## SKILLS THIS ORCHESTRATES

| Skill | Trigger |
|-------|---------|
| `/research` | New project -- before build starts |
| `/critical-thinker` | New project + every architectural decision |
| `/build-rules` | New project -- full intake and build governance |
| `/costs` | New project -- initialized during build-rules intake |
| `/onboard` | New CLIENT project -- optional, asked once |
| `freelance-billing` | New CLIENT project -- optional, asked once |
| `/testing` | Every gate -- PRE and POST build |
| `/security` | Every gate lightweight + pre-production full audit |
| `/performance` | Every gate lightweight + pre-production full audit |
| `/health` | Monthly auto-prompt at session start |
| `/debug` | On demand + auto-triggered by circuit breaker |

**Not included:**
- `/coursework` -- academic work, invoked separately
- `/handoff` -- auto-triggered by build-rules at v1.0.0 gate close
- `/deploy` -- auto-triggered by build-rules at production gate

---

## INVOCATION

When `/start` is typed, Claude responds immediately:

---

"Session started.

Are you:
1. Starting a NEW project
2. Continuing an EXISTING project

Type 1 or 2."

---

## PATH 1 -- NEW PROJECT

### Step 1 -- Project type detection

After Brian types `1`, Claude asks:

```
Is this project for a client or for yourself?

1. Client project
2. Personal project / own product

Type 1 or 2.
```

### Step 2 -- Optional skills (client projects only)

If client project:
```
Two optional skills available for client work:

/onboard -- generates proposal, contract, and email PDF
            (use if you haven't signed the client yet)

freelance-billing -- starts time tracking for this session
                    (use for all billable client work)

Do you need either?
1. Both -- onboard this client AND track time
2. Onboard only -- client not signed yet
3. Billing only -- client is signed, track time
4. Neither -- skip for now

Type 1, 2, 3, or 4.
```

If personal project -- skip optional skills, proceed to Step 3.

### Step 3 -- Health check prompt

```
HEALTH CHECK: When did you last run /health?

1. Never or more than 30 days ago -- run /health now
2. Within the last 30 days -- skip and proceed

Type 1 or 2.
```

If `1`: run /health quick (contradictions only, ~60 seconds).

### Step 4 -- Research

Claude activates `/research`:

```
SKILL ACTIVATED: /research

Understanding the competitive landscape before we define anything.

[Runs /research intake protocol]
[RESEARCH.md generated]

Research complete. Activating critical thinker...
```

### Step 5 -- Critical Thinker (pre-build review)

Claude activates `/critical-thinker`:

```
SKILL ACTIVATED: /critical-thinker

Reading RESEARCH.md...
Preparing to pressure-test the technical approach.

[Runs /critical-thinker build-start review after roadmap proposed]
[Brian types PROCEED after review]

Critical thinker review complete. Activating build system...
```

### Step 6 -- Build Rules (full intake)

Claude activates `/build-rules`:

```
SKILL ACTIVATED: /build-rules v4.0

Note: /costs, /testing, /security, and /performance will activate
automatically at the appropriate moments. No need to invoke manually.

Build Rules v4 introduces the FRONTEND SPEC GATE:
FRONTEND_SPEC.md is generated and approved BEFORE any UI code.
This is mandatory and cannot be skipped.

[Runs full /build-rules protocol]
[Intake → Interrogation → Roadmap → Mockups → Frontend Spec → Build]
```

### Step 7 -- Automatic skill activation during build

| Moment | Skill activated | What happens |
|--------|----------------|--------------|
| Gate open | BUILD_RULES generates SPEC.md | Spec written before code |
| Gate open | test-writer subagent | Tests written before implementation |
| Before any screen | FRONTEND_SPEC.md check | Spec confirmed before component |
| Before any screen | MOCKUPS.md check | Approval confirmed before building |
| Any architectural decision | /critical-thinker | Decision pressure-test |
| Any decision with cost | /costs | Cost note shown |
| Gate close | security-reviewer subagent | Security scan |
| Gate close | performance-checker subagent | Performance scan |
| Gate close | deslop-reviewer subagent | AI artifact scan |
| Gate close | /testing POST-BUILD | Tests run, coverage checked |
| Gate close | FRONTEND_SPEC.md compliance | All components verified |
| Gate close | CHANGELOG.md update | What shipped logged |
| Gate close | TIMELOG.md update | Hours and cost logged |
| Gate close | agnix validation | Blueprint files linted |
| 3 consecutive failures | /debug | Circuit breaker triggers |
| Pivot requested | /critical-thinker | Pivot evaluation |
| v1.0.0 gate close | /handoff | Client documents generated |
| Production deploy | /security full audit | Full OWASP + AI + infra |
| Production deploy | /performance full audit | Full 4-layer audit |

---

## PATH 2 -- CONTINUING AN EXISTING PROJECT

### Step 1 -- File reading

After Brian types `2`, Claude asks:

```
What is the project root path?
(e.g. D:\Trailwai\ or D:\Forge-Finance\)

Type the path or HERE if already in the project directory.
```

### Step 2 -- Automatic state reconstruction

Claude reads 17 files in order:

```
READING PROJECT STATE...

1.  CLAUDE.md ............. boot sequence and sacred rules
2.  MEMORY.md ............. cross-session learnings
3.  DECISIONS.md .......... architectural decision history
4.  CONTRACT.md ........... config and project identity
5.  VERSION_ROADMAP.md .... current gate and history
6.  SPEC.md ............... current gate specification
7.  PLANS.md .............. active tasks and session log
8.  ERRORS.md ............. known failure modes
9.  TESTS.md .............. test registry and coverage
10. TIMELOG.md ............ hours logged and billing status
11. COSTS.md .............. cost thresholds and current spend
12. SECURITY.md ........... last audit and open findings
13. PERFORMANCE.md ........ last audit and open findings
14. MOCKUPS.md ............ mockup approval status and drift log
15. CHANGELOG.md .......... what shipped at each gate
16. RESEARCH.md ........... competitive intelligence (if exists)
17. FRONTEND_SPEC.md ...... UI component specs (NEW in v4)
```

### Step 3 -- Frontend spec drift check (new in v4)

After reading files, Claude checks FRONTEND_SPEC.md against any
recently built components:

```
FRONTEND SPEC CHECK:
Comparing built components against FRONTEND_SPEC.md...

[CLEAR] -- all built components match the spec
[DRIFT] -- [N] components diverged from spec:
  - [component name]: [what diverged]
  Action required before continuing frontend work.
```

### Step 4 -- Mid-gate detection

After file reads, Claude checks SPEC.md and PLANS.md:

**At gate boundary:**
```
You're at a gate boundary.
Gate v[X.X.X] is COMPLETE.
Next gate: v[X.X.X] -- [GATE NAME]

Generating SPEC.md for next gate...
[SPEC.md generated]

Ready to open gate v[X.X.X]. Type GO to begin.
```

**Mid-gate:**
```
You're mid-gate at v[X.X.X] -- [GATE NAME].

Completed this gate so far:
- [task from PLANS.md]

Active tasks remaining:
- [task from SPEC.md not yet checked]

Tests: [X] passing / [X] failing
[If failing: IMPORTANT -- fix before writing new code. Type /debug.]

Next frontend component: [component name from FRONTEND_SPEC.md]
Resuming at: [first unchecked task from SPEC.md]
```

### Step 5 -- Status summary

```
PROJECT STATUS: [APP NAME]

Current gate: v[X.X.X] -- [GATE NAME]
Position: [AT BOUNDARY / MID-GATE at task [N] of [TOTAL]]

Last session: [from PLANS.md]
Next task: [first unchecked SPEC.md task or next gate open]

Tests: [X] passing / [X] failing
Open errors: [X] items in ERRORS.md
Security: Last check [DATE] -- [PASS / OPEN FINDINGS]
Performance: Last check [DATE] -- [PASS / OPEN FINDINGS]
Mockups: [X] APPROVED / [X] PENDING / [X] DRIFT
Frontend Spec: [CURRENT / DRIFT on [N] components]
Hours logged: [X] hrs ([billed / unbilled at $150/hr])
Current AI cost: $[X]/month (threshold: [PASS / WARNING])

Does this look right? Type YES to resume or
CORRECT [what's wrong] if anything is off.
```

### Step 6 -- Health check (continuing sessions)

```
HEALTH CHECK: Last run [DATE] -- [X] days ago.
[If > 30 days:] Run /health before building? (1. Yes  2. Skip)
[If < 30 days:] Health check current. Proceeding.
```

### Step 7 -- Resume

After Brian types `YES`:

```
Resuming [APP NAME] at [GATE / TASK].

All skills active and will trigger automatically.

[If FRONTEND_SPEC.md drift:]
⚠️ [N] components diverged from FRONTEND_SPEC.md:
- [component]: [drift description]
Resolve before continuing frontend work.

[If open errors:]
⚠️ [X] open items in ERRORS.md:
- [ERR-ID]: [description]
Address these or type SKIP to continue.

[If failing tests:]
⚠️ [X] failing tests. Fix before new code. Type /debug.

[If MOCKUPS.md DRIFT:]
⚠️ [X] mockup drift entries. Resolve before frontend work.

[If open security findings:]
⚠️ [X] open security findings.

[If all clear:]
All clear. Continuing from: [current task].
What are we working on?
```

### Step 8 -- Billing prompt (client projects only)

```
BILLING: Client project ([CLIENT NAME]).
Starting time tracking now.
Rate: $150/hr | Current unbilled: $[X] ([X] hrs)
Time tracking active.
```

---

## SKILL COORDINATION RULES

**Rule 1:** No double invocation. If Brian manually invokes a skill
that START already activated, Claude acknowledges and continues.

**Rule 2:** Skill output flows forward.
Research → Critical Thinker → Build Rules.
Gate open → SPEC.md → test-writer → build → frontend spec check
→ deslop → CHANGELOG → TIMELOG → close.

**Rule 3:** Hard blocks are cumulative. Gate cannot close until ALL pass:
- /testing POST-BUILD: GATE STATUS PASS
- security-reviewer: PASS (no CRITICAL/HIGH)
- performance-checker: PASS (no CRITICAL/HIGH)
- deslop-reviewer: CLEAN or REVIEW (not BLOCK)
- CHANGELOG.md: updated
- SPEC.md: all items checked
- FRONTEND_SPEC.md: all components match spec
- MOCKUPS.md: no DRIFT entries
- agnix: no errors

**Rule 4:** Debug takes priority over all other work.

**Rule 5:** Cost notes always on. /costs runs in background.

**Rule 6:** Critical Thinker always watching.
Auto-triggers on every significant architectural decision.

**Rule 7:** SPEC.md is the gate contract.
If something in SPEC.md is not done, the gate cannot close.

**Rule 8 (new in v4):** FRONTEND_SPEC.md is the component contract.
If a component doesn't match the spec, it must be fixed before
the gate can close. No exceptions.

---

## SESSION END PROTOCOL

```
SESSION WRAP-UP

Time logged: [X] hours this session
Gate: v[X.X.X] -- [IN PROGRESS / COMPLETE]

Modified files this session:
[list from PLANS.md session tracking]

Test status: [X] passing / [X] failing
Frontend spec compliance: [CURRENT / DRIFT on [N] components]
New ERRORS.md entries: [X]
New DECISIONS.md entries: [X]
MEMORY.md: [X] new entries added / none this session

[If gate completed:]
Gate v[X.X.X] COMPLETE.
CHANGELOG.md updated. TIMELOG.md updated.
Next gate: v[X.X.X] -- [GATE NAME]

[If mid-gate:]
PLANS.md session log updated.
SPEC.md position: task [N] of [TOTAL]
Next session resumes at: [task description]

[If health check > 30 days:]
HEALTH CHECK DUE. Run /health before next session.

[If client project:]
Unbilled: [X] hrs ($[X] at $150/hr)
Type BILL to generate summary.

Session logged.
```

---

## COMMAND WORDS

| You type | What happens |
|----------|--------------|
| `/start` | Invoke master orchestrator |
| `1` | New project path |
| `2` | Continuing project path |
| `YES` | Confirm state, begin session |
| `CORRECT [what]` | Fix state summary |
| `SKIP` | Skip open warnings, proceed |
| `GO` | Open next gate |
| `+onboard` | Activate onboard mid-session |
| `+billing` | Activate billing mid-session |
| `+research` | Run research mid-session |
| `STATUS` | Current project status |
| `BILL` | Generate invoice summary |
| `WRAP` | Trigger session end manually |
| `SPEC` | Show current gate spec |
| `DECISIONS` | Show decision log |
| `FRONTEND` | Show FRONTEND_SPEC.md for current gate's screens |

---

# END OF START v4.0
# Changelog from v3.0:
# - FRONTEND_SPEC.md added to state reconstruction (17 files, up from 16)
# - Frontend spec drift check added to session resume
# - Frontend spec compliance added to hard blocks
# - FRONTEND command word added
# - Step 7 (schema rebuild): FRONTEND_SPEC.md drift shown as warning
# - Rule 8 added: FRONTEND_SPEC.md is the component contract
# - Gate auto-activation table: FRONTEND_SPEC.md and MOCKUPS.md checks added
