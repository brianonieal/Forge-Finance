# enforce-conventions.md
# Owner: Brian Onieal | Freelance AI Systems Engineer
# Version: 3.0 | April 2026 | Blueprint v3
# Location: D:\.claude\rules\enforce-conventions.md
#
# These rules are always active across ALL projects.
# They load automatically in every Claude Code session.

---

## Sequential Build Rules (CRITICAL)
- NEVER suggest parallel file writes across backend and frontend simultaneously
- NEVER suggest doing multiple file changes at the same time
- ALWAYS complete backend changes and validate before touching frontend
- Order within any gate: backend config → backend deps → validate backend →
  frontend deps → frontend config → validate frontend → validate together → tests
- After every single file change: validate it works before moving to the next file
- Source of this rule: Forge Genesis v15-v29 regression cycle from parallel writes

## Blueprint v3 File Rules
- CONTRACT.md is the single source of truth. Never hardcode config values.
- SPEC.md must be generated at every gate open before any implementation
- CHANGELOG.md must be updated at every gate close before typing GATE COMPLETE
- DECISIONS.md must be updated when any architectural decision is made
- MOCKUPS.md must be checked before building any UI screen or component
- MEMORY.md must be written to at session end if genuine learnings occurred
- ERRORS.md must be updated immediately when any mistake is made

## Gate Rules
- No gate closes without all tests passing
- No gate closes without security lightweight check passing
- No gate closes without performance lightweight check passing
- No gate closes without deslop review passing
- No gate closes without agnix passing (no errors)
- No gate closes without CHANGELOG.md updated
- No gate closes without TIMELOG.md updated with hours and cost
- No frontend work starts without MOCKUPS.md APPROVED entry for that screen
- No version gate is skipped. Ever.
- VERSION BOUNDARIES ARE SACRED -- no future version features in current gate

## Context Management Rules
- Compact at 50% context fill max. NEVER wait for auto-compact at 83.5%
- If corrected more than twice on the same issue: /clear and restart with better prompt
- Use subagents for codebase investigation to keep main context clean
- Compact instruction: "/compact focus on [current task], modified files, test status, current gate"

## Agent Rules
- Subagents always receive fresh messages[] -- never inherit parent context
- Coordinator agents use prompt-as-algorithm, not code
- Workers never spawn other workers
- Each subagent has tool restrictions -- only the tools it actually needs

## Security Rules
- Never expose secret keys in frontend env vars (no NEXT_PUBLIC_ prefix on secrets)
- API keys go in backend .env only
- Never commit .env files
- Never put ANTHROPIC_API_KEY, VOYAGE_API_KEY, or PLAID credentials in frontend
- Run varlock check before any deploy to confirm no secrets in logs or session files

## Code Quality Rules
- Run /deslop on modified files before committing
- No debug console.log statements committed
- No TODO/FIXME/HACK markers left in committed code
- No placeholder text ({{}}, lorem ipsum) in committed code
- No commented-out code blocks committed

## Blueprint File Quality Rules
- CLAUDE.md must stay under 200 lines -- use @imports for everything else
- Skill names must be kebab-case (review-code, not Review-Code)
- Run `npx agnix .` before gate close to catch malformed blueprint files
- settings.json hook event matchers must match Claude Code spec exactly
- AGENTS.md subagent files go in .claude/agents/ directory

## Communication Rules
- Never use em dashes in any output
- Never use the words "spearheading" or "dogfooding"
- Never use "genuinely", "straightforward", or "honestly" as filler
- Use bold for key terms, bullet points for lists
- Get straight to the point -- no filler sentences
- For discussion boards: grounded, helpful, never lecturing
- For assignments: follow the specific format shown in the upload

## Billing Rules
- Log every session in TIMELOG.md before closing
- Discovery and planning hours are billable
- Client-requested scope changes get SCOPE tag in TIMELOG.md
- Rate is $150/hr for all client work
- Generate invoice with generate_invoice.py
- Invoice numbering: CLIENT-NNN format (e.g. FEAST-001)

---

# Version History
# v1.0 -- initial conventions
# v2.0 -- sequential build rule added (Forge Genesis source)
# v3.0 -- Blueprint v3 file rules, deslop, agnix, varlock, SPEC/CHANGELOG/DECISIONS/MOCKUPS
