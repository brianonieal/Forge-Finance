# ERRORS.md — Living Failure Log
# {{APP_NAME}}
#
# PURPOSE: When Claude makes a mistake, it adds an entry here immediately.
# This file is read at the start of every session to prevent repeated errors.
# This is the institutional memory of what has gone wrong on this project.
#
# FORMAT:
# ## [ERROR-NNN] Short title
# **Date:** YYYY-MM-DD
# **Version:** vX.X.X
# **Category:** regression | type-error | config | agent | harness | design | test
# **What happened:** Brief description
# **Root cause:** Why it happened
# **Fix:** What was done
# **Prevention rule:** Rule added to CLAUDE.md or CONTRACT.md as a result

---

## [ERROR-000] Template initialized -- no errors yet
**Date:** {{DATE}}
**Version:** v0.0.0
**Category:** n/a
**What happened:** Project initialized. ERRORS.md is empty.
**Root cause:** n/a
**Fix:** n/a
**Prevention rule:** Begin populating this file the moment the first mistake is made.

---

# Error Index
| ID       | Title                     | Version | Category   |
|----------|---------------------------|---------|------------|
| ERR-000  | Template initialized      | v0.0.0  | n/a        |

---

# Regression Watchlist
Patterns from past projects (Forge Genesis, Forge Finance, EOM-AI) to guard against:

- **Config hardcoding:** Values defined in CONTRACT.md that got hardcoded in source files. Caused by skipping CONTRACT.md read at session start.
- **Version gate skip:** Proceeding to next version with failing tests because "it's just one small thing." Always causes downstream regression.
- **Agent context bleed:** Subagent inheriting parent conversation context, producing wrong outputs. Caused by not using fresh messages[] for subagents.
- **Design drift:** UI diverging from DESIGN_SYSTEM.md color/font tokens because Claude used generic Tailwind classes. Caused by not reading DESIGN_SYSTEM.md before component work.
- **Agent role confusion:** One agent taking actions permitted only for another. Caused by imprecise tool permission definitions in COUNCIL_AGENTS.md.
- **Context overload:** Session degrading after 60%+ context fill. Caused by not compacting at 50% threshold.
