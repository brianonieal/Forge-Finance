# CHANGELOG.md
# {{APP_NAME}}
# Format: Conventional Commits (https://www.conventionalcommits.org)
#
# RULE: Updated at every gate close -- not before, not after.
# RULE: Entries written by Claude at gate close, reviewed by Brian.
# RULE: Never delete entries. Use DEPRECATED tag if needed.
# RULE: Follows Semantic Versioning: MAJOR.MINOR.PATCH
#
# Entry types:
# feat:     New feature (MINOR version bump)
# fix:      Bug fix (PATCH version bump)
# chore:    Tooling, config, dependencies (no version bump)
# docs:     Documentation only (no version bump)
# refactor: Code restructure without behavior change (PATCH)
# test:     Adding or updating tests (no version bump)
# perf:     Performance improvement (PATCH)
# security: Security fix (PATCH or MINOR)
# BREAKING CHANGE: Breaking change (MAJOR version bump)

---

## [Unreleased]
Changes staged for next release.

---

## [0.0.0] — {{DATE}} — Foundation

### chore
- Initialized repository with Blueprint v3 foundation files
- Populated CLAUDE.md, CONTRACT.md, HARNESS.md, ERRORS.md
- Populated TECH_STACK.md, DESIGN_SYSTEM.md, COUNCIL_AGENTS.md
- Populated MOCKUPS.md, CHANGELOG.md, SPEC.md, MEMORY.md, DECISIONS.md
- Confirmed environment variables against CONTRACT.md
- Database connection verified

### Status: COMPLETE
**Tests:** N/A
**Gate duration:** {{HOURS}} hrs
**Gate cost:** ${{COST}} at $150/hr

---

## Gate Entry Template (copy for each gate close)

## [VERSION] — DATE — GATE_NAME

### feat / fix / chore / etc
- {{WHAT_SHIPPED}}
- {{WHAT_SHIPPED}}

### Breaking Changes (if any)
- {{BREAKING_CHANGE_DESCRIPTION}}

### Status: COMPLETE
**Tests:** {{X}} passing / {{Y}} failing
**Gate duration:** {{HOURS}} hrs
**Gate cost:** ${{COST}} at $150/hr
**Notes:** {{ANY_RELEVANT_CONTEXT}}

---

## Version History Summary

| Version | Date | Gate Name | Status | Tests |
|---------|------|-----------|--------|-------|
| 0.0.0 | {{DATE}} | Foundation | COMPLETE | N/A |
