# {{APP_NAME}}
{{ONE_LINE_DESCRIPTION}} | Stack: {{STACK_SUMMARY}}
# Blueprint v4 | Built with Build Rules v4 | Trailwai-ready

## Boot Sequence
Run in order. Do not skip steps.

1. Read this file completely
2. Load @MEMORY.md -- cross-session learnings first
3. Load @ERRORS.md -- known failure modes
4. Load @CONTRACT.md -- all config values from here only
5. Run `npx agnix .` -- lint blueprint files, fix HIGH findings
6. Check DESIGN_SYSTEM.md Phase 1 gate -- must be complete before any UI
7. Check MOCKUPS.md -- every screen needs APPROVED before building
8. Check FRONTEND_SPEC.md -- read UI component spec before any frontend work
9. If last health check > 30 days: prompt Brian to run /health
10. Load remaining docs on demand via @imports as work requires
11. Session END: write 1-3 entries to MEMORY.md if genuine learnings
12. Session END: run /deslop on modified files before committing
13. Session END: propose one update to this file based on what was learned

## Commands
```bash
{{DEV_COMMAND}}       # Start dev server
{{TEST_COMMAND}}      # Run test suite
{{BUILD_COMMAND}}     # Production build
{{LINT_COMMAND}}      # Lint and typecheck
{{MIGRATE_COMMAND}}   # Run DB migrations
npx agnix .           # Lint blueprint files
npx agnix --fix .     # Auto-fix HIGH/MEDIUM findings
npm run storybook     # Launch component library (if configured)
```

## Project Structure
```
{{DIRECTORY_MAP}}
```

## Gate Rules (hard stops -- no exceptions)

### Version Gate Rule
YOU MUST NOT proceed to the next gate with failing tests.
Stop, run {{TEST_COMMAND}}, report to Brian, wait for GO.

### Design Phase 1 Gate
YOU MUST NOT write any UI component, screen, or style until
DESIGN_SYSTEM.md contains "- [x] Phase 1 complete".

### Mockup Gate
YOU MUST NOT build any screen without APPROVED in MOCKUPS.md.
DRIFT entries block gate close until resolved.

### Frontend Spec Gate
YOU MUST NOT build any component without reading FRONTEND_SPEC.md first.
Every component must match the spec -- deviation is a regression.

### Gate Close Checklist
- [ ] All tests passing
- [ ] Security lightweight check: PASS
- [ ] Performance lightweight check: PASS
- [ ] /deslop applied to all modified files
- [ ] CHANGELOG.md updated
- [ ] SPEC.md all items checked
- [ ] TIMELOG.md updated with hours and cost
- [ ] agnix: no errors
- [ ] MOCKUPS.md: no DRIFT entries
- [ ] FRONTEND_SPEC.md: components match spec

### Human Checkpoint Rule
Stop and surface to Brian at:
- Every gate boundary
- Any decision changing a CONTRACT.md value
- Any unrecoverable error or blocker
- Any scope question not answered by existing files
Proceed autonomously within a gate.

## Sacred Rules
- Config values: CONTRACT.md only. Never hardcode.
- Agent/tool permissions: COUNCIL_AGENTS.md only.
- Mistakes: add to ERRORS.md immediately.
- Learnings: add to MEMORY.md at session end.
- UI components: must match FRONTEND_SPEC.md exactly.
- Sequential builds only: backend first, validate, then frontend.
- This file evolves: propose one update per session.
- Stay under 200 lines. Use @imports for everything else.

## Reference Documents
### `@CONTRACT.md` -- config, env vars, ports, endpoints
### `@HARNESS.md` -- agent loop, tool registry, context management
### `@COUNCIL_AGENTS.md` -- agent roster and tool permissions
### `@TECH_STACK.md` -- stack decisions and dependency rationale
### `@DESIGN_SYSTEM.md` -- design tokens, colors, fonts, spacing
### `@FRONTEND_SPEC.md` -- component specs, screen layouts, interactions
### `@MOCKUPS.md` -- approved screen mockups, drift log
### `@VERSION_ROADMAP.md` -- gate structure and milestones
### `@SPEC.md` -- current gate specification
### `@CHANGELOG.md` -- gate-by-gate change log
### `@MEMORY.md` -- cross-session learnings (read at boot, write at end)
### `@ERRORS.md` -- failure log (read at boot, write on mistakes)
### `@DECISIONS.md` -- architectural decision log
